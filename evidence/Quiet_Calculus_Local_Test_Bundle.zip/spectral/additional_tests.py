"""Frozen bounded perturbation/replication checks; see PROTOCOL.md."""
import os
for _k in ('OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[_k]='1'
from pathlib import Path
import sys,json,time,hashlib,platform,traceback
import numpy as np
import scipy
from numpy.polynomial.legendre import leggauss

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'exact_mode_copy'))
import mode_sums as m
import independent_checks as ic

checks={}; raw={}; timings={}
def record(name,condition,metric=None,tolerance=None,status=None):
    d={'status':status or ('pass' if condition else 'fail')}
    if metric is not None:d['metric']=float(metric)
    if tolerance is not None:d['tolerance']=float(tolerance)
    checks[name]=d
    print(name,d,flush=True)

def serialize(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    raise TypeError(type(x).__name__)

def real_potential_fit(kind,L,hmin,hmax,second_scale=1.):
    hs=np.linspace(hmin,hmax,12)
    potentials=np.zeros((len(hs),len(nodes)))
    for block in m.blocks(kind,L):
        B=block['D']/R
        S=block['S'][0].copy()
        if len(block['S'])>1:S+=second_scale*block['S'][1]
        e0=np.linalg.eigvalsh(B)**2
        for i,h in enumerate(hs):
            eh=np.linalg.eigvalsh(B+h*S)**2
            delta=eh-e0
            # Sorted eigenvalues pair continuous finite-matrix spectra; expm1
            # reduces cancellation without a Taylor coefficient extractor.
            changes=(np.exp(-nodes[:,None]*e0[None,:])
                     *np.expm1(-nodes[:,None]*delta[None,:])).sum(axis=1)
            potentials[i]+=changes/(8*np.pi**2*nodes**2)
    x=hs**2; z=x/hmax**2
    design=np.column_stack([z**i for i in range(6)])
    coef,_,_,_=np.linalg.lstsq(design,potentials/x[:,None],rcond=None)
    predicted=design@coef
    return {'hs':hs,'potential_per_node':potentials,'A2':coef[0],
            'A4':coef[1]/hmax**2,'fit_residual':float(np.max(abs(predicted-potentials/x[:,None]))),
            'design_condition':float(np.linalg.cond(design))}

def quadrature_G(L,order):
    xx,ww=leggauss(order);ss=(xx+1)/2;ww=ww/2
    out=np.zeros(len(nodes))
    for block in m.blocks('pair',L):
        eig,U=np.linalg.eigh(block['D']/R);e=eig**2
        S=U.T@block['S'][0]@U;A=(eig[:,None]+eig[None,:])*S
        for i,a in enumerate(nodes):
            total=0.
            for s,w in zip(ss,ww):
                heat=np.exp(-a*(s*e[:,None]+(1-s)*e[None,:]))
                total+=w*np.sum(heat*(S*S-a*s*(1-s)*A*A))
            out[i]+=total/(8*np.pi**2)
    return out

def direct_projected_mass(kind,amplitudes,L,epsilon,order=240):
    xx,ww=leggauss(order);ss=(xx+1)/2;ww=ww/2
    result=np.zeros(len(nodes))
    for block in m.blocks(kind,L):
        B=block['D']/R+sum((h*S for h,S in zip(amplitudes,block['S'])),np.zeros_like(block['D']))
        eig,U=np.linalg.eigh(B);e=eig**2
        T=U.T@(block['T'][0]+block['T'][1]+epsilon*block['T'][2])@U
        C=(eig[:,None]-eig[None,:])*T
        for i,a in enumerate(nodes):
            total=0.
            for s,w in zip(ss,ww):
                heat=np.exp(-a*(s*e[:,None]+(1-s)*e[None,:]))
                total+=w*np.sum(heat*(2/a*T*T+C*C))
            contact=np.dot(np.sum(T*T,axis=1),np.exp(-a*e))
            result[i]+=(total-2/a*contact)/(8*np.pi**2)
    return result

def scalar_tests():
    ts=time.monotonic(); allfits={}; summaries={}
    for L in (8,12):
        for hmin,hmax in ((.15,.45),(.20,.60)):
            key=f'L{L}_h{hmin}_{hmax}'
            f={kind:real_potential_fit(kind,L,hmin,hmax) for kind in ('pair','quark','parallel')}
            allfits[key]=f; summaries[key]={}
            for label,w in (('minus',wm),('plus',wp)):
                A2=w@f['pair']['A2'];A4=w@f['pair']['A4']
                C0=w@(f['quark']['A4']-2*f['pair']['A4'])
                C1=w@(f['parallel']['A4']-f['quark']['A4'])
                vals={'A2':A2,'A4':A4,'C0':C0,'C1':C1}
                summaries[key][label]=vals
                err=max(abs(vals[k]-ref['scalar_profiles'][label][k]) for k in vals)
                record(f'T1a_reference_{key}_{label}',err<1e-9,err,1e-9)
                identity=abs(C0+C1-2*A4)
                record(f'T1a_independent_sum_{key}_{label}',identity<1e-10,identity,1e-10)
    vals=[v['minus'] for v in summaries.values()]
    spread=max(max(v[k] for v in vals)-min(v[k] for v in vals) for k in vals[0])
    record('T1a_grid_cutoff_spread',spread<1e-9,spread,1e-9)
    nominal=summaries['L12_h0.15_0.45']['minus']
    local_residual=abs(nominal['C1']-nominal['C0'])
    record('CONTROL_T1_local_equality_rejected',local_residual>1e-6,local_residual,1e-6)
    mutant=real_potential_fit('parallel',12,.15,.45,second_scale=1.10)
    mutant_residual=abs(wm@mutant['A4']-4*nominal['A4'])
    record('CONTROL_T1_altered_Yukawa_rejected',mutant_residual>1e-6,mutant_residual,1e-6)
    raw['T1a']={'fits':allfits,'summaries':summaries,'parallel_mutant':mutant}
    timings['T1a_seconds']=time.monotonic()-ts
    ts=time.monotonic(); gg={}
    for L,order in ((8,160),(12,240)):
        v=quadrature_G(L,order);gg[f'L{L}_order{order}']=v
        diff=dw@v;err=abs(diff-1.8962286434521906e-9)
        record(f'T1b_profile_difference_L{L}',err<1e-11,err,1e-11)
    moments=[dw@(nodes**k) for k in (-3,-2,-1,0,1,2)]
    record('T1b_retained_local_moments',max(abs(np.array(moments)))<2e-15,max(abs(np.array(moments))),2e-15)
    delta=abs(dw@(gg['L8_order160']-gg['L12_order240']))
    record('T1b_quadrature_cutoff_delta',delta<1e-11,delta,1e-11)
    raw['T1b']={'G_per_node':gg,'profile_differences':{k:dw@v for k,v in gg.items()},'shared_moment_residuals':moments}
    timings['T1b_seconds']=time.monotonic()-ts
    return gg['L12_order240']

def neutral_tests(G_independent):
    ts=time.monotonic();N=np.array([1.,1.,0.]);scales=(1.,.75,.5,.375,.25)
    shifts=np.array(fresh['higgs_shift_per_node'])
    out={}
    for L in (8,12):
        k0,_=m.full_response(R,nodes,0.,0.,L)
        out[str(L)]={}
        for t in scales:
            hd=.12*t;hu=.09*t;k,mass=m.full_response(R,nodes,hd,hu,L)
            delta=np.tensordot(wm,k-k0,axes=1)
            rem=delta-np.tensordot(wm,hd**2*shifts[0]+hu**2*shifts[1],axes=1)
            mm=np.tensordot(wm,mass,axes=1)
            residual=np.linalg.norm(mm@N)/np.linalg.norm(mm)
            record(f'T2a_photon_null_L{L}_t{t}',residual<1e-9,residual,1e-9)
            out[str(L)][str(t)]={'K_shift':delta,'mass':mm,'photon_remainder':N@rem@N,'matrix_remainder':rem,'normalized_null':residual}
        for large,small in ((1.,.5),(.5,.25)):
            r1=out[str(L)][str(large)]['photon_remainder'];r2=out[str(L)][str(small)]['photon_remainder']
            if abs(r1)<=1e-12:
                record(f'T2a_fourth_order_L{L}_{large}_{small}',False,abs(r1),1e-12,status='inconclusive')
            else:
                ratio=abs(r2/r1)
                record(f'T2a_fourth_order_L{L}_{large}_{small}',.03<=ratio<=.10,ratio)
    spread=max(np.max(abs(out['8'][str(t)]['K_shift']-out['12'][str(t)]['K_shift'])) for t in scales)
    record('T2a_response_cutoff_change',spread<1e-10,spread,1e-10)
    _,M0=m.full_response(R,nodes,0.,0.,12);ward=[]
    for i,nd in enumerate((16,12)):
        vals=[]
        for h in (.08,.04,.02):
            amps=(h,0.) if i==0 else (0.,h)
            _,mass=m.full_response(R,nodes,*amps,12)
            vals.append(np.tensordot(wm,mass-M0,axes=1)/h**2)
        r1=(4*vals[1]-vals[0])/3;r2=(4*vals[2]-vals[1])/3
        estimate=(16*r2-r1)/15
        charge=np.array([-.5,.5,1. if i==0 else -1.])
        target=(wm@G_independent)*nd*np.outer(charge,charge)
        err=np.max(abs(estimate-target));ward.append({'estimate':estimate,'target':target,'error':err})
        record(f'T2a_Ward_independent_G_{i}',err<2e-9,err,2e-9)
    direct={};matrix=out['12']['1.0']['mass']
    for epsilon in (0.,.05):
        q=direct_projected_mass('quark',(.12,.09),12,epsilon)
        ell=direct_projected_mass('lepton',(.12,),12,epsilon)
        value=wm@(12*q+4*ell)
        NN=np.array([1.,1.,epsilon]);expected=NN@matrix@NN
        direct[str(epsilon)]={'mass':value,'matrix_projection':expected,'error':abs(value-expected)}
        record(f'T2a_independent_mass_projection_eps{epsilon}',abs(value-expected)<1e-11,abs(value-expected),1e-11)
    record('T2a_direct_protected_mass',abs(direct['0.0']['mass'])<1e-11,abs(direct['0.0']['mass']),1e-11)
    record('CONTROL_T2_wrong_generator_rejected',direct['0.05']['mass']>1e-8,direct['0.05']['mass'],1e-8)
    raw['T2a']={'field_scaling':out,'Ward':ward,'independent_projection':direct}
    timings['T2a_seconds']=time.monotonic()-ts

def vertex_tests():
    ts=time.monotonic();rng=np.random.default_rng(20261025);fixtures=[]
    b=np.array([-1.1,-.3,.4,1.3])
    for i,(a,rr) in enumerate(zip((.61,1.07,1.43),(.9,1.4,1.8))):
        x=rng.normal(size=(4,4))*.2;T=(x+x.T)/2
        x=rng.normal(size=(4,4))*.2;L=(x+x.T)/2
        zero=ic.direct_gauge_fourier(a,rr,b,T,L,0.,order=64)
        vals=[(ic.direct_gauge_fourier(a,rr,b,T,L,h,order=64)-zero)/h**2 for h in (.06,.03,.015)]
        r1=(4*vals[1]-vals[0])/3;r2=(4*vals[2]-vals[1])/3
        exact=(16*r2-r1)/15
        contracted=ic.contracted_gauge_kinetic(a,rr,b,T,L)
        mutant=ic.contracted_gauge_kinetic(a,rr,b,T,np.zeros_like(L))
        err=abs(exact-contracted)
        record(f'T2b_new_Clifford_fixture_{i}',err<2e-9,err,2e-9)
        fixtures.append({'a':a,'R':rr,'b':b,'T':T,'L':L,'finite_q':vals,'direct':exact,'contracted':contracted,'omitted_Pauli':mutant,'mutant_discrepancy':abs(exact-mutant)})
    discrepancy=max(f['mutant_discrepancy'] for f in fixtures)
    record('CONTROL_T2_omitted_Pauli_rejected',discrepancy>1e-7,discrepancy,1e-7)
    raw['T2b']=fixtures;timings['T2b_seconds']=time.monotonic()-ts

if __name__=='__main__':
    started=time.monotonic()
    p=json.loads((ROOT/'exact_mode_copy/inputs/common_vacuum_pair.json').read_text())
    R=float(p['common_R']);nodes=np.array(p['nodes'],float)
    wm=np.array(p['weights_minus'],float);wp=np.array(p['weights_plus'],float);dw=wp-wm
    ref=json.loads((ROOT/'reference_outputs/results.json').read_text())
    fresh=json.loads((ROOT/'exact_mode_copy/results.json').read_text())
    fatal=None
    try:
        g=scalar_tests();neutral_tests(g);vertex_tests()
    except Exception:
        fatal=traceback.format_exc();print(fatal,flush=True)
    timings['total_seconds']=time.monotonic()-started
    report={'checks':checks,'raw':raw,'timings':timings,'fatal_error':fatal,
            'environment':{'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'numpy':np.__version__,'scipy':scipy.__version__}}
    (ROOT/'additional_results.json').write_text(json.dumps(report,indent=2,default=serialize)+'\n')
    counts={s:sum(v['status']==s for v in checks.values()) for s in ('pass','fail','inconclusive')}
    print('FINAL',counts,'fatal',fatal is not None,'seconds',timings['total_seconds'],flush=True)
    sys.exit(1 if fatal or counts['fail'] else 0)
