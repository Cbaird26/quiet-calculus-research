# Bounded spectral test results

Bounded classical spectral computational replication and perturbation tests, not laboratory or ToE validation.

Protocol freeze: `78df3370d890b12daa9d716b09e62894ddea7af1c45e480aaa9c1ef57644f0e1` at 2026-10-26T00:22:15.718511+00:00.
Historical outcomes were known. New protocols and executable hashes were frozen before these executions.

Fresh archived suite: 126/126 recorded checks; execution success = True.
Additional checks: 48 pass, 0 fail, 0 inconclusive.
Original source files checked: 76; changed: 0. Frozen files changed: 0.

## Selected new numerical results

- real_axis_scalar_minus: `{"A2": -0.003247173901751544, "A4": 0.00016967340585381807, "C0": 0.0001309313121945121, "C1": 0.00020841549862176848}`
- C1_over_C0: `1.591792636372158`
- max_real_axis_reference_error_all_fits: `3.375602320452101e-11`
- max_protected_sum_residual_all_fits: `3.4848618023393396e-11`
- max_normalized_photon_null_residual: `1.9348711333450836e-12`
- negative_control_residuals: `{"CONTROL_T1_local_equality_rejected": 7.74841864272564e-05, "CONTROL_T1_altered_Yukawa_rejected": 0.00015000825521187125, "CONTROL_T2_wrong_generator_rejected": 3.010333285427451e-06, "CONTROL_T2_omitted_Pauli_rejected": 0.001036133239219321}`
- direct_profile_delta_G: `{"L8_order160": 1.8962286435064007e-09, "L12_order240": 1.8962286435064007e-09}`
- photon_remainders_L12: `{"1.0": 1.822506452226545e-06, "0.75": 5.771255753994811e-07, "0.5": 1.1406695287197878e-07, "0.375": 3.609890439703717e-08, "0.25": 7.131693062387138e-09}`
- independent_projected_masses: `{"0.0": {"mass": 4.0205106021398045e-16, "matrix_projection": -4.2609145378680324e-17, "error": 4.446602055926607e-16}, "0.05": {"mass": 3.010333285427451e-06, "matrix_projection": 3.0103332853847005e-06, "error": 4.275059988087179e-17}}`
- external_Clifford_absolute_errors: `[7.676064645023573e-14, 2.9866300405023694e-14, 1.8791392053518763e-15]`

## Failures and inconclusive checks

None recorded.

## Scope limits

- Historical outcomes known; internal prospective replication protocol, not public or blinded preregistration.
- Additional routes reuse the monopole matrix builder; not a fully independent implementation of the entire model.
- Double precision, finite angular cutoffs and finite test points; no interval enclosure or universal tail bound.
- Field-scaling check is a bounded numerical diagnostic, not proof of an asymptotic theorem.
- No physical vacuum solved; no six-dimensional anomaly completion, quantum thresholds, physical pole masses, observed coupling or laboratory test.
- Negative controls deliberately violate assumptions and test sensitivity; they do not establish sensitivity to every possible implementation error.

Commands/timings: execution_records.json. Full raw arrays and fits: additional_results.json. Fresh-suite logs: T0.stdout.log and T0.stderr.log. Additional logs: additional.stdout.log and additional.stderr.log. Historical comparison: replication_comparison.json. No source files were intentionally altered.
