"""Post-execution reporting only; does not alter tests or their outcomes."""
from pathlib import Path
import json,hashlib,datetime,math
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def compare(a,b,path=''):
    out=[]
    if isinstance(a,dict) and isinstance(b,dict):
        for k in sorted(set(a)|set(b)):
            if k not in a or k not in b:out.append({'path':path+'/'+k,'kind':'missing','reference':a.get(k),'fresh':b.get(k)})
            else:out+=compare(a[k],b[k],path+'/'+k)
    elif isinstance(a,list) and isinstance(b,list):
        if len(a)!=len(b):out.append({'path':path,'kind':'length','reference':len(a),'fresh':len(b)})
        for i,(x,y) in enumerate(zip(a,b)):out+=compare(x,y,path+'/'+str(i))
    elif a!=b:
        is_number=lambda x:isinstance(x,(int,float)) and not isinstance(x,bool)
        if is_number(a) and is_number(b):out.append({'path':path,'kind':'numeric','reference':a,'fresh':b,'absolute_difference':abs(a-b)})
        else:out.append({'path':path,'kind':'other','reference':a,'fresh':b})
    return out

execution=json.loads((ROOT/'execution_records.json').read_text())
audit=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text());src=Path(audit['source'])
changes=[]
for name,h in audit['files'].items():
    p=src/name
    if not p.exists() or digest(p)!=h:changes.append(name)
freeze=json.loads((ROOT/'PROTOCOL_FREEZE.json').read_text())
frozen_changes=[name for name,h in freeze['files'].items() if not (ROOT/name).exists() or digest(ROOT/name)!=h]
comparison={}
for name in ('results.json','checks.json'):
    ref=ROOT/'reference_outputs'/name;fresh=ROOT/'exact_mode_copy'/name
    d=compare(json.loads(ref.read_text()),json.loads(fresh.read_text()))
    comparison[name]={'byte_identical':digest(ref)==digest(fresh),'difference_count':len(d),
                     'numeric_max_absolute_difference':max((x['absolute_difference'] for x in d if x['kind']=='numeric'),default=0),
                     'nonnumeric_differences':[x for x in d if x['kind']!='numeric'],'all_differences':d}
(ROOT/'replication_comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
t0=json.loads((ROOT/'exact_mode_copy/checks.json').read_text())
extra=json.loads((ROOT/'additional_results.json').read_text()) if (ROOT/'additional_results.json').exists() else {}
counts={s:sum(v['status']==s for v in extra.get('checks',{}).values()) for s in ('pass','fail','inconclusive')}
summary={'date_local':'2026-10-25','timezone':'America/New_York','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope':'Bounded classical spectral computational replication and perturbation tests, not laboratory or ToE validation.',
    'protocol_freeze_sha256':digest(ROOT/'PROTOCOL_FREEZE.json'),'frozen_at_utc':freeze['frozen_utc'],
    'historical_outcomes_known_before_freeze':True,'original_source_files_checked':len(audit['files']),
    'original_source_files_changed':changes,'frozen_files_changed':frozen_changes,
    'execution':execution,'T0':{'passed':t0['passed'],'total':t0['total'],'fresh_execution_succeeded':any(x['stage']=='T0' and x.get('exit_code')==0 for x in execution)},
    'additional':{'counts':counts,'fatal_error':extra.get('fatal_error'),'checks':extra.get('checks',{}),'timings':extra.get('timings',{})},
    'comparison':{k:{a:b for a,b in v.items() if a!='all_differences'} for k,v in comparison.items()},
    'limitations':['Historical outcomes known; internal prospective replication protocol, not public or blinded preregistration.',
                  'Additional routes reuse the monopole matrix builder; not a fully independent implementation of the entire model.',
                  'Double precision, finite angular cutoffs and finite test points; no interval enclosure or universal tail bound.',
                  'Field-scaling check is a bounded numerical diagnostic, not proof of an asymptotic theorem.',
                  'No physical vacuum solved; no six-dimensional anomaly completion, quantum thresholds, physical pole masses, observed coupling or laboratory test.',
                  'Negative controls deliberately violate assumptions and test sensitivity; they do not establish sensitivity to every possible implementation error.']}
if extra.get('raw'):
    rr=extra['raw'];nom=rr['T1a']['summaries']['L12_h0.15_0.45']['minus']
    summary['selected_results']={'real_axis_scalar_minus':nom,'C1_over_C0':nom['C1']/nom['C0'],
        'max_real_axis_reference_error_all_fits':max(v['metric'] for k,v in extra['checks'].items() if k.startswith('T1a_reference')),
        'max_protected_sum_residual_all_fits':max(v['metric'] for k,v in extra['checks'].items() if k.startswith('T1a_independent_sum')),
        'max_normalized_photon_null_residual':max(v['metric'] for k,v in extra['checks'].items() if k.startswith('T2a_photon_null')),
        'negative_control_residuals':{k:v['metric'] for k,v in extra['checks'].items() if k.startswith('CONTROL_')},
        'direct_profile_delta_G':rr['T1b']['profile_differences'],
        'photon_remainders_L12':{k:v['photon_remainder'] for k,v in rr['T2a']['field_scaling']['12'].items()},
        'independent_projected_masses':rr['T2a']['independent_projection'],
        'external_Clifford_absolute_errors':[abs(x['direct']-x['contracted']) for x in rr['T2b']]}
(ROOT/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['# Bounded spectral test results','',summary['scope'],'',
       f"Protocol freeze: `{summary['protocol_freeze_sha256']}` at {freeze['frozen_utc']}.",
       'Historical outcomes were known. New protocols and executable hashes were frozen before these executions.','',
       f"Fresh archived suite: {t0['passed']}/{t0['total']} recorded checks; execution success = {summary['T0']['fresh_execution_succeeded']}.",
       f"Additional checks: {counts['pass']} pass, {counts['fail']} fail, {counts['inconclusive']} inconclusive.",
       f"Original source files checked: {len(audit['files'])}; changed: {len(changes)}. Frozen files changed: {len(frozen_changes)}.",'',
       '## Selected new numerical results','']
for k,v in summary.get('selected_results',{}).items():lines.append(f'- {k}: `{json.dumps(v)}`')
lines+=['','## Failures and inconclusive checks','']
bad={k:v for k,v in extra.get('checks',{}).items() if v['status']!='pass'}
lines.append(json.dumps(bad,indent=2) if bad else 'None recorded.')
if extra.get('fatal_error'):lines.append(extra['fatal_error'])
lines+=['','## Scope limits','']+['- '+v for v in summary['limitations']]
lines+=['','Commands/timings: execution_records.json. Full raw arrays and fits: additional_results.json. Fresh-suite logs: T0.stdout.log and T0.stderr.log. Additional logs: additional.stdout.log and additional.stderr.log. Historical comparison: replication_comparison.json. No source files were intentionally altered.','']
(ROOT/'SUMMARY.md').write_text('\n'.join(lines))
manifest={str(p.relative_to(ROOT)):digest(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='ARTIFACT_SHA256SUMS.json' and '__pycache__' not in p.parts}
(ROOT/'ARTIFACT_SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'T0':summary['T0'],'additional_counts':counts,'source_changes':changes,'frozen_changes':frozen_changes,'selected':summary.get('selected_results')},indent=2))
