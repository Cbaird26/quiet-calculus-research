"""Execute already-frozen sources; preserve logs, command and timestamps."""
from pathlib import Path
import sys,os,json,hashlib,datetime,time,subprocess
ROOT=Path(__file__).resolve().parent
PY='/Users/christophermichaelbaird/Documents/ChatGPT/ZoraASI/release_2026-10-22_scalar_anomaly/.venv/bin/python'
freeze=json.loads((ROOT/'PROTOCOL_FREEZE.json').read_text())
for name,digest in freeze['files'].items():
    actual=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    if actual!=digest:raise SystemExit('Frozen-file hash mismatch: '+name)
env=os.environ.copy()
for k in ('OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):env[k]='1'
env['PYTHONDONTWRITEBYTECODE']='1'
records=[]
for label,script,cwd in [('T0','run_all.py',ROOT/'exact_mode_copy'),('additional','additional_tests.py',ROOT)]:
    rec={'stage':label,'command':[PY,script],'cwd':str(cwd),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':600}
    start=time.monotonic()
    try:
        p=subprocess.run([PY,script],cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=600)
        rec.update(exit_code=p.returncode,timed_out=False)
        (ROOT/(label+'.stdout.log')).write_text(p.stdout)
        (ROOT/(label+'.stderr.log')).write_text(p.stderr)
    except subprocess.TimeoutExpired as exc:
        rec.update(exit_code=None,timed_out=True)
        (ROOT/(label+'.stdout.log')).write_text((exc.stdout or b'').decode() if isinstance(exc.stdout,bytes) else exc.stdout or '')
        (ROOT/(label+'.stderr.log')).write_text((exc.stderr or b'').decode() if isinstance(exc.stderr,bytes) else exc.stderr or '')
    rec['elapsed_seconds']=time.monotonic()-start
    rec['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();records.append(rec)
    (ROOT/'execution_records.json').write_text(json.dumps(records,indent=2)+'\n')
    print(rec,flush=True)
    if label=='T0' and (rec['timed_out'] or rec['exit_code']!=0):
        print('T0 failed; additional stage not run because fresh inputs were not produced.',flush=True);break
