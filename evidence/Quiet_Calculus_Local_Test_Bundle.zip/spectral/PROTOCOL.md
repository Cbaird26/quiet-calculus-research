# Frozen bounded spectral replication protocol

Date: 2026-10-25, America/New_York. This is an internal computational protocol freeze, not a public preregistration. Historical package values and previous checks were read before this protocol was written. New perturbation, field-scaling and real-axis fitting outcomes have not been inspected. No empirical or physical confirmation is claimed.

## Scope and preservation

Run only in this isolated folder. The source is the exact-mode package recorded in SOURCE_MANIFEST.json. Keep reference_outputs unchanged. Do not modify source packages or contact a network. Use existing Python 3.14 environment `/Users/christophermichaelbaird/Documents/ChatGPT/ZoraASI/release_2026-10-22_scalar_anomaly/.venv/bin/python`, NumPy 2.4.3, SciPy 1.18.1. Set OPENBLAS_NUM_THREADS, VECLIB_MAXIMUM_THREADS, OMP_NUM_THREADS and MKL_NUM_THREADS to 1; disable bytecode writing. Save executable path, environment versions, command, timing, stdout and stderr. Each executable stage has a 600-second timeout. No automatic tolerance relaxation or post-outcome alteration of this protocol.

## T0: Re-execute the saved computation

Run exact_mode_copy/run_all.py freshly. Require exit zero and 126/126 recorded passing checks. Compare JSON numeric leaves with preserved reference outputs; report maximum absolute difference and all structural/environment changes. A byte comparison is recorded separately from numeric agreement. This is replication of the same implementation, not independent validation.

## T1a: Independent real-axis scalar extraction

Reuse the source's monopole matrix builder (an explicit independence limitation), but do not call its Toeplitz or Cauchy potential extractor for the new route. Use NumPy Hermitian eigenvalue diagonalization of B+hS and a stable expm1 heat-trace difference. Fit [V(h)-V(0)]/h^2 as a degree-five polynomial in normalized h^2 on 12-point grids [0.15,0.45] and [0.20,0.60], at levels 8 and 12. Use both profiles and all ten rates. Independently fit one-link, orthogonal-link (quark), and parallel-link potentials. Define A4 from the single-link fit, C0 from quark-2*single, and C1 from parallel-quark. In particular do not define C1=2*A4-C0.

Require all four coefficient estimates A2,A4,C0,C1 (A2 comparison for single link) to match preserved results within absolute 1e-9, fitting-grid and cutoff changes below 1e-9, and |C0+C1-2*A4| below 1e-10. These are proposed acceptance tolerances, not claims of certified error. Save polynomial residuals and conditioning. A failed tolerance remains failed.

Negative controls: (i) compare C1-C0 against a deliberately imposed local-equality null, requiring a discrepancy above 1e-6; (ii) scale the second parallel Yukawa insertion by 1.10 while retaining the unperturbed identity comparator, requiring |A4_parallel_mutant-4*A4_single| above 1e-6. These demonstrate detection of violated assumptions, not discovery of a physical effect.

## T1b: Profile discrimination through independent quadrature

Compute G from its spectral formula using direct Gauss-Legendre quadrature of heat moments, independently of the source's closed-form heat_moments routine, at (L,order)=(8,160),(12,240). Reuse monopole matrices and Hermitian diagonalization. Calculate differences directly as delta_weights dot per-node G. Require delta_G to agree with the preserved 1.8962286434521906e-9 within 1e-11, and quadrature/cutoff agreement within 1e-11. Require the six shared local moments to remain within 2e-15. This tests exact-profile discrimination; the C1/C0 inequality in T1a alone does not.

## T2a: Field scaling, Ward relation and photon direction

Use fresh Cauchy coefficients from T0 and fresh real-background responses at (hd,hu)=t*(0.12,0.09), t in {1,0.75,0.5,0.375,0.25}, at L=8,12. Subtract unbroken and quadratic kinetic terms. For photon-projected remainders require |r(0.5)/r(1)| and |r(0.25)/r(0.5)| in [0.03,0.10], only if both denominators exceed 1e-12 (otherwise mark inconclusive). This is a finite-range diagnostic for O(h^4), not a proof of a leading nonzero fourth-order coefficient. Require absolute cross-cutoff response differences below 1e-10 and normalized mass-null residual ||M N||/||M|| below 1e-9 with N=(1,1,0). Extract directional h^2 mass coefficients with two levels of Richardson extrapolation at h=0.08,0.04,0.02; compare the Ward targets using independent-quadrature G, tolerance 2e-9.

For a second route, evaluate the photon-projected mass formula directly with quadrature heat moments in the raw operator blocks for both Q and Q+0.05X at hd=0.12,hu=0.09. Require direct vs matrix-projected agreement below 1e-11, the proper-Q mass below 1e-11, and the deliberately nonneutral Q+0.05X mass above 1e-8. No source matrix is edited.

## T2b: New finite-momentum external-Clifford fixtures

Use three new deterministic four-state fixtures (NumPy RNG seed 20261025); fixed internal eigenvalues [-1.1,-0.3,0.4,1.3], a in [0.61,1.07,1.43], R in [0.9,1.4,1.8]. Generate independent real symmetric T,L with scale 0.2. Compare full external-Clifford finite-q response, Gauss order 64, q=0.06,0.03,0.015 and Richardson extraction, to the contracted coefficient. Require absolute difference below 2e-9. A negative control omits L only from the contracted expression; require at least one fixture to differ from the full result by more than 1e-7. These use the archived independent-check implementation with new inputs, and are not a wholly independent derivation.

## Interpretation and reporting

Classify each check as pass, fail, inconclusive, or not executed. Retain raw values even on failure. No interval enclosure or universal tail bound; no full independent monopole construction; no anomaly completion; no coupled vacuum; no physical pole masses; no laboratory data; no measured fine-structure constant. No proof of ToE or ZoraASI capability follows from these computational tests. Any later repairs must be new, labeled amendments with preserved original outcomes.
