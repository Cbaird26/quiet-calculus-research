# Quiet Calculus version 3: local computational evidence

Executed October 25, 2026 America/New_York (October 26 UTC). These records contain software checks, synthetic local-model behavior, generated-path simulations, and conditional mathematical computations. They contain no human or laboratory study, physical field observation, or empirical validation of a Theory of Everything. Check counts are not counts of independent physical experiments.

## Main findings

- `pilot/integration_summary.json`: 12 AI-authored fictional event groups; 48 actual local model calls; both systems match 10/12 provisional labels and make the same two false refutations. Three roles use 3.28 times the tokens and 3.63 times the elapsed case time. No generalization or causal role-superiority estimate follows. Original software tests 29/29; fresh controls 668/668; artifact/arithmetic assertions 380/380.
- `memory/results/summary.json`: 1,100 new scenario paths, summarized with 100 independent seed clusters across 11 known scenario generators. Adaptive minus validation-selected fixed-memory Brier loss is -0.000279697, but the frozen minimum-benefit and worst-scenario harm criteria both fail. The bank replication and negative results are retained. Forty-one software checks pass.
- `portal/results.json`: nine of 56 wider reference quadratures warned; the initial plan is not all-pass. `followup_results.json` is a separately frozen exploratory phase-aware/weighted-cosine diagnosis. It resolves the tested discrepancies without erasing the initial warnings. The same workstream compares pure-dephasing implementations on 960 density configurations and includes controls.
- `spectral/SUMMARY.json`: freshly reproduced 126 historical checks, plus 48 new numerical/control checks. Finite cutoffs, double precision, a shared matrix builder, and an incomplete physical model limit the conclusion. Coupled-vacuum and empirical matching gates remain open.

## Integrity and reproduction

`BUNDLE_SHA256SUMS.txt` hashes every delivered file except itself. Existing workstream manifests, frozen protocols, commands, logs, raw responses, and original-versus-copy integrity records remain intact. Bytecode/cache files are omitted. The nested memory archive is preserved as an independently sealed component.

Follow `pilot/README.txt`, `memory/README.txt`, `portal/README.md`, and `spectral/SUMMARY.md` plus its execution records. Inference requires the exact installed local Ollama model digest. The memory run uses copied pinned dependencies. Numerical work needs the recorded NumPy/SciPy/mpmath environments. Some audit commands also check the original absolute local source paths; those source-integrity assertions are machine-specific. Copy/redirect to new output folders before rerunning experiments. Never overwrite frozen results.

`aggregate_audit.py` independently recomputes memory statistics from saved path metrics and checks that initial portal failures and follow-up remain distinct; it does not regenerate forecasts or observations. All protocol freezes were internal and informed by historical research, not independently blinded public preregistration. The portal follow-up was designed after initial numerical warnings.

The companion paper and Overleaf project are separate artifacts. Their compact `data/fresh_run_manifest.json` binds reported results to these records. Artifact compilation and checksum agreement establish reproducibility/integrity, not physical truth. No external model review, publication, or upload is claimed.
