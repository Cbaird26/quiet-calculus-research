"""Post-run artifact and arithmetic audit. Does not change policies or predictions."""
from collections import Counter,defaultdict
from datetime import datetime,timezone
import hashlib
import json
import math
from pathlib import Path
import re
import statistics

ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    cfg=json.loads((ROOT/'protocol.json').read_text())
    fr=json.loads((ROOT/'freeze.json').read_text())
    frozen={n:sha(ROOT/n)==h for n,h in fr['files'].items()}
    src=json.loads((ROOT/'source_provenance.json').read_text())
    originals={n:sha(Path(v['original']))==v['sha256'] for n,v in src.items()}
    copies={n:sha(ROOT/n)==v['sha256'] for n,v in src.items()}
    receipt=json.loads((ROOT/'results/execution_receipt.json').read_text())
    assert receipt['status']=='complete'
    assert all(frozen.values()) and all(originals.values()) and all(copies.values())
    rows=[json.loads(line) for line in (ROOT/'results/raw_paths.jsonl').open()]
    result=json.loads((ROOT/'results/summary.json').read_text())
    val=json.loads((ROOT/'results/validation.json').read_text())
    assert sha(ROOT/'results/validation.json')==(ROOT/'results/validation.sha256').read_text().strip()
    assert sha(ROOT/'results/raw_paths.jsonl')==result['raw_sha256']
    assert len(rows)==1100 and len({(r['split'],r['scenario'],r['seed']) for r in rows})==1100
    expected={(split,sc):cfg['test_n'] for split in cfg['test_bases'] for sc in cfg['scenarios']}
    assert Counter((r['split'],r['scenario']) for r in rows)==expected
    used=[set(range(base,base+cfg['test_n'])) for base in cfg['test_bases'].values()]
    used.append(set(range(cfg['validation_base'],cfg['validation_base']+cfg['validation_n'])))
    previous=set(range(181000000,181000100))|set(range(191000000,191000100))|set(range(201000000,201000030))
    assert not(set.union(*used)&previous)
    assert all(not(a&b) for i,a in enumerate(used) for b in used[i+1:])
    assert not(set.union(*used)&{s+1000000000 for s in set.union(*used)})
    recomputed_selection=min(cfg['hazards'],key=lambda h:statistics.mean(r['brier'] for r in val['raw'] if r['hazard']==h))
    assert recomputed_selection==val['selected_hazard']==result['selected_hazard']
    trace_checks=0
    for r in rows:
        assert all(r['identity'].values())
        base=cfg['test_bases'][r['split']]
        assert base<=r['seed']<base+cfg['test_n']
        if 'trace' not in r:continue
        y=r['trace']['stream'][1:]
        for arm,p in r['trace']['forecasts'].items():
            brier=statistics.mean((q-a)**2 for q,a in zip(p,y))
            loss=statistics.mean(-math.log(q if a else 1-q) for q,a in zip(p,y))
            for name,value in [('brier',brier),('bce',loss)]:assert abs(value-r['metrics']['overall'][arm][name])<1e-12
            digest=hashlib.sha256(json.dumps(p,separators=(',',':')).encode()).hexdigest()
            assert digest==r['forecast_sha256'][arm]
            trace_checks+=1
    summary_checks=0
    for split,data in result['summary'].items():
        rr=[r for r in rows if split=='combined' or r['split']==split]
        for contrast,metrics in data['scenario_average'].items():
            arm,comp=contrast.split('-minus-')
            for metric,rec in metrics.items():
                grouped=defaultdict(list)
                for r in rr:grouped[r['seed']].append(r['metrics']['overall'][arm][metric]-r['metrics']['overall'][comp][metric])
                means=[statistics.mean(v) for v in grouped.values()]
                assert abs(statistics.mean(means)-rec['mean'])<1e-14
                assert abs(statistics.stdev(means)-rec['sd'])<1e-14
                summary_checks+=1
    counts={}
    for name in ['test_phase29_engine','test_benchmark','test_phase210']:
        text=(ROOT/'logs'/f'{name}.log').read_text();match=re.search(r'Ran (\d+) tests?',text)
        assert match and '\nOK\n' in text
        counts[name]=int(match.group(1))
    combined=result['summary']['combined']
    negative_banks=all(result['summary'][split]['scenario_average']['adaptive-minus-fixed']['brier']['mean']<0 for split in cfg['test_bases'])
    report={'audited_at':datetime.now(timezone.utc).isoformat(),'status':'pass','frozen_files_unchanged':frozen,
        'original_sources_unchanged':originals,'copied_sources_identical':copies,'test_counts':counts,
        'total_tests':sum(counts.values()),'raw_paths':len(rows),'full_trace_arm_checks':trace_checks,
        'scenario_average_arithmetic_checks':summary_checks,'new_seed_sets_disjoint_from_known_p29':True,
        'selection_reproduced':recomputed_selection,'negative_direction_both_banks':negative_banks,
        'prespecified_joint_success':combined['decision']['primary_superiority'] and combined['decision']['harm_guardrail_pass'] and negative_banks,
        'note':'Artifact/arithmetic checks, not independent model implementation or new empirical replication.'}
    (ROOT/'results/audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if not isinstance(v,dict)},indent=2))

if __name__=='__main__':main()
