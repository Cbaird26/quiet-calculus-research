"""Frozen fresh-path adaptive-memory test. Standard library; no network."""
from collections import defaultdict
from dataclasses import asdict
from datetime import datetime,timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import time
import benchmark_phase29 as b

ROOT=b.ROOT
CONFIG=json.loads((ROOT/'protocol.json').read_text())
m=b.module('fresh_experiment_phase210',ROOT/'corrected/phase2_10_adaptive_memory.py')

def save(path,obj):
    path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_frozen():
    freeze=json.loads((ROOT/'freeze.json').read_text())
    for name,h in freeze['files'].items():
        if digest(ROOT/name)!=h:raise AssertionError('frozen file changed: '+name)
    return digest(ROOT/'freeze.json')

def create(kind,fit,h=None):
    if kind=='p29_share_gap':e=b.p29.Phase29Engine(share_rate=.02,gap_reset=12)
    elif kind=='p29_ttl':e=b.p29.Phase29Engine(ttl=90)
    else:
        kw={'replacement':'none','hazards':tuple(CONFIG['hazards']),'meta_share':.01,'max_snapshots':8}
        if kind=='fixed':kw['hazards']=(h,)
        if kind=='uniform':kw['meta_mode']='uniform'
        if kind=='no_memory':kw['memory_enabled']=False
        if kind=='adaptive_fifo':kw['replacement']='fifo'
        if kind=='adaptive_utility':kw['replacement']='utility'
        e=m.Phase210Engine(**kw)
    e.initialize(fit.p11,fit.p01,fit.marginal)
    return e

def bank(e):return [(s.p11,s.p01,s.born) for s in e.archive]

def run_arm(obj,stream):
    started=time.perf_counter();path=[];base=[];max_archive=0
    for x,y in zip(stream[:-1],stream[1:]):
        before=obj.predict_proba(x);issued=obj.step_update(x,y)
        assert before==issued,'outcome-dependent emitted forecast'
        path.append(issued);base.append(obj.last_step['base_prediction'])
        max_archive=max(max_archive,len(obj.archive))
    elapsed=time.perf_counter()-started
    return path,base,bank(obj),{'wall_seconds':elapsed,'max_archive':max_archive,
        'admissions':getattr(obj,'stats',{}).get('admissions'),
        'replacements':getattr(obj,'stats',{}).get('replacements')}

def intervals(xs,alpha=.05):
    n=len(xs);mu=statistics.mean(xs);sd=statistics.stdev(xs);se=sd/math.sqrt(n)
    z=statistics.NormalDist().inv_cdf(1-alpha/2)
    return {'n':n,'mean':mu,'sd':sd,'ci95':[mu-z*se,mu+z*se],
        'upper_one_sided_95':mu+statistics.NormalDist().inv_cdf(.95)*se}

def validation():
    started=time.perf_counter();raw=[]
    for name in CONFIG['scenarios']:
        for seed in range(CONFIG['validation_base'],CONFIG['validation_base']+CONFIG['validation_n']):
            _,fit,stream=b.datasets(name,seed)
            for h in CONFIG['hazards']:
                path,_,_,timing=run_arm(create('fixed',fit,h),stream)
                raw.append({'scenario':name,'seed':seed,'hazard':h,**b.p25.score(stream[1:],path),**timing})
        print('Validation complete:',name,flush=True)
    means={str(h):statistics.mean(r['brier'] for r in raw if r['hazard']==h) for h in CONFIG['hazards']}
    selected=min(CONFIG['hazards'],key=lambda h:means[str(h)])
    result={'selected_hazard':selected,'criterion':'equal scenario-weighted mean Brier; first hazard wins exact tie',
        'candidate_means':means,'raw':raw,'elapsed_seconds':time.perf_counter()-started,
        'sealed_before_test':datetime.now(timezone.utc).isoformat(),'freeze_sha256':verify_frozen()}
    save(ROOT/'results/validation.json',result)
    (ROOT/'results/validation.sha256').write_text(digest(ROOT/'results/validation.json')+'\n')
    print('Validation selected',selected,'sealed',digest(ROOT/'results/validation.json'),flush=True)
    return selected

def one_path(name,seed,selected,keep_trace=False):
    schedule,fit,stream=b.datasets(name,seed);scopes,_=b.slices(schedule,stream)
    arms=CONFIG['arms'];forecasts={};bases={};archives={};timings={}
    for arm in arms:
        forecasts[arm],bases[arm],archives[arm],timings[arm]=run_arm(create(arm,fit,selected),stream)
    assert all(p==forecasts['no_memory'] for p in bases.values()),'shadow base differs'
    common=['adaptive','fixed','uniform','no_memory','p29_share_gap','p29_ttl']
    assert all(archives[a]==archives['adaptive'] for a in common),'common archive differs'
    metrics={scope:{a:b.p25.score([stream[i+1] for i in ids],[path[i] for i in ids])
        for a,path in forecasts.items()} for scope,ids in scopes.items()}
    row={'scenario':name,'seed':seed,'training':asdict(fit),'metrics':metrics,'timing':timings,
        'forecast_sha256':{a:b.path_hash(p) for a,p in forecasts.items()},
        'identity':{'all_bases_exact':True,'common_no_replacement_archives':True},
        'final_archives':archives}
    if keep_trace:row['trace']={'stream':stream,'forecasts':forecasts,'schedule':[asdict(v) for v in schedule]}
    return row

def summarize(rows):
    out={}
    contrasts=[('adaptive','fixed'),('adaptive','no_memory'),('adaptive','uniform'),
        ('adaptive_fifo','adaptive'),('adaptive_utility','adaptive'),('p29_share_gap','no_memory'),('p29_ttl','no_memory')]
    for split in [*CONFIG['test_bases'],'combined']:
        rr=[r for r in rows if split=='combined' or r['split']==split]
        out[split]={'scenarios':{},'scenario_average':{}}
        for name in CONFIG['scenarios']:
            ss=[r for r in rr if r['scenario']==name]
            entry={'absolute':{a:{metric:intervals([r['metrics']['overall'][a][metric] for r in ss])
                for metric in ['brier','bce']} for a in CONFIG['arms']},'contrasts':{}}
            for a,c in contrasts:
                entry['contrasts'][a+'-minus-'+c]={metric:intervals([r['metrics']['overall'][a][metric]-r['metrics']['overall'][c][metric] for r in ss]) for metric in ['brier','bce']}
            out[split]['scenarios'][name]=entry
        for a,c in contrasts:
            out[split]['scenario_average'][a+'-minus-'+c]={}
            for metric in ['brier','bce']:
                by_seed=defaultdict(list)
                for r in rr:by_seed[r['seed']].append(r['metrics']['overall'][a][metric]-r['metrics']['overall'][c][metric])
                assert all(len(v)==len(CONFIG['scenarios']) for v in by_seed.values())
                out[split]['scenario_average'][a+'-minus-'+c][metric]=intervals([statistics.mean(v) for v in by_seed.values()])
        primary=out[split]['scenario_average']['adaptive-minus-fixed']['brier']
        z=statistics.NormalDist().inv_cdf(1-.05/len(CONFIG['scenarios']))
        worst={name:entry['contrasts']['adaptive-minus-fixed']['brier']['mean']+
            z*entry['contrasts']['adaptive-minus-fixed']['brier']['sd']/math.sqrt(entry['contrasts']['adaptive-minus-fixed']['brier']['n'])
            for name,entry in out[split]['scenarios'].items()}
        out[split]['decision']={'mean_brier_minimum_effect':CONFIG['minimum_brier_effect'],
            'primary_superiority':primary['upper_one_sided_95'] < -CONFIG['minimum_brier_effect'],
            'scenario_harm_margin':CONFIG['scenario_harm_margin'],
            'bonferroni_upper_bounds':worst,'harm_guardrail_pass':max(worst.values())<CONFIG['scenario_harm_margin'],
            'worst_mean_scenario':max(CONFIG['scenarios'],key=lambda n:out[split]['scenarios'][n]['contrasts']['adaptive-minus-fixed']['brier']['mean'])}
    return out

def main():
    start=time.perf_counter();freeze_hash=verify_frozen();selected=validation();rows=[]
    rawfile=ROOT/'results/raw_paths.jsonl'
    if rawfile.exists():raise RuntimeError('Refuse to overwrite existing test results')
    with rawfile.open('x') as fp:
        for split,base in CONFIG['test_bases'].items():
            for name in CONFIG['scenarios']:
                for seed in range(base,base+CONFIG['test_n']):
                    row={'split':split,**one_path(name,seed,selected,keep_trace=(name=='mixed_9' and seed==base))}
                    fp.write(json.dumps(row,separators=(',',':'),allow_nan=False)+'\n');fp.flush();rows.append(row)
                print('Test complete:',split,name,CONFIG['test_n'],flush=True)
    report={'status':'complete','freeze_sha256':freeze_hash,'selected_hazard':selected,'paths':len(rows),
        'validation_sha256':digest(ROOT/'results/validation.json'),'raw_sha256':digest(rawfile),
        'elapsed_seconds':time.perf_counter()-start,'summary':summarize(rows),
        'timings':{a:sum(r['timing'][a]['wall_seconds'] for r in rows) for a in CONFIG['arms']},
        'all_identity_checks_pass':all(all(r['identity'].values()) for r in rows),
        'limitations':CONFIG['limitations']}
    assert verify_frozen()==freeze_hash
    save(ROOT/'results/summary.json',report)
    lines=['Fresh adaptive-memory evaluation','Selected hazard: '+str(selected),'Scored paths: '+str(len(rows)),
        'Elapsed seconds: '+str(report['elapsed_seconds']), 'Primary contrast adaptive minus validation-selected fixed; negative is better.']
    for split,data in report['summary'].items():
        lines.append(split+': '+json.dumps(data['scenario_average']['adaptive-minus-fixed']['brier']))
        lines.append('Decision: '+json.dumps(data['decision']))
        for name,e in data['scenarios'].items():lines.append(name+': '+json.dumps(e['contrasts']['adaptive-minus-fixed']['brier']))
    lines+=['Limitations:']+CONFIG['limitations']
    (ROOT/'results/summary.txt').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines[:7]),flush=True)

if __name__=='__main__':main()
