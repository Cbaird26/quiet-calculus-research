Quiet Calculus — fresh bounded local adaptive-memory experiment

This isolated package preserves the original Phase2.9 and Phase2.10 algorithms.
The exact existing Phase2.5 reference dependency makes the isolated Phase2.10
copy runnable. Originals were not edited. No model service, network, installation,
external action, or publication is part of this experiment.

Start with results/summary.txt and results/summary.json after completion.
PROTOCOL.txt and protocol.json define the hypothesis, seeds, candidate grid,
comparators, endpoints, superiority margin and robustness guardrail. freeze.json
hashes those files and executable code before new tests or outcome generation.
source_provenance.json records original paths and SHA256 identities.

Validation selects one fixed hazard using 20 fresh seeds per scenario. Its
selection receipt is saved and hashed before the fresh primary/replication test
banks. All 1100 test paths retain metrics and forecast hashes in raw_paths.jsonl;
the first mixed_9 seed in each bank additionally retains full forecasts.

logs/ contains stdout/stderr for 41 correctness tests and the new experiment.
results/execution_receipt.json contains exact commands, interpreter, platform,
thread limits, exit codes, elapsed times and frozen-file verification.
audit_results.py independently rechecks artifact identities and saved arithmetic;
it is an audit, not an independent algorithm implementation.

Reproduce without overwriting this package:
  python3 -B reproduce_to.py /absolute/path/to/a/new-memory-reproduction-directory

The destination must not exist. This copies the frozen input files, creates
empty results/logs folders, and runs the unchanged frozen command there. Exact
output bytes containing timestamps and wall times need not reproduce, while
the same Python/runtime should reproduce deterministic forecasts and scores.
Do not rerun run_frozen.py inside a completed package: preserve the receipts.

Scientific limits: fresh paths from already known synthetic generators; internal
freeze informed by prior results, not external preregistration; no empirical
inference about consciousness, identity, clinical benefit, or MQGT-SCF physics.
