"""Execute frozen tests and experiment; stop on failure and retain every log."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent

def main():
    freeze=json.loads((ROOT/'freeze.json').read_text())
    for name,h in freeze['files'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h,name
    env=dict(os.environ)
    for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']:env[k]='1'
    receipt={'started_at':datetime.now(timezone.utc).isoformat(),'python':sys.version,'executable':sys.executable,
        'platform':platform.platform(),'cwd':str(ROOT),'freeze_sha256':hashlib.sha256((ROOT/'freeze.json').read_bytes()).hexdigest(),
        'thread_limits':{k:env[k] for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']},'runs':[]}
    target=ROOT/'results/execution_receipt.json'
    for script in ['review/test_phase29_engine.py','review/test_benchmark.py','review/test_phase210.py','review/fresh_experiment.py']:
        cmd=[sys.executable,'-B',script];log=ROOT/'logs'/(Path(script).stem+'.log');start=time.perf_counter()
        with log.open('w') as fp:result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=fp,stderr=subprocess.STDOUT)
        receipt['runs'].append({'command':cmd,'returncode':result.returncode,'elapsed_seconds':time.perf_counter()-start,'log':str(log.relative_to(ROOT))})
        receipt['status']='failed' if result.returncode else 'running'
        target.write_text(json.dumps(receipt,indent=2)+'\n')
        print(script,'exit',result.returncode,'seconds',round(receipt['runs'][-1]['elapsed_seconds'],3),flush=True)
        if result.returncode:sys.exit(result.returncode)
    receipt['status']='complete';receipt['completed_at']=datetime.now(timezone.utc).isoformat()
    receipt['integrity_after']={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h for name,h in freeze['files'].items()}
    assert all(receipt['integrity_after'].values())
    target.write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':main()
