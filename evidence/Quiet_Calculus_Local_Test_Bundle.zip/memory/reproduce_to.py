"""Reproduce in a NEW directory, leaving the sealed completed results untouched."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('destination',type=Path)
    args=parser.parse_args()
    source=Path(__file__).resolve().parent
    dest=args.destination.expanduser().resolve()
    if dest.exists():raise SystemExit('Destination must not exist')
    freeze=json.loads((source/'freeze.json').read_text())
    dest.mkdir(parents=True)
    for name in [*freeze['files'],'freeze.json','freeze.sha256']:
        target=dest/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source/name,target)
    (dest/'results').mkdir();(dest/'logs').mkdir()
    raise SystemExit(subprocess.call([sys.executable,'-B','run_frozen.py'],cwd=dest))

if __name__=='__main__':main()
