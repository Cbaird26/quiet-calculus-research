#!/usr/bin/env python3
"""Independent arithmetic audit of saved outputs; no experiment or inference rerun."""
from pathlib import Path
from collections import defaultdict
from statistics import mean,stdev,NormalDist
import json,math,hashlib
ROOT=Path(__file__).resolve().parent
clusters=defaultdict(list);scenarios=defaultdict(list)
for line in (ROOT/'memory/results/raw_paths.jsonl').read_text().splitlines():
 r=json.loads(line);d=r['metrics']['overall']['adaptive']['brier']-r['metrics']['overall']['fixed']['brier'];clusters[(r['split'],r['seed'])].append(d);scenarios[r['scenario']].append(d)
assert len(clusters)==100 and all(len(v)==11 for v in clusters.values())
x=[mean(v) for v in clusters.values()];mu=mean(x);se=stdev(x)/math.sqrt(len(x));z=NormalDist().inv_cdf(.975);ci=[mu-z*se,mu+z*se]
summary=json.loads((ROOT/'memory/results/summary.json').read_text())['summary']['combined']
expected=summary['scenario_average']['adaptive-minus-fixed']['brier'];assert abs(mu-expected['mean'])<1e-15;assert max(abs(a-b) for a,b in zip(ci,expected['ci95']))<1e-15
bonf=NormalDist().inv_cdf(1-.05/len(scenarios));bounds={k:mean(v)+bonf*stdev(v)/math.sqrt(len(v)) for k,v in scenarios.items()}
for k,v in bounds.items():assert abs(v-summary['decision']['bonferroni_upper_bounds'][k])<1e-15
report={'memory_clusters':len(clusters),'scenario_paths':sum(len(v) for v in clusters.values()),'memory_mean':mu,'memory_ci95':ci,'summary_arithmetic_matches':True,'memory_minimum_effect_gate':mu+NormalDist().inv_cdf(.95)*se<-.0005,'memory_harm_guardrail':max(bounds.values())<.001,'memory_max_simultaneous_upper_bound':max(bounds.values()),'scope':'Independent recomputation from saved per-path metrics; not independent regenerated forecasts'}
portal=json.loads((ROOT/'portal/results.json').read_text());follow=json.loads((ROOT/'portal/followup_results.json').read_text())
assert len(portal['radial_cases'])==56
assert len(portal['radial_summary']['failed_cases'])==9
assert not portal['all_planned_checks_passed']
assert follow['summary']['phase_reference_all_converged'] and not follow['summary']['original_energy_above_1e7_cases']
report.update(portal_initial_failure_preserved=True,portal_exploratory_followup_separate=True)
(ROOT/'aggregate_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
