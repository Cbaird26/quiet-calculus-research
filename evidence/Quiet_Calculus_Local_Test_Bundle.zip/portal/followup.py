from pathlib import Path
import json,math,time,warnings,importlib.util
import numpy as np
from scipy.integrate import quad,IntegrationWarning
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('inherited',ROOT/'inherited/check_quadratic_bridge.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
start=time.perf_counter();initial=json.loads((ROOT/'results.json').read_text());rows=[]
def phase_quad(a,b,order):
 if b==0:return 0.
 km=math.sqrt((a+80)**2-a*a);width=min(.25,math.pi/(4*b));x,w=np.polynomial.legendre.leggauss(order)
 edges=np.linspace(0,km,int(math.ceil(km/width))+1);half=np.diff(edges)/2;k=((edges[:-1]+half)[:,None]+half[:,None]*x).ravel();weights=(half[:,None]*w).ravel()
 e=np.hypot(k,a);v=k*b;u2=v*v;phase=np.where(abs(v)<.02,u2/3-2*u2**2/45+u2**3/315,1-np.sinc(v/np.pi)**2)
 y=k**3/e*np.exp(a-e)/(-np.expm1(-e))**2*phase
 return float(np.dot(weights,y)/(2*np.pi**3))
def weighted(a,b):
 km=math.sqrt((a+80)**2-a*a)
 def f(k):
  e=math.hypot(k,a);return k/e*math.exp(a-e)/(-math.expm1(-e))**2
 with warnings.catch_warnings(record=True) as ws:
  warnings.simplefilter('always',IntegrationWarning)
  cs,er=quad(f,0,km,weight='cos',wvar=2*b,epsabs=1e-12,epsrel=1e-12,limit=2000)
 return old.closed_local(a)-(1/(-math.expm1(-a))-cs)/(4*math.pi**3*b*b),[str(w.message) for w in ws]
for row in initial['radial_cases']:
 a,b=row['a'],row['b'];s0=row['local_spectrum'];v16=phase_quad(a,b,16);v32=phase_quad(a,b,32)
 r={'a':a,'b':b,'scaled_phase_reference':v32,'phase_order_difference_over_S00':abs(v32-v16)/s0,'phase_reference_converged':abs(v32-v16)/s0<1e-10,'initial_adaptive_difference_over_S00':abs(row['scaled_reference']-v32)/s0,'original_energy_difference_over_S00':abs(row['scaled_inherited']-v32)/s0}
 if b>=10:
  v,w=weighted(a,b);r.update(weighted_cosine_difference_over_S00=abs(v-v32)/s0,weighted_cosine_warnings=w)
 rows.append(r)
for width in [.125,.03125]:
 old.U,old.UW=old.quadrature_grid(100,width=width,order=96)
 for row in rows:
  a,b=row['a'],row['b'];v=old.energy_spectrum(a,b,True);s0=old.closed_local(a)
  row[f'energy_width_{width}_difference_over_S00']=abs(v-row['scaled_phase_reference'])/s0
summary={'case_count':56,'phase_reference_all_converged':all(r['phase_reference_converged'] for r in rows),'max_phase_order_difference':max(r['phase_order_difference_over_S00'] for r in rows),'weighted_cosine_cases':sum('weighted_cosine_difference_over_S00' in r for r in rows),'max_weighted_cosine_difference':max(r.get('weighted_cosine_difference_over_S00',0) for r in rows),'weighted_cosine_warnings':sum(len(r.get('weighted_cosine_warnings',[])) for r in rows),'max_original_energy_difference':max(r['original_energy_difference_over_S00'] for r in rows),'original_energy_above_1e7_cases':[r for r in rows if r['original_energy_difference_over_S00']>1e-7],'max_initial_adaptive_difference':max(r['initial_adaptive_difference_over_S00'] for r in rows),'max_refined_energy_difference':max(r['energy_width_0.03125_difference_over_S00'] for r in rows),'elapsed_seconds':time.perf_counter()-start}
(ROOT/'followup_results.json').write_text(json.dumps({'status':'exploratory numerical diagnosis after initial failures','summary':summary,'rows':rows},indent=2)+'\n');print(json.dumps(summary,indent=2))
