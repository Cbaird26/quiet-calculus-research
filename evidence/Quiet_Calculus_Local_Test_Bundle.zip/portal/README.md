# Conditional portal and dephasing computation

All outputs are numerical model checks, not physical evidence.

The initial frozen run executes the unchanged inherited portal script, 56 wider radial-reference comparisons, 12 spatial-covariance fixtures, 960 density-matrix configurations, and explicit negative controls. Nine initial radial comparisons were not certified because the adaptive reference emitted warnings. Keep `results.json` and its failed flags intact.

The separately frozen exploratory follow-up uses phase-aware radial Gauss quadrature and weighted-cosine integration. It attributes the largest mismatch to the adaptive reference; both initial methods contribute in the other above-tolerance comparison. All original energy-grid comparisons lie within the declared tolerance against the resolved reference. Refinement gives tighter agreement. This does not turn the original warning-bearing protocol into an all-pass execution.

## Reproduce in a new copy

Requires Python, NumPy, SciPy and mpmath. Exact runtime/version information is in results.json. Source check hash is in freeze.json. Commands used:

```sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python run_tests.py
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python followup.py
```

Run `followup.py` after `run_tests.py`; it explicitly reads the first results. Use a new folder to preserve delivered artifacts. No network, plotting runtime or source PDF is needed. The inherited checker writes only within its copied folder. Fresh physical data, bath calibration, apparatus mapping, and a joint observational likelihood are absent.
