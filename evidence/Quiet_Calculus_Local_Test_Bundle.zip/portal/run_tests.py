#!/usr/bin/env python3
"""Frozen local model checks. Requires numpy, scipy, mpmath. No network."""
from pathlib import Path
import sys,json,math,time,hashlib,subprocess,warnings,importlib.util,platform
import numpy as np
import scipy
from scipy.integrate import quad,IntegrationWarning
from scipy.linalg import expm
import mpmath
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('inherited',ROOT/'inherited/check_quadratic_bridge.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
start=time.perf_counter()
run=subprocess.run([sys.executable,str(ROOT/'inherited/check_quadratic_bridge.py')],cwd=ROOT/'inherited',capture_output=True,text=True)
(ROOT/'inherited_run.log').write_text(run.stdout+run.stderr)

def diff_sinc2(u):
    if abs(u)<.02:
        v=u*u;return v/3-2*v*v/45+v*v*v/315
    return 1-(math.sin(u)/u)**2

def radial(a,b,tol):
    if b==0:return 0.,0.,[]
    km=math.sqrt((a+80)**2-a*a)
    def f(k):
        e=math.hypot(k,a);occ=math.exp(a-e)/(-math.expm1(-e))**2
        return k**3/e*occ*diff_sinc2(k*b)/(2*math.pi**3)
    with warnings.catch_warnings(record=True) as ws:
        warnings.simplefilter('always',IntegrationWarning)
        val,err=quad(f,0,km,epsabs=tol,epsrel=1e-11,limit=2000)
    return val,err,[str(w.message) for w in ws]
rows=[]
for a in [.01,.1,.3,1.,3.,10.,30.,100.]:
    s0=old.closed_local(a)
    for b in [0.,1e-6,.001,.1,1.,10.,50.]:
        ref,err,ws=radial(a,b,1e-12);lo,errlo,wslo=radial(a,b,1e-10)
        v=old.energy_spectrum(a,b,True)
        rows.append({'a':a,'b':b,'scaled_reference':ref,'scaled_inherited':v,'local_spectrum':s0,'normalized_rate':ref/s0,'normalized_disagreement':abs(v-ref)/s0,'normalized_reference_resolution':abs(lo-ref)/s0,'quad_error_estimate':err,'warnings':ws+wslo,'reference_converged':abs(lo-ref)/s0<1e-8 and not(ws or wslo),'inherited_agreement_pass':abs(v-ref)/s0<1e-7})
    print('radial grid a=',a,flush=True)
rng=np.random.default_rng(2026102501);covs=[]
for a in [.1,1.,10.]:
    s0=old.energy_spectrum(a)
    for j in range(4):
        x=rng.normal(size=(12,3));dist=np.linalg.norm(x[:,None,:]-x[None,:,:],axis=2)
        cov=np.array([[old.energy_spectrum(a,float(d)) for d in row] for row in dist])/s0
        mineig=float(np.linalg.eigvalsh(cov).min());covs.append({'a':a,'seed_index':j,'normalized_min_eigenvalue':mineig,'pass':mineig>=-1e-11})
Z=np.diag([1.,-1.]);I=np.eye(4);L0=(np.kron(Z,Z)-I)/2
states=[]
for _ in range(64):
    a=rng.normal(size=(2,2))+1j*rng.normal(size=(2,2));rho=a@a.conj().T;states.append(rho/np.trace(rho))
errors={'trace':0.,'populations':0.,'kraus_expm':0.};mineig=1.;cases=0
for lam in [0.,.03,.7,3.,20.]:
    for tau in [.1,1.,5.]:
        propagator=expm(lam*tau*L0);v=math.exp(-lam*tau)
        for rho in states:
            exact=(propagator@rho.flatten(order='F')).reshape(2,2,order='F')
            kraus=(1+v)/2*rho+(1-v)/2*Z@rho@Z
            errors['trace']=max(errors['trace'],float(abs(np.trace(exact)-1)))
            errors['populations']=max(errors['populations'],float(np.max(abs(np.diag(exact)-np.diag(rho)))))
            errors['kraus_expm']=max(errors['kraus_expm'],float(np.max(abs(exact-kraus))))
            mineig=min(mineig,float(np.linalg.eigvalsh(exact).min()));cases+=1
plus=np.ones((2,2))/2
neg=(expm(-.7*L0)@plus.flatten(order='F')).reshape(2,2,order='F')
neg_eig=float(np.linalg.eigvalsh(neg).min())
def amplitude(lam):
    q=math.exp(-lam);k0=np.diag([1,math.sqrt(q)]);k1=np.array([[0,math.sqrt(1-q)],[0,0]])
    return k0@plus@k0.T+k1@plus@k1.T
ampdiff=float(abs(amplitude(.4)[0,0]-amplitude(.8)[0,0]))
lam=.7;tau=1.2;theta=.3;v=math.exp(-lam*tau);c=math.cos(theta)
fisher=tau*tau*v*v*c*c/(1-v*v*c*c)
def readout(l):return (1+math.exp(-l*tau)*c)/2
h=1e-5;dp=(readout(lam+h)-readout(lam-h))/(2*h);p=readout(lam);fd=dp*dp/(p*(1-p))
ref,_,_=radial(1,1,1e-12);wrong=old.energy_spectrum(1,1,True)/4
negative={'negative_rate_min_eigenvalue':neg_eig,'negative_rate_detected':neg_eig < -1e-3,'amplitude_population_difference':ampdiff,'amplitude_control_detected':ampdiff>1e-3,'quarter_vertex_relative_error':abs(wrong-ref)/ref,'normalization_control_detected':abs(wrong-ref)/ref>.7}
failed=[r for r in rows if not r['reference_converged'] or not r['inherited_agreement_pass']]
report={'scope':'Computational model checks, no physical evidence or new field detection','python':sys.version,'executable':sys.executable,'versions':{'numpy':np.__version__,'scipy':scipy.__version__,'mpmath':mpmath.__version__},'inherited_run_return_code':run.returncode,'radial_cases':rows,'radial_summary':{'count':len(rows),'failed_cases':failed,'max_normalized_disagreement':max(r['normalized_disagreement'] for r in rows),'max_reference_resolution_difference':max(r['normalized_reference_resolution'] for r in rows)},'covariance_cases':covs,'density_matrix_checks':{'count':cases,'maximum_errors':errors,'minimum_eigenvalue':mineig,'pass':max(errors.values())<1e-12 and mineig>=-1e-12,'interference_fisher':fisher,'finite_difference_fisher':fd,'fisher_derivative_pass':abs(fisher-fd)<1e-8},'negative_controls':negative,'elapsed_seconds':time.perf_counter()-start}
report['all_planned_checks_passed']=run.returncode==0 and not failed and all(r['pass'] for r in covs) and report['density_matrix_checks']['pass'] and report['density_matrix_checks']['fisher_derivative_pass'] and all(negative[k] for k in ['negative_rate_detected','amplitude_control_detected','normalization_control_detected'])
(ROOT/'results.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['radial_cases','covariance_cases']},indent=2))
