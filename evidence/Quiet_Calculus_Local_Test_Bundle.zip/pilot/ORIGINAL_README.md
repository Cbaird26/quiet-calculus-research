# ZoraASI local integrity pilot

A small, local evidence-review workflow for security advisories and outages. Three roles—collector, verifier, challenger—are compared with a single-pass model using the same frozen evidence. Every output is a draft for human review.

This folder is a standalone Python project. It does not alter the existing Zora runtime, memory, model weights, automations, or other research directories. Python 3.10+ and an existing local Ollama installation are sufficient; there are no third-party Python dependencies.

## Abstention diagnosis and revision 3

The original verifier matched 17 of 18 provisional labels, while the independent challenger matched 8 of 18 and abstained on 16. Eleven verifier/challenger disagreements forced the aggregate to abstain. In A02 and A05, the challenger explicitly described a contradiction in its reason but returned `insufficient_evidence`. In A04 it demanded independent corroboration of a claim about the publisher's own catalog. In O04 it rejected a documented latest update because it treated the evidence cutoff as an exact publication-time requirement. See the [saved diagnosis](state/diagnostics/20261023T034325Z-4aa912c1/diagnosis.json) and the original report below.

Revision 3 distinguishes evidence that contradicts a claim from credible sources that remain in conflict with each other. It explains when a publisher's record supports a claim about that record, and distinguishes a documented report from an unobserved later real-world state. The challenger performs an independent assessment under the same decision rules as the verifier. Its role does not require doubt when the supplied evidence settles a narrow claim.

Each assessment now emits a short reason, exact citations, and one explicit evidence relation: `entailed`, `contradicted`, or `not_determined`. These map mechanically to `supported`, `refuted`, and `insufficient_evidence`. The program never infers a verdict from prose or consults benchmark labels. This is a combined prompt-and-output-schema revision; this experiment does not isolate the contribution of each change.

The citation validator, admissible-evidence filtering, and disagreement rule are unchanged. All three role responses must validate, and verifier and challenger must agree, before the aggregate retains a definite judgment. Missing evidence, genuine unresolved source conflict, response errors, and unresolved role disagreement still produce abstention.

Before fresh-case selection, both workflows matched all six selected development labels (A02, A04, A06, A09, O04, O06), including the three cases requiring abstention. This was a targeted development check, not independent validation. Its [result](state/benchmarks/20261023T034416Z-30205d0f/report.html) and [29-test receipt](state/diagnostics/20261023T034325Z-4aa912c1/unit-tests-revision3.json) are separate from the original results.

## Fresh comparison design

The [protocol freeze](state/diagnostics/20261023T034325Z-4aa912c1/protocol-freeze.json) records the code hashes, unchanged local model digest, budgets, planned metrics, and selection rule before the new source collection and case generation. Four arms run on identical cases: original single pass, original three roles, revised single pass, and revised three roles. Their order rotates by case. The original code is loaded from a verified copy of its saved snapshot; original result files are not imported or edited in place.

The [fresh dataset](state/diagnostics/20261023T034325Z-4aa912c1/fresh-cases.json) contains twelve constructed claims from four records: two previously unused CISA KEV entries and one component each from GitHub Status and Cloudflare Status. Each record supplies one supported field claim, one explicitly contradicted field claim, and one unsupported outcome claim. Labels and rationales are excluded from every model input. Selection is deterministic and no fresh predictions are used to tune prompts or choose cases.

The new [collection](state/collections/20261023T035101Z-0e7626cc/result.json) fetched all three feeds after the freeze. Its CISA bytes match the earlier capture; both status-feed responses differ. Freshness means a new capture and new claims, not necessarily new incidents. The twelve claims share four records, are deliberately balanced, and have provisional programmatic/author-created labels awaiting independent human review. They do not establish general reliability, confidence calibration, or statistical superiority.

Reproduce the frozen comparison with the existing dataset (this creates a new result directory and performs local inference):

```sh
python3 -m zora_pilot compare \
  --dataset state/diagnostics/20261023T034325Z-4aa912c1/fresh-cases.json \
  --original-run state/benchmarks/20261023T032203Z-c8e2821c \
  --freeze state/diagnostics/20261023T034325Z-4aa912c1/protocol-freeze.json
```

The command rejects a changed protocol, model digest, or dataset-to-freeze binding. Reports retain all responses and errors. New metrics separate unnecessary abstention on answerable labels from incorrect definite judgments, so a reduction in abstention alone is not treated as success. Original pre-change artifacts are inventoried in [original-artifacts.json](state/diagnostics/20261023T034325Z-4aa912c1/original-artifacts.json); their preservation is checked with SHA-256.

## Fresh comparison results

The frozen comparison finished at 04:17 UTC on 23 October 2026, after the Codex session that started it had stopped. This summary was added afterwards by Claude (Anthropic) from the saved result; nothing was rerun or edited. Open the [comparison report](state/comparisons/20261023T035112Z-4b0d424e/report.html) or the [complete record](state/comparisons/20261023T035112Z-4b0d424e/result.json) (SHA-256 `29eb75e8cc990971051878c4a892e249f5a7e4d9dcd4e91b87ec2200549d3c54`, matching `result.sha256`). Model `zora:fast`, twelve claims from four records, identical cases in all four arms.

| Measure | Original single pass | Original three roles | Revised single pass | Revised three roles |
| --- | ---: | ---: | ---: | ---: |
| Matches to provisional labels | 5 / 12 | 4 / 12 | 12 / 12 | 11 / 12 |
| Unnecessary abstentions | 7 | 8 | 0 | 0 |
| Incorrect definite judgments | 0 | 0 | 0 | 0 |
| False confirmations | 0 | 0 | 0 | 0 |
| Decisive coverage | 0.083 | 0.000 | 0.667 | 0.667 |
| Appropriate abstention recall | 1.00 | 1.00 | 1.00 | 0.75 |
| Verifier/challenger disagreements | 0 | 8 | 0 | 1 |
| Processing errors | 0 | 0 | 0 | 1 |
| Reported input + output tokens | 13,090 | 40,588 | 14,776 | 46,948 |
| Wall time | 166 s | 552 s | 204 s | 675 s |

On these claims, revision 3 removed the unnecessary abstentions in both workflows (7 to 0 and 8 to 0) without adding a false confirmation or an incorrect definite judgment. The single revised three-role miss is a processing error, not a wrong verdict: on the CVE-2026-96652 remediation claim one role reached its 256-token cap (`incomplete_generation`), which the protocol counts as a failure rather than an abstention. The three-role workflow again added no accuracy over the single pass and used about 3.2 times the tokens and time.

These twelve claims are correlated (three per record), deliberately balanced, and carry provisional programmatic or author-created labels that no human has reviewed. They are not an independent holdout and do not establish general reliability, calibration, or superiority. The result stays a local draft pending human review (`python3 -m zora_pilot review ...`, below).

Preservation check, 23 October 2026: all 37 original pre-change artifacts listed in [original-artifacts.json](state/diagnostics/20261023T034325Z-4aa912c1/original-artifacts.json) still match their recorded SHA-256 values, and the 29 unit tests pass offline.

## First completed development run

Open the [local benchmark report](state/benchmarks/20261023T032203Z-c8e2821c/report.html) or its [complete evidence and inference record](state/benchmarks/20261023T032203Z-c8e2821c/result.json).

| Observed measure | Three roles | Single pass |
| --- | ---: | ---: |
| Matches to provisional labels | 8 / 18 | 9 / 18 |
| Definite judgments | 2 / 18 | 3 / 18 |
| False confirmations | 0 | 0 |
| JSON/citation validation failures | 0 | 0 |
| Reported input + output tokens | 35,176 | 10,948 |
| Total assessment time | 615.99 s | 190.44 s |

The three-role workflow did not improve this development result and used about 3.2 times the tokens and time. Both approaches abstained excessively, including on all six provisionally refuted claims. Zero false confirmations must be read alongside their low decisive coverage. These are synthetic, unreviewed development labels; the results do not establish general performance. All reports remain pending human review. The test receipt is in [state/validation/unit-tests.json](state/validation/unit-tests.json).

The [live-feed smoke-test report](state/evaluations/20261023T033530Z-988571eb/report.html) evaluates one captured claim each from CISA, GitHub Status and Cloudflare Status. All three feeds fetched successfully and all three evaluations completed without processing errors. The workflow retained the GitHub publisher-report claim as supported; CISA and Cloudflare had verifier/challenger disagreements and remain unresolved. These are automated draft assessments, not human approvals or independently verified service diagnoses.

## Boundaries

- Public network access consists only of GET requests to three fixed feeds, explicitly enabled with `collect --online`.
- Inference uses `http://127.0.0.1:11434` and an already installed local model. No model downloads, cloud fallback, API keys, or remote inference endpoints.
- Source content is untrusted data. Agents receive no tools, shell access, browsing, filesystem access, or credentials.
- No accounts, messages, posts, scanning of machines, exploit execution, deployment, or publishing are implemented.
- Local writes are limited to this project’s artifacts. CLI-created state uses private file permissions.
- A local review command records a human’s decision against a result hash. Approval does not publish or authorize an external action. This is an attestation workflow, not an identity-verification system.

“Read-only” refers to external systems. Saving local evidence snapshots, inference traces and review records is necessary for the pilot.

## Run it

Run commands from this directory:

```sh
cd /Users/christophermichaelbaird/Documents/ChatGPT/ZoraASI/zora_integrity_pilot
python3 -m zora_pilot doctor
python3 -m unittest discover -s tests -v
python3 -m zora_pilot benchmark --model zora:fast
```

The default is the already installed `zora:fast` model. An initial `zora:core` trial produced malformed JSON with a trailing control token in collector responses; that incomplete run is retained under `state/benchmarks/20261023T031620Z-eeaf78d6/`. The parser was not loosened to accept it. Both arms in a comparison always use the same selected model.

The benchmark is offline except for loopback inference. Default timeout is 120 seconds per model call; there are no automatic retries that would silently expand the budget. `--timeout` supports 1–300 seconds. There are 72 calls in the full 18-case comparison. Runtime depends on local model load and machine contention. Results and per-case progress are written under `state/benchmarks/`. A stopped process leaves `progress.json`; it is not a completed result. Rerun a selected subset into a new run if needed:

```sh
python3 -m zora_pilot benchmark --case-ids A01 A02 A03 O01 O02 O03
```

Collect current publisher reports:

```sh
python3 -m zora_pilot collect --online
```

The command prints a collection directory and the status of each source. Pass that exact directory to evaluate its frozen contents:

```sh
python3 -m zora_pilot evaluate /absolute/path/to/collection
python3 -m zora_pilot evaluate /absolute/path/to/collection --case-ids github-status-summary
```

To investigate a different claim, copy one case object from a collection into a local JSON file, edit its `claim` and `id`, and keep the source evidence and timestamps intact. Then run:

```sh
python3 -m zora_pilot assess /absolute/path/to/claim.json
```

This evaluates the supplied evidence locally; it never fetches the URLs in the file. It does not require a gold label. Source origins in manually assembled files require human verification. Collection-generated claims are deliberately narrow transcriptions of publisher reports, not an autonomous rumor-monitoring system.

Results include `report.html`, `result.json`, and `result.sha256`. The HTML is a self-contained, escaped, script-free local review document. `result.json` includes the complete case data, source metadata, prompts, model digest, responses, validation errors and timing. Do not rely on the HTML alone for artifact integrity:

```sh
python3 -m zora_pilot inspect /absolute/path/to/run
```

If a source fetch fails, the collection retains `fetch_error` and the CLI exits with code 2. Other successful source snapshots remain available. Missing coverage never becomes a claim that services are healthy. Model errors also cause exit code 2 after the completed comparison is saved.

## What the roles do

| Role | Input | Output |
| --- | --- | --- |
| Collector | Exact claim and eligible frozen source text | Relevant observations, exact citations, gaps and source dependencies |
| Verifier | Same evidence plus collector observations | `supported`, `refuted`, or `insufficient_evidence`, with short reasoning and citations |
| Challenger | Same original evidence; no verifier verdict or collector output | Independent assessment seeking contradictions, scope errors, stale evidence and unsupported inference |
| Single-pass baseline | Same original evidence | One assessment instructed to collect, verify and challenge in one pass |

These are three isolated invocations of one local model, not three independently trained models. The collector can help orient the verifier but cannot add sources. A matching verifier/challenger verdict is retained as a provisional assessment. Disagreement produces `insufficient_evidence` while preserving both assessments. There is no negotiation loop or majority vote. This conservative rule can raise abstention and reduce useful coverage; both are measured.

Every definite judgment must include an exact, nonempty quotation from a known source ID. Unknown citations, fabricated quotes, truncated generations and malformed responses fail validation. This checks traceability only: an exact quotation can still be irrelevant or fail to support the conclusion. A human must assess semantic support.

Operational incident status remains inside the claim/evidence. An incident can be confirmed as reported and also resolved; these are separate concepts.

## Sources and collection scope

| Source | Captured data | Scope |
| --- | --- | --- |
| [CISA KEV JSON](https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json) | Complete raw catalog; three most recently added entries become candidate claims | Whether CISA lists a vulnerability as known exploited; not a full vendor advisory feed or exhaustive inventory |
| [GitHub status summary](https://www.githubstatus.com/api/v2/summary.json) | Raw summary, overall indicator/count, up to two unresolved incidents | What GitHub currently reports about its own services |
| [Cloudflare status summary](https://www.cloudflarestatus.com/api/v2/summary.json) | Raw summary, overall indicator/count, up to two unresolved incidents | What Cloudflare currently reports about its own services |

Source URLs cannot be selected by model output. Redirects and environment proxies are disabled. Requests have bounded size and socket timeouts. No URLs embedded in a feed are followed. Feed schema/identity failures are explicit errors. A status feed with zero incidents only supports a statement about that feed, not the absence of all service failures.

Raw response bytes and normalized evidence text each have SHA-256 hashes. Result hashes detect ordinary edits; they are not signatures, immutable audit infrastructure, or evidence of truth. Someone with filesystem access can rewrite both data and hashes. Keep this folder private until a human has reviewed what would be shared.

## Benchmark design and limits

`data/seed-v1.json` contains 18 fictional diagnostic cases: nine advisory cases and nine outage cases, balanced across the three verdicts. It includes later snapshots, stale status, source mirrors, speculative exploitation, regional/global scope mistakes and an embedded instruction attack. All source URLs use the reserved `.invalid` domain and are never fetched. `zora_pilot/seed.py` defines the fixtures.

Labels and examples were authored together. They have **not** been independently reviewed; the set is **not** a historical benchmark, an independent holdout, a representative sample, or evidence of real-world reliability. Paired cases share templates. Initial cases were used to debug model integration and refine the prompts. The incomplete `zora:fast` compatibility trial is retained in `state/benchmarks/20261023T031936Z-62b47c66/`. Prompt revision 2 clarifies publisher-statement scope and constrains citation output to exact source excerpts. Treat the completed run as a development diagnostic, and preserve failures without rewriting the fixtures to improve scores.

The comparison uses the same model, temperature 0, seed 42, context size 8192 and eligible evidence in both arms. Order alternates between arms by case. Each role gets at most 256 generated tokens; the baseline gets 768. This matches the cumulative generation allowance, **not total compute**. The three-role arm repeats input and can cost more even if its outputs are shorter. Actual input tokens, output tokens and latency are reported. Generation may use fewer tokens than allowed. No determinism guarantee is claimed across hardware/runtime versions.

Metrics include accuracy with processing errors counted as failures, false confirmations, supported precision, decisive coverage, appropriate abstention recall, response-validation rate, confusion matrices and token/latency totals. Undefined rates are `null`, not zero. An infrastructure or schema error is not rewarded as a correct abstention. The benchmark makes no automatic significance, superiority or calibration claim. Human review time can be recorded separately with `--review-seconds`; it is not inferred from model latency.

Gold labels, rationales and other dataset metadata are excluded from model inputs by an explicit field allowlist. Both observation and publication timestamps must be at or before the case cutoff. Outage snapshots older than six hours, and advisory snapshots older than 30 days, are excluded. These are conservative pilot settings. A current fetch of an old advisory is not automatically authentic evidence of what was available at an earlier cutoff.

For a real evaluation, create an independently reviewed JSON dataset using the same case fields, record authentic snapshot provenance, and run:

```sh
python3 -m zora_pilot benchmark --dataset /absolute/path/to/reviewed-dataset.json
```

Each case has `id`, `domain` (`security_advisory` or `outage`), `claim`, timezone-qualified `as_of`, an `evidence` array and `gold`. Each evidence record has `id`, `text`, `text_sha256`, `source_url`, `source_family`, `observed_at`, and optional `published_at`. Hashes are over UTF-8 text. Dataset metadata must state label provenance, sampling, whether the set is a holdout and whether the incidents are historical. Reserve cases before tuning prompts, group related incidents to avoid leakage, and use independent human adjudication of unresolved labels. A prospective collection is the easiest way to obtain genuine pre-cutoff snapshots.

## Human review

Open the report and compare the exact claim, cutoff, source passages and all role assessments. Check scope, citation relevance, whether sources actually originate independently, unresolved contradictions and missing coverage. Keep uncertain claims unresolved.

After the human completes review, they can record their decision locally:

```sh
python3 -m zora_pilot review /absolute/path/to/run \
  --reviewer 'Your name' --decision needs_changes \
  --note 'Describe evidence checked and corrections needed.' \
  --review-seconds 180
```

Decisions are `approve`, `reject`, or `needs_changes`. Review records are separate files bound to the exact `result.json` hash. The original report remains a frozen pending-review draft; review records do not silently rewrite it. An approval does not enable a public action. Any later publication requires a separate, explicit user instruction and inspection of the exact materials to share.

## Implementation references

- [Ollama chat API](https://docs.ollama.com/api/chat): local structured output, timing and token counters.
- [GitHub Status API](https://www.githubstatus.com/api): public read-only status summary semantics.
- Public feed links above are the actual source allowlist.

No recurring monitor is installed. Run collection explicitly when a fresh snapshot is wanted.
