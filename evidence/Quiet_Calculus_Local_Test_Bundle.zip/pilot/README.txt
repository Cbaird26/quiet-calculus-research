QUIET CALCULUS — LOCAL ZORAASI WORKFLOW TEST

This folder is an isolated copy of the ZoraASI integrity pilot's revision-3 code.
The original project was not modified. The model is an already installed local
Ollama zora:fast; no models, feeds, accounts, or remote services were downloaded
or queried. The only network access in the evaluation is loopback inference.

Evidence classes:
1. unit-tests.txt / unit-tests.json: newly executed software regression checks.
2. controls-result.json: newly executed deterministic boundary/property checks.
   The semantic negative control intentionally demonstrates that a genuine quote
   can accompany a wrong conclusion and still pass byte-level citation validation.
3. result.json / raw_calls/: actual local model outputs on 12 fictional event
   groups, one claim each. These are synthetic computational measurements, not
   physical measurements or a representative real-world benchmark.

Labels were authored with the cases by an AI assistant; truth_specification is
an explicit author-defined rule, not an independent human adjudication. Cases
share conceptual templates. All remain pending human review. An ambiguous Q09
claim was revised BEFORE any model inference; preflight-v0 preserves that
version and its old freeze. The final protocol/data/code hashes were checked
before every inference run. No prompts, test data, or budgets were tuned after
outcomes were observed; no retries or excluded failed outputs are permitted.

Comparison: original revised single-pass baseline (up to 768 generated tokens)
versus original collector/verifier/blind-challenger workflow (256 per role).
The generation allowance is equal; total compute is not. The latter repeats
inputs and introduces extra model calls. Actual token counts and wall time are
reported. Role separation does not create independent underlying models.

Exact input reproduction: make an EMPTY new directory, copy zora_pilot/,
prepare.py, run.py, dataset.json, source_manifest.json, protocol-freeze.json,
protocol-freeze.sha256, unit-tests.json and unit-tests.txt into it, and execute:
  python3 -u run.py > run.log 2>&1
Do not copy result.json, progress.json, raw_calls/ or run.log into the new
directory. run.py checks the existing frozen model/data/code and refuses to
overwrite a result; inference is not guaranteed deterministic across runtimes.
For a NEW protocol freeze rather than an exact-input repeat, copy tests/ and
the saved state/ fixture too and run prepare.py first. prepare.py reruns the
29 original software tests and requires the source tree at its recorded path.
Do not rerun prepare.py inside this completed record. The fictional .invalid
URLs are never fetched. verify_controls.py and audit_run.py reproduce the
separate deterministic and final integrity checks without any model calls.
The completed record stores the frozen code, raw API requests/responses, model
digest, Python/platform versions, actual latency and counts, errors and hashes.

Frozen inference limits: 60 seconds per call, 1200 seconds overall, no retries.
Timeout/truncation/schema/citation errors remain processing failures and are
not scored as correct abstentions. No numerical confidence probabilities are
elicited, so this experiment does not measure probability calibration.

Physical evidence: none. The results do not validate consciousness, general
intelligence, any Theory of Everything, or a physical scalar field.
