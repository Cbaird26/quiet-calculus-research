"""Independently audit frozen input binding, raw calls, and metric arithmetic."""
import json,hashlib,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
r=load(ROOT/'result.json'); f=load(ROOT/'protocol-freeze.json')
a=[]
def check(name,value): a.append({'check':name,'passed':bool(value)})
check('result_seal',h(ROOT/'result.json')==(ROOT/'result.sha256').read_text().strip())
check('freeze_seal',h(ROOT/'protocol-freeze.json')==(ROOT/'protocol-freeze.sha256').read_text().strip())
for path,sha in f['frozen_files'].items():check('frozen_file:'+path,h(ROOT/path)==sha)
for path,sha in f['code_sha256'].items():check('source_code:'+path,h(ROOT/path)==sha)
check('source_original_preserved',r['all_source_code_preserved'])
check('complete_planned_rows',r['complete'] and len(r['rows'])==24)
gold={c['id']:c['gold'] for c in r['cases']}
metric_audit={}; idx=0
for row in r['rows']:
 for call in row['calls']:
  idx+=1
  req=load(ROOT/'raw_calls'/f'{idx:03d}.request.json')
  body=req['payload']
  check(f'call_{idx}_input_binding',json.loads(body['messages'][1]['content'])==call['input'])
  check(f'call_{idx}_prompt_binding',body['messages'][0]['content']==call['system_prompt'])
  check(f'call_{idx}_generation_cap',body['options']['num_predict']==call['generation_cap'])
  check(f'call_{idx}_frozen_before_request',datetime.datetime.fromisoformat(req['started_at'])>=datetime.datetime.fromisoformat(f['frozen_at']))
  check(f'call_{idx}_no_label_fields',not any(key in call['input'] for key in ['gold','gold_rationale','truth_specification','control','group_id']))
  if call['role']=='challenger':check(f'call_{idx}_challenger_blind','collector_observations' not in call['input'] and 'verifier' not in call['input'])
  resp=ROOT/'raw_calls'/f'{idx:03d}.response.json'
  if resp.exists():
   raw=load(resp)
   check(f'call_{idx}_raw_output_preserved',raw['message']['content']==call.get('raw_content'))
   check(f'call_{idx}_reported_counts_preserved',raw.get('eval_count',0)==call.get('output_tokens',0) and raw.get('prompt_eval_count',0)==call.get('input_tokens',0))
  else:check(f'call_{idx}_error_retained',bool(call.get('error')) and (ROOT/'raw_calls'/f'{idx:03d}.error.json').exists())
check('planned_call_count',idx==48)
for mode in ['baseline','three_role']:
 rows=[x for x in r['rows'] if x['mode']==mode]; n=len(rows)
 valid=[x for x in rows if not x['processing_error']]
 definite=[x for x in valid if x['result']['verdict']!='insufficient_evidence']
 measures={'correct':sum(x['result']['verdict']==gold[x['case_id']] for x in valid),
 'incorrect_definite_judgments':sum(x['result']['verdict']!=gold[x['case_id']] for x in definite),
 'processing_errors':n-len(valid),
 'unnecessary_abstentions':sum(x['result']['verdict']=='insufficient_evidence' and gold[x['case_id']]!='insufficient_evidence' for x in valid),
 'input_tokens':sum(c.get('input_tokens',0) for x in rows for c in x['calls']),
 'output_tokens':sum(c.get('output_tokens',0) for x in rows for c in x['calls'])}
 for key,value in measures.items():check(mode+':'+key,value==r['metrics'][mode][key])
 check(mode+':coverage',round(len(definite)/n,4)==r['metrics'][mode]['decisive_coverage'])
 metric_audit[mode]=measures
out={'scope':'Integrity and arithmetic verification, not semantic or physical validation.','checks':len(a),'passed':all(x['passed'] for x in a),'results':a,'independently_recomputed':metric_audit,'script_sha256':h(__file__)}
(ROOT/'audit-result.json').write_text(json.dumps(out,indent=2)+'\n')
summary=load(ROOT/'summary.json');summary['fresh_control_checks']=load(ROOT/'controls-result.json');summary['independent_artifact_audit']={'passed':out['passed'],'checks':out['checks'],'sha256':h(ROOT/'audit-result.json')}
(ROOT/'integration_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'passed':out['passed'],'checks':out['checks'],'metrics':metric_audit},indent=2))
assert out['passed']
