"""Run only fixed loopback inference against the pre-frozen synthetic cases."""
import json,time,sys,signal
from pathlib import Path
import zora_pilot.network as net
from zora_pilot.core import digest,read_json,write_json,now,seal,model_input
from zora_pilot.pipeline import assess
from zora_pilot.evaluation import metrics,render_report
ROOT=Path(__file__).resolve().parent
freeze=read_json(ROOT/'protocol-freeze.json')
assert digest((ROOT/'protocol-freeze.json').read_bytes())==(ROOT/'protocol-freeze.sha256').read_text().strip()
for rel,h in freeze['frozen_files'].items(): assert digest((ROOT/rel).read_bytes())==h
for rel,h in freeze['code_sha256'].items(): assert digest((ROOT/rel).read_bytes())==h
assert not (ROOT/'result.json').exists(), 'Never overwrite a completed run.'
dataset=read_json(ROOT/'dataset.json')
client=net.Ollama('zora:fast',60)
assert client.info==freeze['model']
rawdir=ROOT/'raw_calls'; rawdir.mkdir(exist_ok=False)
orig=net.request_bytes
counter=0
start=time.monotonic()
def recording_request(url,payload=None,timeout=20,local=False):
    global counter
    assert local and url==net.LOCAL+'/api/chat', 'Only local inference during evaluation.'
    if time.monotonic()-start>=1200: raise TimeoutError('total_runtime_cap_reached')
    counter+=1
    prefix=rawdir/f'{counter:03d}'
    write_json(str(prefix)+'.request.json',{'url':url,'payload':payload,'started_at':now(),'timeout_seconds':min(timeout,1200-(time.monotonic()-start))})
    t=time.monotonic()
    try:
        raw=orig(url,payload,timeout=min(timeout,1200-(time.monotonic()-start)),local=True)
        Path(str(prefix)+'.response.json').write_bytes(raw)
        return raw
    except Exception as exc:
        write_json(str(prefix)+'.error.json',{'error':str(exc),'elapsed_seconds':time.monotonic()-t})
        raise
net.request_bytes=recording_request
rows=[]
result={'kind':'benchmark','created_at':now(),'model':client.info,'dataset_metadata':dataset['metadata'],'dataset_sha256':freeze['dataset_sha256'],
 'protocol':freeze['protocol'],'protocol_freeze_sha256':digest((ROOT/'protocol-freeze.json').read_bytes()),'cases':dataset['cases'],'rows':rows,
 'review':'pending','public_release':False,'complete':False,'computational_only':True}
write_json(ROOT/'progress.json',result)
for index,case in enumerate(dataset['cases']):
    for mode in (('baseline','three_role') if index%2 else ('three_role','baseline')):
        if time.monotonic()-start>=1200: break
        row=assess(case,client,mode,256)
        rows.append(row)
        write_json(ROOT/'progress.json',result)
        print(f"{case['id']} {mode} {row['result']['verdict']} error={row['processing_error']} time={row['wall_seconds']}",flush=True)
    if time.monotonic()-start>=1200: break
gold={c['id']:c['gold'] for c in dataset['cases']}
result['metrics']={}
for mode in ('baseline','three_role'):
    m=metrics([r for r in rows if r['mode']==mode],gold)
    nd=sum(not r['processing_error'] and r['result']['verdict']!='insufficient_evidence' for r in rows if r['mode']==mode)
    m['selective_error']=m['incorrect_definite_judgments']/nd if nd else None
    m['total_tokens']=m['input_tokens']+m['output_tokens']
    result['metrics'][mode]=m
result['complete']=len(rows)==24
result['completed_at']=now(); result['elapsed_seconds']=time.monotonic()-start
result['all_source_code_preserved']=all(digest((Path('/Users/christophermichaelbaird/Documents/ChatGPT/ZoraASI/zora_integrity_pilot')/rel).read_bytes())==h for rel,h in freeze['code_sha256'].items())
result['all_frozen_files_preserved']=all(digest((ROOT/rel).read_bytes())==h for rel,h in freeze['frozen_files'].items())
seal(ROOT,result); render_report(ROOT,result)
summary={'kind':'synthetic_computational_diagnostic','complete':result['complete'],'model':client.info,'independent_underlying_synthetic_records':12,
 'planned_rows':24,'completed_rows':len(rows),'inference_calls':counter,'unit_tests':read_json(ROOT/'unit-tests.json'),
 'metrics':result['metrics'],'elapsed_seconds':result['elapsed_seconds'],'protocol_freeze_sha256':result['protocol_freeze_sha256'],
 'result_sha256':digest((ROOT/'result.json').read_bytes()),'source_preserved':result['all_source_code_preserved'],'freeze_preserved':result['all_frozen_files_preserved'],
 'limitations':[dataset['metadata']['label_provenance'],'Small deliberately balanced set; common templates; no real-world generalization claim.','Equal generation allowance is not equal compute.','No probability calibration measured. No physical measurements.']}
write_json(ROOT/'summary.json',summary)
lines=['Local ZoraASI synthetic challenge: computational workflow evidence only.',json.dumps(summary,indent=2), '\nCASE OUTCOMES']
for case in dataset['cases']:
    outcomes=[f"{r['mode']}={r['result']['verdict']} ({r['aggregation']})" for r in rows if r['case_id']==case['id']]
    lines.append(f"{case['id']} truth={case['gold']}; "+'; '.join(outcomes))
(ROOT/'summary.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps(summary,indent=2))
