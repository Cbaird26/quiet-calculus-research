import copy
import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

from zora_pilot.comparison import compare, freeze_protocol, validate_dataset
from zora_pilot.core import ROOT, digest, load_sealed, model_input, read_json, seal, write_json
from zora_pilot.evaluation import metrics
from zora_pilot.fresh import build_fresh
from zora_pilot.pipeline import assess
from zora_pilot.seed import build_seed
from test_pilot import FakeModel

ORIGINAL = ROOT / "state/benchmarks/20261023T032203Z-c8e2821c"


class ComparisonTests(unittest.TestCase):
    def fixture_collection(self, folder):
        raw = {
            "cisa-kev": {"vulnerabilities": [
                {"cveID": "CVE-2099-0001", "dateAdded": "2026-01-14", "dueDate": "2026-02-01", "vendorProject": "Test A", "product": "Alpha"},
                {"cveID": "CVE-2099-0002", "dateAdded": "2026-01-14", "dueDate": "2026-02-02", "vendorProject": "Test B", "product": "Beta"},
                {"cveID": "CVE-2099-0003", "dateAdded": "2026-01-14", "dueDate": "2026-02-03", "vendorProject": "Test C", "product": "Gamma"}]},
            "github-status": {"components": [{"id": "one", "name": "Example API", "status": "operational"}]},
            "cloudflare-status": {"components": [{"id": "two", "name": "Example Help", "status": "major_outage"}]},
        }
        sources = []
        for key, body in raw.items():
            path = folder / (key + ".json")
            write_json(path, body)
            sources.append({"id": key, "status": "ok", "url": "https://fixtures.invalid/" + key,
                            "captured_at": "2026-01-15T12:00:00Z", "raw_file": path.name, "sha256": digest(path.read_bytes())})
        seal(folder, {"kind": "collection", "sources": sources})

    def test_fresh_selection_balanced_and_uses_unused_cve_records(self):
        with tempfile.TemporaryDirectory() as d:
            self.fixture_collection(Path(d))
            dataset = build_fresh(d, ["CVE-2099-0003"])
            validate_dataset(dataset)
            self.assertEqual(len(dataset["cases"]), 12)
            for label in ("supported", "refuted", "insufficient_evidence"):
                self.assertEqual(sum(c["gold"] == label for c in dataset["cases"]), 4)
            self.assertNotIn("CVE-2099-0003", str(dataset["cases"]))
            for c in dataset["cases"]:
                self.assertEqual(c["as_of"], c["evidence"][0]["observed_at"])
                payload = json.dumps(model_input(c))
                self.assertNotIn("gold_rationale", payload)
                self.assertNotIn("group_id", payload)

    def test_fresh_source_tampering_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d)
            self.fixture_collection(folder)
            (folder / "cisa-kev.json").write_text("{}")
            with self.assertRaisesRegex(ValueError, "hash"):
                build_fresh(folder)

    def test_metrics_penalize_abstention_and_wrong_decisive_answers_separately(self):
        c = build_seed()["cases"][0]
        abstain = assess(c, FakeModel(verifier="insufficient_evidence", challenger="insufficient_evidence"))
        m = metrics([abstain], {c["id"]: "supported"})
        self.assertEqual(m["unnecessary_abstentions"], 1)
        self.assertEqual(m["incorrect_definite_judgments"], 0)
        wrong = assess(c, FakeModel())
        m = metrics([wrong], {c["id"]: "insufficient_evidence"})
        self.assertEqual(m["incorrect_definite_judgments"], 1)
        self.assertEqual(m["false_confirmations"], 1)

    def test_four_arm_runner_preserves_original_and_binds_fresh_dataset(self):
        before = {str(p): digest(p.read_bytes()) for p in ORIGINAL.rglob('*') if p.is_file()}
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d)
            freeze = folder / "freeze.json"
            freeze_protocol(freeze, ORIGINAL)
            case = build_seed()["cases"][0]
            dataset = {"metadata": {"name": "Test only", "record_groups": 1,
                       "protocol_freeze_sha256": digest(freeze.read_bytes())}, "cases": [case]}
            data_path = folder / "dataset.json"
            write_json(data_path, dataset)
            client = FakeModel()
            client.info = load_sealed(ORIGINAL)["model"]
            output = folder / "run"
            output.mkdir()
            with patch("zora_pilot.comparison.new_folder", return_value=output), redirect_stdout(io.StringIO()):
                _, result = compare(data_path, ORIGINAL, freeze, client)
            self.assertEqual(len(result["rows"]), 4)
            self.assertEqual(len(client.calls), 8)
            self.assertEqual(len({(r["protocol_variant"], r["mode"]) for r in result["rows"]}), 4)
            self.assertTrue(load_sealed(output)["complete"])
            self.assertEqual(result["review"], "pending")
            self.assertFalse(result["public_release"])
            for _, payload, _ in client.calls:
                self.assertNotIn("gold", payload)
        after = {str(p): digest(p.read_bytes()) for p in ORIGINAL.rglob('*') if p.is_file()}
        self.assertEqual(before, after)

    def test_frozen_model_or_dataset_changes_block_comparison(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d)
            freeze = folder / "freeze.json"
            freeze_protocol(freeze, ORIGINAL)
            with self.assertRaisesRegex(ValueError, "already exists"):
                freeze_protocol(freeze, ORIGINAL)
            case = build_seed()["cases"][0]
            path = folder / "dataset.json"
            write_json(path, {"metadata": {"protocol_freeze_sha256": "wrong"}, "cases": [case]})
            client = FakeModel()
            with self.assertRaisesRegex(ValueError, "model"):
                compare(path, ORIGINAL, freeze, client)
            client.info = load_sealed(ORIGINAL)["model"]
            with self.assertRaisesRegex(ValueError, "not bound"):
                compare(path, ORIGINAL, freeze, client)
