import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from zora_pilot.__main__ import assess_file, evaluate, review
from zora_pilot.core import check_assessment, digest, eligible_evidence, load_sealed, model_input, seal, validate_case
from zora_pilot.evaluation import metrics, render_report
from zora_pilot.network import LOCAL, NoRedirect, Ollama, collect, request_bytes, source_cases
from zora_pilot.pipeline import assess, protocol, response_schema, normalize_relation, RELATION_TO_VERDICT
from zora_pilot.seed import build_seed


class FakeModel:
    info = {"name": "fixture-only", "digest": "test"}

    def __init__(self, verifier="supported", challenger="supported", bad_quote=False):
        self.calls = []
        self.verifier, self.challenger, self.bad_quote = verifier, challenger, bad_quote

    def call(self, system, data, schema, budget):
        self.calls.append((system, data, budget))
        cite = [{"evidence_id": "e1", "quote": "invented quote" if self.bad_quote else data["evidence"][0]["text"]}]
        answer = {"reason": "fixture only", "citations": cite}
        if "observations" in schema["properties"]:
            answer["observations"] = "Collector fixture."
        else:
            verdict = self.challenger if "Independently test" in system or "Independently assess" in system else self.verifier
            if "evidence_relation" in schema["properties"]:
                answer["evidence_relation"] = {v: k for k, v in RELATION_TO_VERDICT.items()}[verdict]
            else:
                answer["verdict"] = verdict
        return {"answer": answer, "input_tokens": 10, "output_tokens": 20, "done_reason": "stop"}


class PilotTests(unittest.TestCase):
    def setUp(self):
        self.cases = build_seed()["cases"]
        self.case = self.cases[0]

    def test_balanced_synthetic_dataset(self):
        for case in self.cases:
            validate_case(case)
        for label in ("supported", "refuted", "insufficient_evidence"):
            self.assertEqual(sum(c["gold"] == label for c in self.cases), 6)
        self.assertFalse(build_seed()["metadata"]["independent_holdout"])

    def test_relation_mapping_is_explicit_and_does_not_parse_reason(self):
        for relation, verdict in RELATION_TO_VERDICT.items():
            result = normalize_relation({"evidence_relation": relation, "reason": "contradicts supports unknown", "citations": []})
            self.assertEqual(result["verdict"], verdict)
        for bad in ({"verdict": "refuted"}, {"evidence_relation": "contradicted", "verdict": "supported"}, {"evidence_relation": "maybe"}):
            with self.assertRaises(ValueError):
                normalize_relation(bad)

    def test_schema_allows_only_exact_source_excerpts_with_matching_ids(self):
        for case in self.cases:
            items = model_input(case)["evidence"]
            schema = response_schema("verifier", items)
            citations = schema["properties"]["citations"]
            if not items:
                self.assertEqual(citations["maxItems"], 0)
                continue
            known = {e["id"]: e["text"] for e in items}
            for branch in citations["items"]["oneOf"]:
                props = branch["properties"]
                for quote in props["quote"]["enum"]:
                    self.assertTrue(quote.strip())
                    self.assertIn(quote, known[props["evidence_id"]["const"]])

    def test_gold_and_private_fields_never_reach_model(self):
        case = copy.deepcopy(self.case)
        case["secret"] = "DO_NOT_FORWARD"
        text = json.dumps(model_input(case))
        for key in ("gold", "gold_rationale", "DO_NOT_FORWARD", "label_review"):
            self.assertNotIn(key, text)

    def test_future_and_stale_snapshots_are_excluded(self):
        for cid, reason in (("A06", "after_cutoff"), ("O06", "stale_snapshot")):
            case = next(c for c in self.cases if c["id"] == cid)
            kept, excluded = eligible_evidence(case)
            self.assertEqual(kept, [])
            self.assertEqual(excluded[0]["reason"], reason)

    def test_future_publication_is_excluded_even_if_capture_claims_earlier(self):
        case = copy.deepcopy(self.case)
        case["evidence"][0]["published_at"] = "2026-01-16T12:00:00Z"
        self.assertEqual(eligible_evidence(case)[0], [])

    def test_source_mirrors_count_as_one_family(self):
        case = next(c for c in self.cases if c["id"] == "A09")
        self.assertEqual(len(model_input(case)["source_families"]), 1)

    def test_modified_evidence_rejected(self):
        case = copy.deepcopy(self.case)
        case["evidence"][0]["text"] += "changed"
        with self.assertRaisesRegex(ValueError, "hash"):
            model_input(case)

    def test_duplicate_evidence_ids_rejected(self):
        case = copy.deepcopy(self.case)
        case["evidence"].append(copy.deepcopy(case["evidence"][0]))
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            model_input(case)

    def test_citations_require_known_ids_exact_nonempty_quotes(self):
        for cite in ({"evidence_id": "missing", "quote": "hello"},
                     {"evidence_id": "e1", "quote": "fabrication"},
                     {"evidence_id": "e1", "quote": ""}):
            with self.assertRaises(ValueError):
                check_assessment({"verdict": "supported", "reason": "x", "citations": [cite]}, self.case["evidence"])
        with self.assertRaises(ValueError):
            check_assessment({"verdict": "supported", "reason": "x", "citations": []}, self.case["evidence"])

    def test_challenger_is_blind_and_budget_allowances_match(self):
        model = FakeModel()
        assess(self.case, model, "three_role", 128)
        self.assertNotIn("collector_observations", model.calls[2][1])
        self.assertNotIn("verifier", json.dumps(model.calls[2][1]))
        assess(self.case, model, "baseline", 128)
        self.assertEqual(sum(c[2] for c in model.calls[:3]), model.calls[3][2])

    def test_disagreement_is_preserved_as_abstention(self):
        result = assess(self.case, FakeModel(challenger="refuted"))
        self.assertEqual(result["result"]["verdict"], "insufficient_evidence")
        self.assertEqual(result["aggregation"], "verdict_disagreement_preserved")
        self.assertEqual(result["calls"][1]["answer"]["verdict"], "supported")
        self.assertEqual(result["calls"][2]["answer"]["verdict"], "refuted")

    def test_bad_quote_errors_are_not_successful_abstentions(self):
        row = assess(self.case, FakeModel(bad_quote=True))
        score = metrics([row], {self.case["id"]: "insufficient_evidence"})
        self.assertEqual(score["correct"], 0)
        self.assertEqual(score["processing_errors"], 1)
        self.assertEqual(score["appropriate_abstention_recall"], 0)

    def test_external_post_unknown_urls_and_remote_local_endpoints_rejected(self):
        for url, payload, local in (("https://example.com", None, False),
                                    ("https://www.githubstatus.com/api/v2/summary.json", {}, False),
                                    ("http://remote.example/api/chat", {}, True),
                                    (LOCAL + "/api/pull", {}, True)):
            with self.assertRaises(ValueError):
                request_bytes(url, payload, local=local)

    def test_redirects_rejected(self):
        with self.assertRaises(ValueError):
            NoRedirect().redirect_request(None, None, 302, "redirect", {}, "http://localhost/")

    def test_cloud_and_missing_models_rejected(self):
        raw = json.dumps({"models": [{"name": "test:cloud", "remote_host": "cloud.example"}]}).encode()
        with patch("zora_pilot.network.request_bytes", return_value=raw):
            for name in ("test:cloud", "not-installed"):
                with self.assertRaises(ValueError):
                    Ollama(name)

    def test_fetch_failure_never_means_no_outages(self):
        with tempfile.TemporaryDirectory() as d, patch("zora_pilot.network.new_folder", return_value=Path(d)), patch("zora_pilot.network.request_bytes", side_effect=OSError("offline")):
            _, result = collect(["github-status"])
            self.assertEqual(result["cases"], [])
            self.assertEqual(result["sources"][0]["status"], "fetch_error")

    def test_empty_status_feed_is_scoped_to_provider(self):
        data = {"page": {"url": "https://www.githubstatus.com"}, "status": {"indicator": "none", "description": "All Systems Operational"}, "incidents": []}
        cases = source_cases("github-status", data, "2026-01-15T12:00:00Z")
        self.assertIn("GitHub's status page", cases[0]["claim"])
        self.assertIn("0 unresolved incidents", cases[0]["claim"])
        del data["incidents"]
        with self.assertRaises(KeyError):
            source_cases("github-status", data, "2026-01-15T12:00:00Z")

    def test_local_review_is_hash_bound_and_never_publishes(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d)
            seal(folder, {"kind": "evaluation", "complete": True})
            path = review(folder, "Test reviewer", "approve", "Test only", 5)
            record = json.loads(path.read_text())
            self.assertFalse(record["public_release"])
            self.assertEqual(record["result_sha256"], digest((folder / "result.json").read_bytes()))
            (folder / "result.json").write_text("{}")
            with self.assertRaisesRegex(ValueError, "hash"):
                review(folder, "Test reviewer", "approve", "changed")

    def test_incomplete_run_cannot_be_reviewed(self):
        with tempfile.TemporaryDirectory() as d:
            seal(d, {"kind": "evaluation", "complete": False})
            with self.assertRaises(ValueError):
                review(d, "Test", "approve", "x")

    def test_report_escapes_hostile_content_and_has_no_scripts(self):
        case = copy.deepcopy(self.case)
        case["claim"] = "<script>alert('unsafe')</script>"
        row = assess(case, FakeModel())
        result = {"kind": "evaluation", "model": FakeModel.info, "created_at": "test", "protocol": protocol(256), "cases": [case], "rows": [row]}
        with tempfile.TemporaryDirectory() as d:
            render_report(d, result)
            page = (Path(d) / "report.html").read_text()
            self.assertNotIn("<script>", page)
            self.assertIn("&lt;script&gt;", page)
            self.assertIn("default-src 'none'", page)

    def test_truncated_generation_is_an_error(self):
        fake_response = {"done": True, "done_reason": "length", "message": {"content": "{}"}}
        client = object.__new__(Ollama)
        client.model, client.timeout = "test", 1
        with patch("zora_pilot.network.request_bytes", return_value=json.dumps(fake_response).encode()):
            self.assertEqual(client.call("test", {}, {}, 128)["error"], "incomplete_generation")

    def test_tampered_raw_source_prevents_evaluation(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d)
            (folder / "source.json").write_text("tampered")
            seal(folder, {"kind": "collection", "sources": [{"status": "ok", "raw_file": "source.json", "sha256": digest("original")}], "cases": [self.case]})
            with self.assertRaisesRegex(ValueError, "Raw source hash"):
                evaluate(folder, FakeModel(), 128)

    def test_manual_claim_uses_only_embedded_evidence_and_stays_pending(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "claim.json"
            path.write_text(json.dumps(self.case))
            out = Path(d) / "run"
            out.mkdir()
            with patch("zora_pilot.__main__.new_folder", return_value=out), patch("zora_pilot.network.request_bytes", side_effect=AssertionError("Public fetch forbidden")):
                _, result = assess_file(path, FakeModel(), 128)
            self.assertEqual(result["review"], "pending")
            self.assertFalse(result["public_release"])
            self.assertEqual(load_sealed(out)["cases"][0]["id"], self.case["id"])


if __name__ == "__main__":
    unittest.main()
