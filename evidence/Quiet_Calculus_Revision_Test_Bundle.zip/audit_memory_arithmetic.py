#!/usr/bin/env python3
"""Independent scalar statistics from saved per-path losses, not another forecasting run."""
from pathlib import Path
from collections import defaultdict
from statistics import mean,stdev,NormalDist
import hashlib,json,math
ROOT=Path(__file__).resolve().parent
m=ROOT/'memory';r=json.loads((m/'results/summary.json').read_text());cfg=json.loads((m/'protocol.json').read_text());rows=[json.loads(x) for x in (m/'results/raw_paths.jsonl').read_text().splitlines()]
checks=[]
def eq(a,b,name):
 assert abs(a-b)<1e-14,(name,a,b);checks.append(name)
assert len(rows)==1300 and sum(x['family_class']=='known' for x in rows)==1100
assert len({(x['split'],x['seed'],x['scenario']) for x in rows})==1300
report={'paths':len(rows),'known_paths':1100,'exploratory_transfer_paths':200,'contrasts':{},'scenario_differences':{}}
for a,b in [('revised','adaptive'),('revised','fixed'),('adaptive','fixed')]:
 grouped=defaultdict(list)
 for x in rows:
  if x['family_class']=='known':grouped[x['split'],x['seed']].append(x['metrics'][a]['brier']-x['metrics'][b]['brier'])
 assert len(grouped)==100 and all(len(x)==11 for x in grouped.values())
 x=[mean(v) for v in grouped.values()];mu=mean(x);se=stdev(x)/10;ci=[mu-NormalDist().inv_cdf(.975)*se,mu+NormalDist().inv_cdf(.975)*se]
 key=a+'-minus-'+b;expected=r['summary']['combined']['known_scenario_average'][key]['brier'];eq(mu,expected['mean'],key+' mean')
 for i in [0,1]:eq(ci[i],expected['ci95'][i],key+' CI'+str(i))
 report['contrasts'][key]={'n_seed_clusters':100,'mean':mu,'ci95':ci,'upper_one_sided_95':mu+NormalDist().inv_cdf(.95)*se}
z=NormalDist().inv_cdf(1-.05/22);zo=NormalDist().inv_cdf(1-.05/11);upper=[];lower=[];oldgate=[]
for s in cfg['known_scenarios']:
 sr=[x for x in rows if x['scenario']==s];rv=[x['metrics']['revised']['brier']-x['metrics']['fixed']['brier'] for x in sr];av=[x['metrics']['adaptive']['brier']-x['metrics']['fixed']['brier'] for x in sr]
 u=mean(rv)+z*stdev(rv)/10;l=mean(av)-z*stdev(av)/10;upper.append(u);lower.append(l);oldgate.append(mean(rv)+zo*stdev(rv)/10)
 expected=r['summary']['combined']['revised_target'];eq(u,expected['revised_scenario_upper_bounds'][s],s+' revised upper');eq(l,expected['original_scenario_lower_bounds'][s],s+' original lower')
 report['scenario_differences'][s]={'revised_minus_fixed':mean(rv),'adaptive_minus_fixed':mean(av),'revised_minus_adaptive':mean(rv)-mean(av)}
bound=max(0.,max(upper))-max(0.,max(lower));eq(bound,r['summary']['combined']['revised_target']['worst_harm_change_upper_bound'],'worst harm difference upper')
eq(max(oldgate),max(r['summary']['combined']['unchanged_v3_fixed_target']['scenario_upper_bounds'].values()),'original gate simultaneous upper')
report.update(passed=True,arithmetic_checks=len(checks),seed_clusters=100,worst_harm_change_upper_bound=bound,max_original_gate_harm_upper=max(oldgate),scope='Independent arithmetic on the same recorded paths. No independent regenerated forecasts or physical observations.')
(ROOT/'memory_arithmetic_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='scenario_differences'},indent=2))
