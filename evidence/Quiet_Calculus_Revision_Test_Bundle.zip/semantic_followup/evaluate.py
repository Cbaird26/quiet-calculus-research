#!/usr/bin/env python3
"""Second-stage held-out comparison. All first-stage records remain unchanged."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,platform,sys,time
ROOT=Path(__file__).resolve().parent;IMPL=ROOT/'implementation'
sys.path.insert(0,str(IMPL))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def now():return datetime.now(timezone.utc).isoformat()
def save(p,value):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n');tmp.replace(p)
def configuration():
 selection=read(IMPL/'MODEL_SELECTION.json');selected=selection['selected_model']
 assert selected in {'zora:fast','gemma4:12b-it-qat'}
 arms=[{'name':'old_fast','model':'zora:fast','method':'baseline'}, {'name':'larger_model_baseline','model':'gemma4:12b-it-qat','method':'baseline'}]
 arms.append({'name':'revised_selected','model':selected,'method':'revision'})
 return {'version':'4.0','stage':'semantic_followup','cases':24,'arms':arms,'planned_calls':24*len(arms),'generation_cap':768,'context_tokens':8192,'temperature':0,'seed':42,'thinking':False,'per_call_timeout_seconds':90,'total_runtime_cap_seconds':3600,'model_metadata':selection['models'],'selected_model':selected,'selection_sha256':sha(IMPL/'MODEL_SELECTION.json'),'case_order':'Six blocks of four frozen cases; arm order cyclically rotated per block (three arms) or alternated (two arms). Every arm is first on the same number of cases. No shuffle after freeze.','primary_gate':'Against old_fast: strictly fewer incorrect definite judgments, no lower total label agreement, no more unnecessary abstentions, no more processing errors, all planned rows complete.','secondary_comparison':'Revision versus selected-model unchanged baseline, if different model; descriptive isolation of method and model changes, no complete factorial or population causal effect.','failure_rule':'All failures retained, no retries, no post-freeze implementation/model/case/label changes.','scope':'Second-stage internal revision informed by first-stage failures; provisional AI labels and constructed held-out cases; no physical evidence or production deployment.'}
def schedule(cases,arms):
 output=[]
 for block,start in enumerate(range(0,len(cases),4)):
  offset=block%len(arms);order=arms[offset:]+arms[:offset]
  for arm in order:output.extend((c,arm) for c in cases[start:start+4])
 return output
def freeze():
 assert not (ROOT/'evaluation_freeze.json').exists()
 implementation=read(IMPL/'IMPLEMENTATION_FREEZE.json');assert implementation.get('authoritative',True)
 data=read(ROOT/'heldout/dataset.json');assert len(data['cases'])==24
 from zora_pilot.network import Ollama
 from zora_pilot.core import model_input
 config=configuration()
 models={name:Ollama(name,90).info for name in {a['model'] for a in config['arms']}}
 for name,info in models.items():assert info==config['model_metadata'][name],name
 for c in data['cases']:
  for e in c['evidence']:assert set(e)<={'id','text','text_sha256','source_url','source_family','observed_at','published_at','authority'}
  assert set(model_input(c))=={'claim','domain','as_of','evidence','excluded_evidence','source_families'}
 files=[ROOT/'evaluate.py',ROOT/'STAGE_RATIONALE.md',ROOT/'root_label_review.json',ROOT/'preflight_model_control_note.json',ROOT/'heldout/dataset.json',*sorted(f for f in IMPL.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.suffix in {'.py','.json','.txt','.md'})]
 record={'created_at':now(),'protocol':config,'model':models,'environment':{'python':sys.version,'platform':platform.platform()},'files':{str(f.relative_to(ROOT)):sha(f) for f in files},'heldout_freeze_sha256':sha(ROOT/'heldout/FREEZE.json'),'implementation_freeze_sha256':sha(IMPL/'IMPLEMENTATION_FREEZE.json'),'first_stage_result_sha256':sha(ROOT.parent/'semantic/result.json'),'first_stage_audit_sha256':sha(ROOT.parent/'semantic/audit.json')}
 save(ROOT/'evaluation_freeze.json',record);(ROOT/'evaluation_freeze.sha256').write_text(sha(ROOT/'evaluation_freeze.json')+'\n');print('Follow-up freeze:',sha(ROOT/'evaluation_freeze.json'))
def run():
 from zora_pilot.pipeline import assess
 from semantic_followup_revision import assess_revised
 from zora_pilot.evaluation import metrics
 import zora_pilot.network as net
 frozen=read(ROOT/'evaluation_freeze.json');config=configuration();assert config==frozen['protocol']
 assert sha(ROOT/'evaluation_freeze.json')==(ROOT/'evaluation_freeze.sha256').read_text().strip()
 for rel,h in frozen['files'].items():assert sha(ROOT/rel)==h,rel
 assert not (ROOT/'result.json').exists() and not (ROOT/'raw_calls').exists()
 clients={name:net.Ollama(name,90) for name in frozen['model']}
 for name,client in clients.items():assert client.info==frozen['model'][name]
 rawdir=ROOT/'raw_calls';rawdir.mkdir();original=net.request_bytes;count=0;current={};start=time.monotonic()
 def record(url,payload=None,timeout=20,local=False):
  nonlocal count
  assert local and url==net.LOCAL+'/api/chat'
  left=config['total_runtime_cap_seconds']-(time.monotonic()-start)
  if left<=0:raise TimeoutError('frozen_total_runtime_exhausted')
  assert set(json.loads(payload['messages'][1]['content']))=={'claim','domain','as_of','evidence','excluded_evidence','source_families'}
  count+=1;prefix=rawdir/f'{count:03d}';save(str(prefix)+'.request.json',{'row':current,'started_at':now(),'url':url,'payload':payload,'timeout_seconds':min(timeout,left)})
  try:
   raw=original(url,payload,timeout=min(timeout,left),local=True);Path(str(prefix)+'.response.json').write_bytes(raw);return raw
  except Exception as exc:save(str(prefix)+'.error.json',{'error':str(exc),'at':now()});raise
 net.request_bytes=record
 data=read(ROOT/'heldout/dataset.json');rows=[]
 result={'version':'4.0','stage':'semantic_followup','created_at':now(),'protocol':config,'evaluation_freeze_sha256':sha(ROOT/'evaluation_freeze.json'),'cases':data['cases'],'dataset_metadata':data['metadata'],'rows':rows,'complete':False,'physical_evidence':False,'public_release':False}
 for case,arm in schedule(data['cases'],config['arms']):
  if time.monotonic()-start>=config['total_runtime_cap_seconds']:break
  clean={k:case[k] for k in ['id','domain','as_of','claim','evidence']};current={'case_id':case['id'],'arm':arm['name'],'model':arm['model']};t=time.monotonic()
  try:row=assess(clean,clients[arm['model']],'baseline',256) if arm['method']=='baseline' else assess_revised(clean,clients[arm['model']],generation_cap=768)
  except Exception as exc:row={'case_id':case['id'],'result':{'verdict':'insufficient_evidence','reason':'processing_error','citations':[]},'processing_error':True,'aggregation':'processing_error','calls':[],'input_tokens':0,'output_tokens':0,'wall_seconds':time.monotonic()-t,'fatal_error':str(exc)}
  row['mode']=arm['name'];row['model_name']=arm['model'];rows.append(row);save(ROOT/'progress.json',result)
  print(case['id'],arm['name'],row['result']['verdict'],'error='+str(row['processing_error']),flush=True)
 gold={c['id']:c['gold'] for c in data['cases']};result['metrics']={}
 for arm in config['arms']:
  values=[r for r in rows if r['mode']==arm['name']];m=metrics(values,gold);m['total_tokens']=m['input_tokens']+m['output_tokens'];m['definite_count']=sum(not x['processing_error'] and x['result']['verdict']!='insufficient_evidence' for x in values);m['selective_error']=m['incorrect_definite_judgments']/m['definite_count'] if m['definite_count'] else None;result['metrics'][arm['name']]=m
 def gate(ref):
  old=result['metrics'][ref];new=result['metrics']['revised_selected'];g={'fewer_incorrect_definite':new['incorrect_definite_judgments']<old['incorrect_definite_judgments'],'no_accuracy_drop':new['correct']>=old['correct'],'no_extra_unnecessary_abstention':new['unnecessary_abstentions']<=old['unnecessary_abstentions'],'no_extra_processing_failure':new['processing_errors']<=old['processing_errors'],'all_planned_rows_complete':len(rows)==config['planned_calls']};return {**g,'passed':all(g.values())}
 result['gate']=gate('old_fast')
 if config['selected_model']!='zora:fast':result['secondary_descriptive_gate']=gate('larger_model_baseline')
 families={}
 for c in data['cases']:families.setdefault(c['family'],[]).append(c['id'])
 result['family_metrics']={f:{arm['name']:metrics([r for r in rows if r['case_id'] in ids and r['mode']==arm['name']],gold) for arm in config['arms']} for f,ids in families.items()}
 paired=[]
 for c in data['cases']:
  matched={r['mode']:r for r in rows if r['case_id']==c['id']}
  paired.append({'case_id':c['id'],'family':c['family'],'gold':c['gold'],'arms':{a:{'verdict':r['result']['verdict'],'processing_error':r['processing_error'],'correct':not r['processing_error'] and r['result']['verdict']==c['gold']} for a,r in matched.items()}})
 result.update(paired=paired,completed_at=now(),elapsed_seconds=time.monotonic()-start,inference_calls=count,complete=len(rows)==config['planned_calls'],frozen_files_preserved=all(sha(ROOT/rel)==h for rel,h in frozen['files'].items()))
 save(ROOT/'result.json',result);(ROOT/'result.sha256').write_text(sha(ROOT/'result.json')+'\n');summary={k:v for k,v in result.items() if k not in {'rows','cases'}};summary['result_sha256']=sha(ROOT/'result.json');save(ROOT/'summary.json',summary)
 print(json.dumps({'complete':result['complete'],'inference_calls':count,'metrics':result['metrics'],'gate':result['gate'],'elapsed_seconds':result['elapsed_seconds']},indent=2))
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--freeze',action='store_true');parser.add_argument('--run',action='store_true');args=parser.parse_args()
 if args.freeze==args.run:raise SystemExit('Specify exactly one of --freeze or --run')
 freeze() if args.freeze else run()
