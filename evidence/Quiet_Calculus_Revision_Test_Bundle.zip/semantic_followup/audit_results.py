#!/usr/bin/env python3
"""Recompute follow-up metrics and verify its immutable evidence without inference."""
from pathlib import Path
from datetime import datetime
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'implementation'))
from zora_pilot.core import model_input
from zora_pilot.pipeline import PROMPTS
from semantic_followup_revision import PROMPT,safe_inputs,map_certificate
from evaluate import schedule

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
def check(value,label):
 checks.append({'passed':bool(value),'description':label})
 if not value:raise AssertionError(label)
freeze=read(ROOT/'evaluation_freeze.json');result=read(ROOT/'result.json');data=read(ROOT/'heldout/dataset.json');config=freeze['protocol'];arms={a['name']:a for a in config['arms']};n=config['planned_calls']
check(sha(ROOT/'evaluation_freeze.json')==(ROOT/'evaluation_freeze.sha256').read_text().strip(),'evaluation freeze digest')
check(sha(ROOT/'result.json')==(ROOT/'result.sha256').read_text().strip(),'result digest')
check(sha(ROOT.parent/'semantic/result.json')==freeze['first_stage_result_sha256'],'first-stage result unchanged')
check(sha(ROOT.parent/'semantic/audit.json')==freeze['first_stage_audit_sha256'],'first-stage audit unchanged')
for rel,h in freeze['files'].items():check(sha(ROOT/rel)==h,'frozen input '+rel)
for folder in ['implementation','heldout']:
 marker='IMPLEMENTATION_FREEZE.json' if folder=='implementation' else 'FREEZE.json';record=read(ROOT/folder/marker)
 for rel,h in record['files'].items():check(sha(ROOT/folder/rel)==h,folder+' inventory '+rel)
check(result['complete'] and len(result['rows'])==n and result['inference_calls']==n,'all planned observations/calls complete')
cases={c['id']:c for c in data['cases']};check(len(cases)==24,'24 unique cases')
seen=[];tokens={a:[0,0] for a in arms}
requests=sorted((ROOT/'raw_calls').glob('*.request.json'));check(len(requests)==n,'raw request count')
for f in requests:
 request=read(f);meta=request['row'];cid=meta['case_id'];arm=meta['arm'];spec=arms[arm];payload=request['payload'];seen.append((cid,arm));case=cases[cid]
 check(datetime.fromisoformat(request['started_at'])>datetime.fromisoformat(freeze['created_at']),'inference after freeze '+cid+' '+arm)
 check(payload['model']==spec['model']==meta['model'],'frozen model '+cid+' '+arm)
 check(payload['options']=={'temperature':0,'seed':42,'num_predict':768,'num_ctx':8192} and payload['think'] is False,'fixed options '+cid+' '+arm)
 expected=model_input(case) if spec['method']=='baseline' else safe_inputs(case)
 check(json.loads(payload['messages'][1]['content'])==expected,'exact allowlisted evidence '+cid+' '+arm)
 check(payload['messages'][0]['content']==(PROMPTS['baseline'] if spec['method']=='baseline' else PROMPT),'frozen prompt '+cid+' '+arm)
 row=next(x for x in result['rows'] if x['case_id']==cid and x['mode']==arm)
 response=f.with_name(f.name.replace('.request.json','.response.json'));error=f.with_name(f.name.replace('.request.json','.error.json'))
 if response.exists():
  raw=read(response);tokens[arm][0]+=raw.get('prompt_eval_count',0);tokens[arm][1]+=raw.get('eval_count',0)
  check(row['calls'][0]['raw_content']==raw.get('message',{}).get('content',''),'raw output bound '+cid+' '+arm)
  if spec['method']=='revision' and not row['processing_error']:
   check(map_certificate(json.loads(raw['message']['content']),expected['evidence'])==row['result'],'mapping replay '+cid+' '+arm)
 else:check(error.exists() and row['processing_error'],'failure retained '+cid+' '+arm)
check(len(seen)==len(set(seen))==n,'no duplicate or retry requests')
check(seen==[(c['id'],a['name']) for c,a in schedule(data['cases'],config['arms'])],'frozen rotating block schedule')
recomputed={}
for arm in arms:
 rows=[r for r in result['rows'] if r['mode']==arm];valid=[r for r in rows if not r['processing_error']];definite=[r for r in valid if r['result']['verdict']!='insufficient_evidence']
 counts={'cases':len(rows),'correct':sum(r['result']['verdict']==cases[r['case_id']]['gold'] for r in valid),'incorrect_definite_judgments':sum(r['result']['verdict']!=cases[r['case_id']]['gold'] for r in definite),'unnecessary_abstentions':sum(r['result']['verdict']=='insufficient_evidence' and cases[r['case_id']]['gold']!='insufficient_evidence' for r in valid),'processing_errors':len(rows)-len(valid),'false_confirmations':sum(r['result']['verdict']=='supported' and cases[r['case_id']]['gold']!='supported' for r in valid),'definite_count':len(definite),'input_tokens':tokens[arm][0],'output_tokens':tokens[arm][1]}
 for key,value in counts.items():check(value==result['metrics'][arm][key],'independent '+arm+' '+key)
 recomputed[arm]=counts
for reference,key in [('old_fast','gate')]+([('larger_model_baseline','secondary_descriptive_gate')] if config['selected_model']!='zora:fast' else []):
 a=recomputed[reference];b=recomputed['revised_selected'];passes=b['incorrect_definite_judgments']<a['incorrect_definite_judgments'] and b['correct']>=a['correct'] and b['unnecessary_abstentions']<=a['unnecessary_abstentions'] and b['processing_errors']<=a['processing_errors']
 check(passes==result[key]['passed'],'joint gate '+reference)
report={'passed':True,'checks':len(checks),'check_details':checks,'recomputed':recomputed,'result_sha256':sha(ROOT/'result.json'),'scope':'Independent artifact and arithmetic verification of the same saved run; no new inference, labels or physical evidence.'}
(ROOT/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='check_details'},indent=2))
