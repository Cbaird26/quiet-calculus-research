"""Authored fictional follow-up; standard library, no model or network calls.

Run only in this new heldout directory before FREEZE.json exists. Labels are
AI-assisted stipulations under PROTOCOL.md, not external human adjudication.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import random

ROOT = Path(__file__).resolve().parent
INPUT_KEYS = ('id', 'domain', 'as_of', 'claim', 'evidence')
LABEL_KEYS = ('id', 'group_id', 'family', 'gold', 'gold_rationale', 'gold_quotes', 'truth_specification')
SEED = 2026102524

def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')

def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()

def write(name, value):
    p = ROOT / name
    with p.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')

cases = []
def add(number, family, domain, date, cutoff, claim, gold, records, rationale, rule, quotes, countermodel=None, formal=None):
    cid = f'FH{number:03d}'
    evidence = []
    for k, (published, observed, body) in enumerate(records, 1):
        evidence.append({
            'id': f'{cid}-E{k}', 'text': body,
            'text_sha256': hashlib.sha256(body.encode('utf-8')).hexdigest(),
            'source_url': f'https://record-{number:03d}.invalid/record/{k}',
            'source_family': f'record-{number:03d}',
            'observed_at': f'{date}T{observed}:00Z',
            'published_at': f'{date}T{published}:00Z',
            'authority': 'publisher_statement',
        })
    spec = {'semantic_rule': rule, 'scope': claim, 'all_records_eligible': True}
    if countermodel is not None:
        spec['countermodels'] = countermodel
    if formal is not None:
        spec['formal_fixture'] = formal
    case = {
        'id': cid, 'group_id': f'followup-event-{number:03d}', 'family': family,
        'domain': domain, 'as_of': f'{date}T{cutoff}:00Z', 'claim': claim,
        'evidence': evidence, 'gold': gold, 'gold_rationale': rationale,
        'gold_quotes': [{'evidence_id': f'{cid}-E{i}', 'quote': q} for i, q in quotes],
        'truth_specification': spec,
    }
    case['input_sha256'] = digest({k: case[k] for k in INPUT_KEYS})
    case['label_sha256'] = digest({k: case[k] for k in LABEL_KEYS})
    cases.append(case)

add(1, 'ordinary_controls', 'security_advisory', '2026-09-02', '09:12',
    'Cedarline Token Ledger version 7.2 is affected by advisory ADV-CL-418.', 'supported',
    [('09:00', '09:05', 'Cedarline engineering advisory ADV-CL-418: the token-validation defect is present in Token Ledger 7.2. Version 7.2 is affected. The separately shipped Ledger Viewer does not contain this component.')],
    'The named advisory directly assigns affected status to the exact product and version in the claim. The exclusion concerns Ledger Viewer, a different product, so it neither qualifies nor conflicts with the 7.2 assessment. No generalization to other releases is required.',
    'Direct affirmative assessment for the same product, version and advisory.',
    [(1, 'Version 7.2 is affected.')])

add(2, 'ordinary_controls', 'outage', '2026-09-04', '19:25',
    'At 19:20 UTC, the Nacre image-export API was accepting new export jobs.', 'refuted',
    [('19:21', '19:23', 'Nacre operations, observation time 19:20 UTC: the image-export API is rejecting every new export request before job creation. Downloads of previously completed images remain available.')],
    'Rejecting every new request before job creation contradicts accepting new export jobs at the same observation time. Continued availability of old downloads concerns a different operation and cannot establish acceptance of new work.',
    'Explicit contrary operational state at the claimed time; distinguish old downloads from new job submission.',
    [(1, 'the image-export API is rejecting every new export request before job creation.')])

add(3, 'ordinary_controls', 'outage', '2026-09-06', '07:56',
    'The Halden gateway was not under maintenance at 07:50 UTC.', 'supported',
    [('07:52', '07:54', 'Halden gateway state at 07:50 UTC: operational. Maintenance flag OFF; no maintenance interval was active for this gateway at that time. The next planned interval begins at 10:00 UTC.')],
    'The record explicitly excludes an active maintenance interval at 07:50. This supports a genuine negative claim, rather than inferring it from silence. The planned later interval does not change the earlier state.',
    'Explicit time-scoped negative evidence supports a negative proposition.',
    [(1, 'no maintenance interval was active for this gateway at that time.')])

add(4, 'ordinary_controls', 'security_advisory', '2026-09-08', '16:18',
    'Installing Juniper Bridge 4.6 disables audit logging.', 'refuted',
    [('16:00', '16:10', 'Juniper Bridge security release note 4.6: installation preserves the existing audit-log configuration. Installing 4.6 does not disable audit logging; an enabled audit logger stays enabled after the upgrade. The installer does rotate the current log file.')],
    'The release note directly denies the claimed disabling behavior. File rotation is an independently described effect and is not equivalent to turning logging off. The claim is about the stated upgrade behavior, not every possible subsequent administrator action.',
    'Explicit negation of the claimed installation effect.',
    [(1, 'Installing 4.6 does not disable audit logging; an enabled audit logger stays enabled after the upgrade.')])

add(5, 'unresolved_conflict', 'security_advisory', '2026-09-10', '11:30',
    'FerroCache 3.1 with default settings can be exploited through FC-709 without authentication.', 'insufficient_evidence',
    [('11:10', '11:18', 'FerroCache security office, FC-709 assessment sheet A, signed 11:10 UTC: unauthenticated exploitation of FerroCache 3.1 is possible. The tested target is the standard 3.1 release with default settings.'),
     ('11:10', '11:20', 'FerroCache security office, FC-709 assessment sheet B, signed 11:10 UTC: authentication is required for every FC-709 exploit against the standard FerroCache 3.1 release with default settings; unauthenticated exploitation is not possible.')],
    'Two equally applicable records from the same security office assert opposite authentication requirements for the same advisory, release and configuration. Neither identifies itself as a correction, and both were signed at the same time. Observation order supplies no justified priority. The claim is about exploitability, not merely what sheet A says.',
    'Same-scope contrary assessments with no stated supersession remain unresolved; do not infer truth by source order.',
    [(1, 'unauthenticated exploitation of FerroCache 3.1 is possible.'), (2, 'unauthenticated exploitation is not possible.')],
    ['One admissible resolution accepts sheet A and rejects sheet B.', 'Another admissible resolution accepts sheet B and rejects sheet A.'])

add(6, 'unresolved_conflict', 'outage', '2026-09-12', '09:50',
    'Frostport search was processing queries at 09:40 UTC.', 'insufficient_evidence',
    [('09:45', '09:47', 'Frostport operations incident FP-63, service-state card, signed 09:45 UTC: at 09:40 UTC the public search service accepted and successfully processed 62 search queries.'),
     ('09:45', '09:48', 'Frostport operations incident FP-63, service-state report, signed 09:45 UTC: at 09:40 UTC every public search query failed before execution; the search service processed no queries.')],
    'Both statements concern the entire public search service at 09:40 and come from the same operations authority with the same signing time. Processing 62 queries and processing none are incompatible here. The record supplies no revision relation or narrower component interpretation that reconciles them.',
    'Material operational conflict over the same service and instant, with no priority relation.',
    [(1, 'the public search service accepted and successfully processed 62 search queries.'), (2, 'the search service processed no queries.')],
    ['If the state card is accurate, the claim holds.', 'If the service-state report is accurate, the claim fails.'])

add(7, 'unresolved_conflict', 'security_advisory', '2026-09-15', '13:35',
    'The immutable RillOS image IR-208 lacks security patch P-9.', 'insufficient_evidence',
    [('13:20', '13:25', 'RillOS release verification, signed report M: immutable release image IR-208 contains security patch P-9. This result refers to the distributed image itself, not a running machine.'),
     ('13:20', '13:27', 'RillOS release verification, signed report N: security patch P-9 is absent from immutable release image IR-208. This result refers to the distributed image itself, not a running machine.')],
    'One verification report entails the negative claim and the other contradicts it. The common immutable image prevents a plausible intervening installation from reconciling the reports, and neither report supersedes the other. Negative wording alone does not make the claim unsupported; the unresolved evidence conflict does.',
    'Contradictory membership assertions for one immutable artifact remain unresolved.',
    [(1, 'immutable release image IR-208 contains security patch P-9.'), (2, 'security patch P-9 is absent from immutable release image IR-208.')],
    ['Report M could be the correct inventory.', 'Report N could be the correct inventory.'])

add(8, 'unresolved_conflict', 'outage', '2026-09-17', '21:24',
    'LumenRoute East was not fully restored at 21:15 UTC.', 'insufficient_evidence',
    [('21:17', '21:20', 'LumenRoute network desk, east-route bulletin E, issued 21:17 UTC: the East route was fully restored at 21:15 UTC, with normal delivery on every east-route link.'),
     ('21:17', '21:21', 'LumenRoute network desk, east-route bulletin F, issued 21:17 UTC: at 21:15 UTC the East route was not fully restored; delivery remained interrupted on its primary link.')],
    'The claim is the explicit conclusion of bulletin F but is contradicted by bulletin E for the same route and time. Both originate from the same network desk and neither announces an amendment. The partial interruption cannot coexist with the first bulletin\'s stated normal delivery on every link.',
    'Unresolved same-time restoration conflict; full restoration and an interrupted constituent link are incompatible.',
    [(1, 'the East route was fully restored at 21:15 UTC'), (2, 'at 21:15 UTC the East route was not fully restored; delivery remained interrupted on its primary link.')],
    ['Accepting bulletin E yields restoration.', 'Accepting bulletin F yields non-restoration.'])

add(9, 'omission_negative', 'security_advisory', '2026-09-19', '08:40',
    'No deployment of TernProxy 6.4 has been exploited through TP-52.', 'insufficient_evidence',
    [('08:20', '08:31', 'TernProxy TP-52 telemetry note: twelve volunteer deployments running version 6.4 submitted records for this review. No TP-52 exploitation was found in those twelve records. Participation was optional; deployments outside this group were not reviewed.')],
    'The negative finding is explicitly limited to twelve volunteering deployments and their records. It does not establish absence of exploitation across all deployments, but it also supplies no exploited deployment that would refute the universal negative. Both possible global states are consistent with this partial observation.',
    'An open, non-exhaustive negative sample cannot establish or disprove a global absence claim.',
    [(1, 'No TP-52 exploitation was found in those twelve records.'), (1, 'deployments outside this group were not reviewed.')],
    ['An unreviewed deployment may have been exploited.', 'All unreviewed deployments may also have escaped exploitation.'])

add(10, 'omission_negative', 'outage', '2026-09-21', '12:15',
    'The Merrow archive service had no interruptions between 00:00 and 12:00 UTC today.', 'insufficient_evidence',
    [('12:05', '12:10', 'Merrow morning digest for 00:00-12:00 UTC, selected incidents: the upload front end slowed at 03:20, and the notification gateway queued deliveries at 08:55. This digest highlights selected incidents and is not an exhaustive service history.')],
    'The archive service is absent from a deliberately non-exhaustive digest. Neither of the two listed incidents names the archive service, and neither implies its state. Absence from this selection cannot establish an interruption-free history or an interruption.',
    'Open-world omission of the named service is not evidence of nonoccurrence.',
    [(1, 'selected incidents: the upload front end slowed at 03:20, and the notification gateway queued deliveries at 08:55.'), (1, 'is not an exhaustive service history.')],
    ['The archive service could have had an omitted interruption.', 'The archive service could have remained available throughout.'])

add(11, 'omission_negative', 'security_advisory', '2026-09-23', '15:14',
    'The vendor assessment says ValeSync 2.0 is not affected by VS-907.', 'supported',
    [('15:00', '15:08', 'ValeSync vendor assessment VS-907: the vulnerable parser was introduced in release 2.1. ValeSync 2.0 does not contain that parser and is not affected by VS-907. This conclusion is specific to VS-907 and does not certify the absence of other defects.')],
    'The assessment expressly gives the claimed negative status to release 2.0 for VS-907. Its caution about other defects does not weaken this advisory-specific conclusion. The claim asks what the vendor assessment says, rather than asserting universal security or absence of all exploitation.',
    'Explicit advisory-scoped negative assessment is stronger than omission and entails the source-scoped claim.',
    [(1, 'ValeSync 2.0 does not contain that parser and is not affected by VS-907.')])

add(12, 'omission_negative', 'outage', '2026-09-25', '12:12',
    'HarborGrid\'s west relay experienced no failed transmissions during the one-minute interval beginning at 12:04 UTC.', 'refuted',
    [('12:06', '12:09', 'HarborGrid relay counter for the one-minute interval beginning 12:04 UTC: west relay attempted 39 transmissions, of which 4 failed. The east relay recorded zero failures in the same interval. These counts cover every attempted transmission in that interval.')],
    'Four west-relay failures directly refute the claimed absence. The zero belongs to the east relay and cannot be transferred west. The counter is explicitly exhaustive, but a single genuine west failure would already suffice to contradict a universal no-failures assertion.',
    'An explicit positive counterexample refutes a negative occurrence claim; preserve component scope.',
    [(1, 'west relay attempted 39 transmissions, of which 4 failed.')])

add(13, 'closed_document', 'outage', '2026-09-27', '16:18',
    'The complete 16:10 UTC edition of the Bracken status table has no entry for the indexing worker.', 'supported',
    [('16:10', '16:13', 'Bracken status table, 16:10 UTC edition. The entire table is reproduced here: API | operational; Queue | degraded; Exporter | operational. There are no additional rows in this edition.')],
    'The claim is only about membership in this particular complete table. Its expressly exhaustive list has three rows and none is the indexing worker. This entails document absence without inferring whether the worker exists, functions, or has incidents elsewhere.',
    'Closed document membership over the exact reproduced edition.',
    [(1, 'The entire table is reproduced here: API | operational; Queue | degraded; Exporter | operational.'), (1, 'There are no additional rows in this edition.')],
    formal={'universe': 'rows in Bracken 16:10 edition', 'members': ['API', 'Queue', 'Exporter'], 'query': 'indexing worker', 'membership': False})

add(14, 'closed_document', 'security_advisory', '2026-09-29', '10:22',
    'Quay Server 8.0 is absent from the affected-products field of Kestrel bulletin KB-62.', 'refuted',
    [('10:05', '10:14', 'Kestrel bulletin KB-62. Complete affected-products field: Quay Server 7.9; Quay Server 8.0; Quay Agent 2.4. The field ends after Quay Agent 2.4. Installation guidance appears in a separate field.')],
    'The exact product and release occur literally in the named field, contradicting the claim of absence. Closure makes the field boundary clear but the positive membership alone is sufficient. Installation guidance outside the field has no bearing on this claim.',
    'A literal member of a named document field refutes absence from that field.',
    [(1, 'Complete affected-products field: Quay Server 7.9; Quay Server 8.0; Quay Agent 2.4.')],
    formal={'universe': 'KB-62 affected-products field', 'members': ['Quay Server 7.9', 'Quay Server 8.0', 'Quay Agent 2.4'], 'query': 'Quay Server 8.0', 'membership': True})

add(15, 'closed_document', 'security_advisory', '2026-10-01', '14:16',
    'Under the Oriole catalog policy, artifact O-33 does not receive the review-required flag.', 'supported',
    [('14:00', '14:08', 'Oriole catalog rule: an artifact receives the review-required flag if and only if external_access is true or unsigned_dependency is true. This rule fully determines that flag. Complete catalog values for O-33: external_access=false; unsigned_dependency=false.')],
    'Both predicates in the exhaustive if-and-only-if rule are false for O-33, so the flag is false. This is a bounded catalog classification, not an inference that O-33 is secure or needs no possible review outside this policy. The biconditional and complete values justify the negative conclusion.',
    'Evaluate an explicit closed Boolean classification rule; no open-world assumption is introduced.',
    [(1, 'if and only if external_access is true or unsigned_dependency is true.'), (1, 'Complete catalog values for O-33: external_access=false; unsigned_dependency=false.')],
    formal={'rule': 'review_required <=> external_access OR unsigned_dependency', 'external_access': False, 'unsigned_dependency': False, 'review_required': False})

add(16, 'closed_document', 'outage', '2026-10-03', '18:26',
    'Channel E4 is available under depot dispatch rule D-17.', 'refuted',
    [('18:10', '18:19', 'Depot dispatch rule D-17 defines a channel as available if and only if its free slot count is greater than zero and its lock is off. Complete current values for channel E4: free slots=3; lock=on. D-17 has no exceptions or additional availability conditions.')],
    'The rule requires both positive capacity and an unlocked state. E4 has free slots but is locked, so its availability predicate is false. Using capacity alone would drop a necessary condition. The conclusion is confined to the dispatch classification defined by D-17.',
    'Closed conjunction with one false necessary conjunct refutes the claimed classification.',
    [(1, 'available if and only if its free slot count is greater than zero and its lock is off.'), (1, 'free slots=3; lock=on.')],
    formal={'rule': 'available <=> free_slots > 0 AND lock == off', 'free_slots': 3, 'lock': 'on', 'available': False})

add(17, 'quantifier_scope', 'outage', '2026-10-05', '06:42',
    'At least one of Koru Observatory\'s upload endpoints returned a timeout at 06:30 UTC.', 'supported',
    [('06:34', '06:38', 'Koru Observatory upload endpoints are North, South and East. Probe observations at 06:30 UTC: North returned a timeout; South completed the upload; East was not probed during this pass.')],
    'North is explicitly an upload endpoint in the stated set and supplies a timeout witness at the required time. Missing East data do not prevent an existential conclusion. Nothing in the claim requires all endpoints to time out.',
    'One scoped witness entails an existential proposition.',
    [(1, 'Koru Observatory upload endpoints are North, South and East.'), (1, 'North returned a timeout;')])

add(18, 'quantifier_scope', 'security_advisory', '2026-10-07', '17:24',
    'Every build in Sable Mesh batch M-14 passed signature verification.', 'refuted',
    [('17:00', '17:13', 'Sable Mesh batch M-14 verification log: build M-14-01 passed signature verification; build M-14-04 failed signature verification because the stored signature did not match the build bytes. Other build outcomes are not included in this excerpt.')],
    'M-14-04 is a member of the claimed batch and explicitly failed the stated verification. It is therefore a counterexample to every build passing. The excerpt need not enumerate every other build to refute a universal.',
    'One contrary member refutes a universal over the same batch.',
    [(1, 'build M-14-04 failed signature verification because the stored signature did not match the build bytes.')])

add(19, 'quantifier_scope', 'security_advisory', '2026-10-09', '09:27',
    'NimbusKit 5.8 passed the deep security audit.', 'insufficient_evidence',
    [('09:05', '09:16', 'NimbusKit release policy: every release that passes the deep security audit receives a signed attestation. Signed attestations may also be issued after an identity-only review. NimbusKit 5.8 has a signed attestation. Its audit outcome is not stated in this record.')],
    'Passing the audit implies an attestation, but having an attestation does not imply passing the audit. Identity-only review supplies a possible alternative route without asserting that it was the route actually used. There is no failed-audit statement either, so the record establishes neither the claim nor its contrary.',
    'Do not invert a one-way implication or infer its antecedent from the consequent.',
    [(1, 'every release that passes the deep security audit receives a signed attestation.'), (1, 'Signed attestations may also be issued after an identity-only review.'), (1, 'NimbusKit 5.8 has a signed attestation.')],
    ['The release may have passed the deep audit and received its attestation.', 'The release may have received an identity-only attestation without passing the deep audit.'],
    formal={'rule': 'passed_deep_audit => attestation', 'attestation': True, 'passed_deep_audit': 'undetermined'})

add(20, 'quantifier_scope', 'outage', '2026-10-11', '20:21',
    'Installing the Mica retry patch eliminated queue stalls on node P7.', 'insufficient_evidence',
    [('20:00', '20:12', 'Mica deployment record for node P7: the retry patch installed successfully at 19:55 UTC. File checksums and configuration checks passed. No traffic run or queue-stall measurement has been performed since installation; the last observed stall occurred before the patch was installed.')],
    'Installation and checksum checks establish deployment, not the claimed behavioral effect. A prior stall does not refute post-installation elimination, while the absence of a post-installation measurement cannot demonstrate it. The scope change from installed artifact to operational efficacy is unsupported.',
    'Do not transfer successful installation or file integrity to demonstrated functional efficacy.',
    [(1, 'the retry patch installed successfully at 19:55 UTC.'), (1, 'No traffic run or queue-stall measurement has been performed since installation;')],
    ['Stalls may have been eliminated after installation.', 'Stalls may persist under the next suitable traffic load.'])

add(21, 'justified_resolution', 'security_advisory', '2026-10-13', '08:45',
    'The current official Solace advisory SA-36 includes version 3.8 in its affected release range.', 'supported',
    [('08:00', '08:08', 'Solace official advisory SA-36, revision 1: affected releases are 3.0 through 3.7, inclusive.'),
     ('08:30', '08:36', 'Solace official advisory SA-36, revision 2: this revision supersedes revision 1 and corrects its affected range. The current affected releases are 3.0 through 3.8, inclusive. Revision 1 omitted the final affected release.')],
    'Revision 2 is available by the cutoff and expressly supersedes and corrects revision 1. Its inclusive range contains 3.8, supporting the current-source claim. The resolution relies on the explicit revision relation, not merely the later observation timestamp.',
    'Apply an explicit correction/supersession relation for a current document claim.',
    [(2, 'this revision supersedes revision 1 and corrects its affected range.'), (2, 'The current affected releases are 3.0 through 3.8, inclusive.')])

add(22, 'justified_resolution', 'outage', '2026-10-15', '11:42',
    'Oxbow ingestion was unavailable at 11:35 UTC.', 'refuted',
    [('10:52', '10:57', 'Oxbow ingestion incident OI-81: at 10:50 UTC the ingestion service was unavailable and new data could not be submitted.'),
     ('11:36', '11:39', 'Oxbow ingestion incident OI-81 current-status update: restoration completed at 11:20 UTC. At 11:35 UTC the ingestion service was operational and accepting new submissions. The earlier 10:50 outage remains part of the incident history.')],
    'The current-status update directly reports availability at the claimed 11:35 instant and identifies restoration at 11:20. The older outage describes 10:50, so it does not conflict with the later state and cannot be carried forward through an explicit restoration.',
    'Use the state at the claimed time; an earlier outage does not persist past documented restoration.',
    [(2, 'At 11:35 UTC the ingestion service was operational and accepting new submissions.')])

add(23, 'justified_resolution', 'outage', '2026-10-17', '14:55',
    'The Plover delivery queue was not operational at 14:10 UTC.', 'supported',
    [('14:12', '14:17', 'Plover queue incident PQ-109: at 14:10 UTC the delivery queue was halted and unable to process deliveries.'),
     ('14:46', '14:50', 'Plover queue incident PQ-109: service restored at 14:45 UTC. Deliveries are now processing normally after the earlier queue halt.')],
    'The first record directly establishes the negative historical state at 14:10. The second gives a later restoration time and is consistent with that history. It must not be used to retroactively overwrite the earlier observation merely because it is newer.',
    'A later state change does not erase an explicitly time-scoped earlier state.',
    [(1, 'at 14:10 UTC the delivery queue was halted and unable to process deliveries.'), (2, 'service restored at 14:45 UTC.')])

add(24, 'justified_resolution', 'security_advisory', '2026-10-19', '18:45',
    'At the cutoff, the official TempoDB vendor notice TD-221 classifies version 10.4 as affected.', 'refuted',
    [('18:00', '18:15', 'Official TempoDB vendor notice TD-221: the defect affects version 10.3 only. Version 10.4 is not affected because the vulnerable component was removed in that release.'),
     ('18:20', '18:30', 'Community-operated TempoDB bulletin mirror, TD-221 summary: versions 10.3 and 10.4 are affected. This page is a community summary, not an official vendor notice.')],
    'The claim is expressly about the official vendor notice, whose quoted classification excludes 10.4. A community mirror says something different, but that does not change what the named official source says. No unstated hierarchy is needed to adjudicate this source-scoped proposition, and later mirror publication does not amend the official notice.',
    'Respect a claim scoped to a named primary source; a later secondary summary does not redefine that source\'s contents.',
    [(1, 'Version 10.4 is not affected because the vulnerable component was removed in that release.'), (2, 'This page is a community summary, not an official vendor notice.')])

def main():
    if (ROOT / 'FREEZE.json').exists():
        raise SystemExit('Frozen dataset: create a separately versioned directory for any amendment.')
    ordered = list(cases)
    random.Random(SEED).shuffle(ordered)
    metadata = {
        'name': 'Quiet Calculus semantic follow-up holdout', 'version': 1,
        'authored_at': datetime.now(timezone.utc).isoformat(), 'fictional': True,
        'case_count': 24, 'event_groups': 24, 'shuffle_seed': SEED,
        'label_provenance': 'AI-assisted author, same-author second pass; not human-independent gold.',
        'model_calls_during_authoring': 0,
        'separation': 'Author did not inspect current semantic implementation, progress, raw calls, results, or implementer messages.',
        'input_keys': list(INPUT_KEYS), 'label_keys': list(LABEL_KEYS),
        'canonical_hash_encoding': 'UTF-8 JSON; ensure_ascii=False; sort_keys=True; separators=(comma,colon); allow_nan=False',
        'read_sources': ['../../semantic/heldout/PROTOCOL.md for format/family rules only; exact schema supplied by root as field names without cases'],
    }
    write('dataset.json', {'metadata': metadata, 'cases': ordered})
    write('inputs.json', {'metadata': {'input_keys': list(INPUT_KEYS)}, 'cases': [{k: c[k] for k in INPUT_KEYS} for c in ordered]})
    write('labels.json', {'metadata': {'label_keys': list(LABEL_KEYS), 'provenance': metadata['label_provenance']}, 'cases': [{k: c[k] for k in LABEL_KEYS} for c in ordered]})
    print('Wrote 24 fictional cases and separate input/label files; no inference performed.')

if __name__ == '__main__':
    main()
