# Separately authored semantic follow-up holdout

This is a new, fictional 24-event challenge prepared on 2026-10-25 local time. It is not a relabeling, replacement, or amendment of an earlier experiment. Each event has one claim, with no alternate labels or shared event variants. All content is nonclinical, and all source URLs are fictional `.invalid` metadata. No network access or model inference is used in authoring or validation.

## Separation and authorship

The author read the earlier `semantic/heldout/PROTOCOL.md` only for schema, family definitions and adjudication semantics. Root supplied exact evidence-field names as text, without cases or outcomes. The author did not inspect current semantic implementation, progress, raw calls, results, or implementer messages. The narratives, entities, dates, quantities and claims here were newly composed. Case content is not communicated to the implementer. Root may independently review ambiguity before executing a separately frozen follow-up.

Labels and the second semantic pass are AI-assisted, performed by the same author. This is author/implementer separation within an AI workflow; it is not independent human labeling or evidence of human agreement. Frozen bytes cannot establish truth or independence. Root's later review, if any, must be described separately.

## Decision rules

1. `supported` means the eligible record entails the precise proposition under these stipulated fictional semantics. `refuted` requires evidence for its contrary. `insufficient_evidence` covers underdetermination and unresolved material same-scope conflict. This conflict rule does not permit classical explosion.
2. Preserve product, version, configuration, component, document/field, quantifier and time. Direct explicit negatives are usable evidence. Do not treat a negative claim as automatically uncertain.
3. Missing entries in a partial or open record do not establish nonoccurrence. A negative finding in an incomplete sample does not establish global absence; without a positive counterexample it does not refute absence either.
4. A document expressly reproduced in full permits conclusions about its membership. A stipulated finite domain with complete values and an iff rule permits its defined classification. Neither form of closure extends to arbitrary events, security properties, other documents, or other versions.
5. Opposite equally applicable statements about the same proposition remain unresolved unless an explicit correction, supersession, justified time distinction, or claim-scoped source relation settles the issue. Publication or observation recency alone is not a correction of history.
6. A current-status claim can use a documented transition before the claimed time. A historical claim retains its own time even when a later update changes the current state. A claim about what a named official document says is distinct from a general assertion about the world.
7. One witness establishes an existential; one contrary member refutes a universal over the same set. A one-way implication cannot be inverted. Installation or file integrity does not establish functional efficacy.
8. Use no outside assumptions, reputation, web lookup, imagined missing events, or actual-world knowledge to decide these fictional labels.

Eligibility follows the prior format: security-advisory records have a 30-day observation-age limit; outage records have a six-hour limit. Exclude publications or observations after the cutoff. Every record in this follow-up is intentionally eligible, with publication no later than observation and both before cutoff. No hidden future-evidence case is required to settle a label.

## Composition and interface

There are six families with four cases each, using the earlier strings: `ordinary_controls`, `unresolved_conflict`, `omission_negative`, `closed_document`, `quantifier_scope`, `justified_resolution`. Overall counts are eight `supported`, eight `refuted`, and eight `insufficient_evidence`. Unresolved conflicts have insufficient labels; forcing within-family balance would weaken that construct. Dataset order is shuffled once using seed 2026102524 before inference.

`dataset.json` contains `metadata` and `cases`. Runtime cases use exactly `id`, `domain`, `as_of`, `claim`, `evidence`; domain is `security_advisory` or `outage`. Every evidence record has exactly these string fields: `id`, `text`, `text_sha256`, `source_url`, `source_family`, `observed_at`, `published_at`, `authority`. Evidence text hashes are SHA-256 of UTF-8 text. Source names are neutral event identifiers; authority is uniformly `publisher_statement`. These metadata do not contain family names or labels.

Dataset-only fields include `group_id`, `family`, `gold`, `gold_rationale`, `gold_quotes`, `truth_specification`, `input_sha256`, `label_sha256`. Gold quotes are literal substrings paired with their evidence ID. `inputs.json` contains the runtime allowlist only; `labels.json` contains adjudication fields only. Root must use the same eligible runtime bytes for both arms and exclude all labels, rationales, families, formal fixtures and review notes from prompts. Arm code, model identity, budgets and inference statistics are root's separately frozen responsibility; this author does not select or inspect outcomes.

Input hashes cover the runtime case. Label hashes cover `id`, `group_id`, `family`, `gold`, `gold_rationale`, `gold_quotes`, `truth_specification`. Both use canonical UTF-8 JSON with `ensure_ascii=False`, `sort_keys=True`, separators `(',', ':')`, and `allow_nan=False`. File hashes cover bytes as saved. This definition is recorded in `FREEZE.json`.

## Review and freeze

The first pass supplies label, exact gold quotes, detailed rationale and semantic rule. Each insufficient case has two admissible states or resolutions that demonstrate why one conclusion is not settled. Finite document/classification and one-way implication cases also include small formal fixtures.

The same author then checks every case for precise scope, time, genuine contradiction or entailment, bounded closure, negative versus missing evidence, and an unjustified inverse implication. The second-pass review is recorded per case. Before freezing, minor wording was tightened for default configuration, a nonzero search count and an exact transmission interval; no model outcome informed any wording or label. All changes occurred before data generation and freezing.

Run `python3 -B author_cases.py`, `python3 -B review_cases.py`, then `python3 -B validate_dataset.py`. The validator checks schema, counts, unique groups and event-specific evidence, literal quotes, eligibility, neutral runtime metadata, separate input/label projection, canonical hashes, formal fixtures and complete review coverage. It does not prove natural-language entailment. Each output is created exclusively; scripts refuse to amend a frozen directory. Freeze every author, protocol, review, validator, source-read, dataset, input, label and validation file in `FREEZE.json`, and save its SHA-256 separately.

After freezing, no silent label changes or outcome-driven case tuning are allowed. Any correction requires a separate version and explicit timing relative to inference. Earlier artifacts remain untouched. A follow-up can be reported only as this separate challenge; it cannot erase or retrospectively repair earlier results.

## Limits

The 24 fictional events share an author and design assumptions. They are not independent samples from a natural deployment distribution. The balance is deliberately artificial. Literal negatives, short records and explicit rules can make some items easier than realistic review; conflict and scope constructions may introduce shared templates. Passing these cases would support only performance on the frozen challenge and configuration. It would establish neither general reliability, physical evidence, consciousness nor a solved theory of everything. Independent human adjudication and broader untouched datasets remain separate future work.
