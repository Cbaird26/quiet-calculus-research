"""Record a same-author second semantic pass, not independent human review."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parent
REVIEWS = {
    'FH001': ('supported', 'Exact product/version/advisory match. Viewer exclusion is a different product; no universal extension is made.'),
    'FH002': ('refuted', 'New exports are rejected before creation. Previously completed downloads cannot satisfy acceptance of new jobs.'),
    'FH003': ('supported', 'An explicit inactive maintenance interval supports the negative at 07:50. The later plan has a different time.'),
    'FH004': ('refuted', 'The record directly denies the installation effect. Rotation is distinct from disabling logging.'),
    'FH005': ('insufficient_evidence', 'Claim now expressly includes default settings. Both reports address that exact configuration, have equal source/signing time, and lack any correction relation.'),
    'FH006': ('insufficient_evidence', 'The affirmative record contains a nonzero count, avoiding vacuous all-queries wording. Sixty-two versus zero at the same time is a real contradiction with no precedence.'),
    'FH007': ('insufficient_evidence', 'Same immutable image and same patch rule out an intervening installation explanation. Opposing inventories remain unresolved.'),
    'FH008': ('insufficient_evidence', 'Normal delivery on every East link contradicts a remaining primary-link interruption at the same instant. Neither statement is a later restoration.'),
    'FH009': ('insufficient_evidence', 'Twelve voluntary records are not all deployments. Both no global exploitation and unreviewed exploitation fit this evidence.'),
    'FH010': ('insufficient_evidence', 'The digest explicitly lacks exhaustive coverage. Neither mentioned service establishes the unmentioned archive state.'),
    'FH011': ('supported', 'The negative is an express version/advisory conclusion, not an argument from silence. Other possible defects do not negate this scoped assessment.'),
    'FH012': ('refuted', 'The claim uses the exact one-minute interval, not an instantaneous reading. Four west failures refute zero; east zero is irrelevant.'),
    'FH013': ('supported', 'Closure is only over this complete table edition. No claim about actual worker availability is inferred from document absence.'),
    'FH014': ('refuted', 'The exact server version is present in the named field. A literal positive member defeats the negative membership claim.'),
    'FH015': ('supported', 'Both operands are false and the policy is a biconditional. The derived negative flag is bounded to the catalog policy.'),
    'FH016': ('refuted', 'An active lock makes one necessary conjunct false despite positive capacity. The iff clause closes the toy classification.'),
    'FH017': ('supported', 'North is explicitly a member and supplies a timeout witness. East need not be measured to establish at least one.'),
    'FH018': ('refuted', 'The failed build belongs to the named batch. One failure refutes every-pass without complete enumeration.'),
    'FH019': ('insufficient_evidence', 'An attestation can follow either audit success or another route. The alternate route is possible, not established, so neither pass nor fail is entailed.'),
    'FH020': ('insufficient_evidence', 'Successful deployment is distinct from measured stall elimination. The pre-patch stall is not a post-patch counterexample.'),
    'FH021': ('supported', 'Supersession and correction are explicit. The inclusive amended range contains 3.8 and is available at cutoff.'),
    'FH022': ('refuted', 'The claim time follows explicit restoration and has its own operational observation. Earlier unavailability does not persist through that transition.'),
    'FH023': ('supported', 'The historical halt remains true despite later restoration. No retroactive correction or conflicting 14:10 observation is present.'),
    'FH024': ('refuted', 'The claim names the official notice. Its exclusion of 10.4 is clear; a later community summary does not change the official text.'),
}

def main():
    if (ROOT / 'FREEZE.json').exists():
        raise SystemExit('Do not alter frozen review.')
    data = json.loads((ROOT / 'dataset.json').read_text())
    review = []
    for case in data['cases']:
        gold, note = REVIEWS[case['id']]
        assert gold == case['gold']
        review.append({
            'id': case['id'], 'label_reaffirmed': gold, 'result': 'clear_under_stated_semantics',
            'checks': ['entity_and_predicate', 'time_and_eligibility', 'source_scope', 'negation_or_omission',
                       'closure_if_used', 'conflict_resolution_if_used', 'quantifier_or_implication', 'literal_gold_quotes'],
            'second_pass_note': note, 'label_sha256': case['label_sha256'],
        })
    out = {'reviewed_at': datetime.now(timezone.utc).isoformat(),
           'reviewer_provenance': 'Same AI-assisted author; this is not independent human adjudication.',
           'dataset_sha256': hashlib.sha256((ROOT / 'dataset.json').read_bytes()).hexdigest(),
           'model_calls': 0, 'all_24_labels_reaffirmed': True, 'cases': review}
    with (ROOT / 'SECOND_PASS_REVIEW.json').open('x') as stream:
        stream.write(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
    print('Recorded 24 same-author semantic reviews.')

if __name__ == '__main__':
    main()
