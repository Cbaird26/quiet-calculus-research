"""Structural, provenance and toy-rule validation. No inference or network."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
INPUT_KEYS = ('id', 'domain', 'as_of', 'claim', 'evidence')
LABEL_KEYS = ('id', 'group_id', 'family', 'gold', 'gold_rationale', 'gold_quotes', 'truth_specification')
EVIDENCE_KEYS = {'id', 'text', 'text_sha256', 'source_url', 'source_family', 'observed_at', 'published_at', 'authority'}
FAMILIES = {'ordinary_controls', 'unresolved_conflict', 'omission_negative', 'closed_document', 'quantifier_scope', 'justified_resolution'}
LABELS = {'supported', 'refuted', 'insufficient_evidence'}

def canonical(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')

def sha_bytes(x):
    return hashlib.sha256(x).hexdigest()

def main():
    if (ROOT / 'FREEZE.json').exists():
        raise SystemExit('Frozen: inspect existing VALIDATION.json or copy to a new directory.')
    raw = (ROOT / 'dataset.json').read_bytes()
    data = json.loads(raw)
    cases = data['cases']
    assert len(cases) == 24
    assert {c['id'] for c in cases} == {f'FH{i:03d}' for i in range(1, 25)}
    assert len({c['group_id'] for c in cases}) == 24
    assert Counter(c['family'] for c in cases) == {f: 4 for f in FAMILIES}
    assert Counter(c['gold'] for c in cases) == {g: 8 for g in LABELS}
    inputs = json.loads((ROOT / 'inputs.json').read_text())['cases']
    labels = json.loads((ROOT / 'labels.json').read_text())['cases']
    assert inputs == [{k: c[k] for k in INPUT_KEYS} for c in cases]
    assert labels == [{k: c[k] for k in LABEL_KEYS} for c in cases]
    all_texts = set()
    all_evidence_ids = set()
    all_source_families = set()
    quote_count = 0
    evidence_count = 0
    per_case = []
    for c in cases:
        assert c['domain'] in {'security_advisory', 'outage'}
        assert c['gold'] in LABELS
        assert c['input_sha256'] == sha_bytes(canonical({k: c[k] for k in INPUT_KEYS}))
        assert c['label_sha256'] == sha_bytes(canonical({k: c[k] for k in LABEL_KEYS}))
        cutoff = datetime.fromisoformat(c['as_of'].replace('Z', '+00:00'))
        assert cutoff.tzinfo is not None
        by_id = {}
        family = set()
        for e in c['evidence']:
            assert set(e) == EVIDENCE_KEYS
            assert all(isinstance(v, str) and v for v in e.values())
            assert e['text_sha256'] == sha_bytes(e['text'].encode('utf-8'))
            assert e['text'] not in all_texts
            all_texts.add(e['text'])
            assert e['id'] not in all_evidence_ids
            all_evidence_ids.add(e['id'])
            parsed = urlparse(e['source_url'])
            assert parsed.scheme == 'https' and parsed.hostname.endswith('.invalid')
            assert e['authority'] == 'publisher_statement'
            assert e['source_family'] == f"record-{int(c['id'][2:]):03d}"
            assert all(word not in e['source_family'] for word in LABELS | FAMILIES)
            observed = datetime.fromisoformat(e['observed_at'].replace('Z', '+00:00'))
            published = datetime.fromisoformat(e['published_at'].replace('Z', '+00:00'))
            assert published <= observed <= cutoff
            max_seconds = 6*3600 if c['domain'] == 'outage' else 30*24*3600
            assert 0 <= (cutoff-observed).total_seconds() <= max_seconds
            assert 0 <= (cutoff-published).total_seconds() <= max_seconds
            family.add(e['source_family'])
            by_id[e['id']] = e
            evidence_count += 1
        assert family.isdisjoint(all_source_families)
        all_source_families.update(family)
        assert c['gold_quotes']
        for q in c['gold_quotes']:
            assert set(q) == {'evidence_id', 'quote'}
            assert q['quote'] and q['quote'] in by_id[q['evidence_id']]['text']
            quote_count += 1
        if c['gold'] == 'insufficient_evidence':
            assert len(c['truth_specification']['countermodels']) == 2
        if c['family'] == 'unresolved_conflict':
            assert c['gold'] == 'insufficient_evidence' and len(c['evidence']) == 2
            assert len({q['evidence_id'] for q in c['gold_quotes']}) == 2
        per_case.append({'id': c['id'], 'input_sha256': c['input_sha256'], 'label_sha256': c['label_sha256'],
                         'eligible_evidence': len(c['evidence']), 'literal_quotes': len(c['gold_quotes'])})
    by_id = {c['id']: c for c in cases}
    for cid in ('FH013', 'FH014'):
        spec = by_id[cid]['truth_specification']['formal_fixture']
        assert (spec['query'] in spec['members']) == spec['membership']
    spec = by_id['FH015']['truth_specification']['formal_fixture']
    assert (spec['external_access'] or spec['unsigned_dependency']) == spec['review_required'] == False
    spec = by_id['FH016']['truth_specification']['formal_fixture']
    assert (spec['free_slots'] > 0 and spec['lock'] == 'off') == spec['available'] == False
    # For A => B with B true, both truth values of A satisfy the premise.
    admissible_a = [a for a in (False, True) if (not a) or True]
    assert admissible_a == [False, True]
    assert by_id['FH019']['truth_specification']['formal_fixture']['passed_deep_audit'] == 'undetermined'
    review = json.loads((ROOT / 'SECOND_PASS_REVIEW.json').read_text())
    assert review['dataset_sha256'] == sha_bytes(raw)
    assert {r['id'] for r in review['cases']} == set(by_id) and len(review['cases']) == 24
    for r in review['cases']:
        assert r['label_reaffirmed'] == by_id[r['id']]['gold']
        assert r['label_sha256'] == by_id[r['id']]['label_sha256']
        assert r['second_pass_note']
    out = {'status': 'pass', 'validated_at': datetime.now(timezone.utc).isoformat(),
           'dataset_sha256': sha_bytes(raw), 'cases': len(cases), 'event_groups': 24,
           'evidence_records': evidence_count, 'literal_gold_quotes': quote_count,
           'labels': dict(Counter(c['gold'] for c in cases)), 'families': dict(Counter(c['family'] for c in cases)),
           'all_records_eligible': True, 'same_author_reviews': 24, 'formal_fixtures_checked': 5,
           'model_calls': 0, 'inputs_exclude_gold_metadata': True, 'per_case': per_case,
           'limitation': 'Mechanical checks validate format, hashes and explicit toy fixtures; natural-language labels remain AI-authored judgments under PROTOCOL.md.'}
    with (ROOT / 'VALIDATION.json').open('x') as stream:
        stream.write(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: v for k, v in out.items() if k != 'per_case'}, indent=2))

if __name__ == '__main__':
    main()
