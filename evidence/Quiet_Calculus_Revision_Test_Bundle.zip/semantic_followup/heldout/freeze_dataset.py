"""Seal this separate authored challenge before any follow-up inference."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def exclusive_json(name, value):
    with (ROOT / name).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')

def main():
    if (ROOT / 'FREEZE.json').exists():
        raise SystemExit('Already frozen; preserve existing artifacts.')
    validation = json.loads((ROOT / 'VALIDATION.json').read_text())
    dataset = json.loads((ROOT / 'dataset.json').read_text())
    assert validation['status'] == 'pass' and validation['dataset_sha256'] == sha(ROOT / 'dataset.json')
    prior_protocol = ROOT.parents[1] / 'semantic' / 'heldout' / 'PROTOCOL.md'
    exclusive_json('SOURCE_READS.json', {
        'prior_material_read': [{'path': str(prior_protocol), 'sha256': sha(prior_protocol),
                                  'purpose': 'Only format, family definitions and adjudication semantics; no prior case data.'}],
        'schema_source': 'Root sent exact field names/types and container shape, with no case contents or evaluation outcomes.',
        'forbidden_artifacts_read': [], 'model_calls': 0, 'network_calls': 0,
        'author_statement': 'No current semantic implementation, progress, raw calls, results, or implementer messages were inspected.',
        'new_local_material': 'Own newly authored code, protocol, cases and review were read during semantic validation.',
    })
    exclusive_json('AUTHORING_RECEIPT.json', {
        'recorded_at': datetime.now(timezone.utc).isoformat(),
        'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
        'commands': [
            {'command': 'python3 -B author_cases.py', 'exit_code': 0,
             'output': 'Wrote 24 fictional cases and separate input/label files; no inference performed.'},
            {'command': 'python3 -B review_cases.py', 'exit_code': 0,
             'output': 'Recorded 24 same-author semantic reviews.'},
            {'command': 'python3 -B validate_dataset.py', 'exit_code': 0,
             'output_artifact': 'VALIDATION.json', 'status': 'pass'},
        ],
        'semantic_review': 'Author read all 24 generated claims, evidence records and rationales before recording the second pass.',
        'inference_performed': False, 'earlier_artifacts_changed': False,
        'limitations': 'This receipt records the authoring run; it is not an external timestamp authority or independent review.',
    })
    paths = sorted(p for p in ROOT.iterdir() if p.is_file() and p.name not in {'FREEZE.json', 'FREEZE.sha256'})
    assert len(paths) == 12
    freeze = {
        'status': 'sealed_before_followup_model_execution',
        'frozen_at': datetime.now(timezone.utc).isoformat(),
        'version': 1, 'cases': 24, 'model_calls_before_freeze': 0,
        'files': {p.name: sha(p) for p in paths},
        'per_case': [{k: c[k] for k in ('id', 'input_sha256', 'label_sha256')} for c in dataset['cases']],
        'hash_definition': 'Input/label hashes use UTF-8 JSON, ensure_ascii=False, sort_keys=True, separators=(comma,colon), allow_nan=False. File hashes use bytes.',
        'label_provenance': 'AI-assisted authorship and same-author second pass; not independent human gold.',
        'inference_scope': 'A separately frozen follow-up only; previous experiments and labels remain unchanged.',
        'amendment_policy': 'Do not modify this seal. Any correction requires a separate version and transparent pre/post-inference timing.',
    }
    exclusive_json('FREEZE.json', freeze)
    with (ROOT / 'FREEZE.sha256').open('x') as stream:
        stream.write(sha(ROOT / 'FREEZE.json') + '\n')
    print(json.dumps({'frozen_files': len(paths), 'dataset_sha256': sha(ROOT / 'dataset.json'),
                      'inputs_sha256': sha(ROOT / 'inputs.json'), 'labels_sha256': sha(ROOT / 'labels.json'),
                      'freeze_sha256': sha(ROOT / 'FREEZE.json')}, indent=2))

if __name__ == '__main__':
    main()
