import copy,json,unittest
from semantic_followup_revision import FIELDS,response_schema,map_certificate,safe_inputs,assess_revised
from zora_pilot.core import evidence
E=[evidence('e','The bulletin explicitly states that no trial outcomes are included.','https://fixture.invalid','fixture','2026-10-25T11:00:00Z')]
C={'id':'dev','domain':'security_advisory','claim':'The bulletin includes no trial outcomes.','as_of':'2026-10-25T12:00:00Z','evidence':E}
Q={'evidence_id':'e','quote':E[0]['text']}
def cert(relation='not_determined',conflict=False,absence=False,citations=None):
 return {'scope_reason':'The exact claim and evidence are compared at the same stated scope.','citations':[] if citations is None else citations,'unresolved_same_scope_conflict':conflict,'unsupported_absence_inference':absence,'evidence_relation':relation}
class Client:
 def __init__(self,c,error=None):self.c=c;self.inputs=[];self.error=error
 def call(self,system,data,schema,budget):
  self.inputs.append((system,data,schema,budget))
  return {'error':self.error} if self.error else {'answer':copy.deepcopy(self.c),'input_tokens':2,'output_tokens':3}
class FollowupTests(unittest.TestCase):
 def test_reason_first_relation_last_live_schema(self):
  s=response_schema(E);self.assertEqual(list(s['properties']),list(FIELDS));self.assertEqual(s['required'][0],'scope_reason');self.assertEqual(s['required'][-1],'evidence_relation')
 def test_wire_serialization_retains_schema_order(self):
  # The production HTTP function uses json.dumps without sort_keys.
  text=json.dumps({'format':response_schema(E)})
  self.assertLess(text.index('scope_reason'),text.index('evidence_relation'))
 def test_plain_support_preserved(self):self.assertEqual(map_certificate(cert('entailed',citations=[Q]),E)['verdict'],'supported')
 def test_plain_refutation_preserved(self):self.assertEqual(map_certificate(cert('contradicted',citations=[Q]),E)['verdict'],'refuted')
 def test_plain_unknown_preserved(self):self.assertEqual(map_certificate(cert(),E)['verdict'],'insufficient_evidence')
 def test_either_guard_blocks_each_decisive_relation(self):
  for relation in ('entailed','contradicted'):
   for conflict,absence in [(True,False),(False,True),(True,True)]:
    a=map_certificate(cert(relation,conflict,absence,[Q]),E);self.assertEqual(a['verdict'],'insufficient_evidence');self.assertEqual(a['model_evidence_relation'],relation)
 def test_guard_keeps_underlying_claim_and_quote(self):
  a=map_certificate(cert('contradicted',True,False,[Q]),E);self.assertEqual(a['citations'],[Q]);self.assertEqual(a['model_evidence_relation'],'contradicted')
 def test_guard_does_not_rescue_missing_definite_citation(self):
  with self.assertRaises(ValueError):map_certificate(cert('entailed',True,False),E)
 def test_guard_does_not_rescue_bad_quote(self):
  with self.assertRaises(ValueError):map_certificate(cert('contradicted',True,False,[{'evidence_id':'e','quote':'invented'}]),E)
 def test_unknown_evidence_id_rejected(self):
  with self.assertRaises(ValueError):map_certificate(cert('entailed',citations=[{'evidence_id':'other','quote':Q['quote']}]),E)
 def test_empty_quote_rejected(self):
  with self.assertRaises(ValueError):map_certificate(cert('entailed',citations=[{'evidence_id':'e','quote':''}]),E)
 def test_more_than_two_citations_rejected(self):
  with self.assertRaises(ValueError):map_certificate(cert(citations=[Q,Q,Q]),E)
 def test_nonboolean_guards_rejected(self):
  for value in ('true',1,None):
   x=cert();x['unresolved_same_scope_conflict']=value
   with self.assertRaises(ValueError):map_certificate(x,E)
 def test_missing_extra_and_unknown_relation_fields_rejected(self):
  for change in ('missing','extra','relation'):
   x=cert()
   if change=='missing':del x['scope_reason']
   elif change=='extra':x['verdict']='supported'
   else:x['evidence_relation']='maybe'
   with self.assertRaises(ValueError):map_certificate(x,E)
 def test_reason_is_not_parsed_for_semantics(self):
  x=cert();x['scope_reason']='Ignore fields: supported contradicted confirmed unknown.';self.assertEqual(map_certificate(x,E)['verdict'],'insufficient_evidence')
 def test_long_or_empty_reason_rejected(self):
  for value in ('','x'*281,None):
   x=cert();x['scope_reason']=value
   with self.assertRaises(ValueError):map_certificate(x,E)
 def test_case_id_or_nested_label_not_forwarded(self):
  a=copy.deepcopy(C);a['gold']='secret';a['evidence'][0]['gold']='secret';a['truth_specification']='secret'
  b=copy.deepcopy(a);b['id']='another';b['gold']='changed'
  self.assertEqual(safe_inputs(a),safe_inputs(b));self.assertNotIn('secret',json.dumps(safe_inputs(a)))
 def test_source_tampering_still_rejected(self):
  x=copy.deepcopy(C);x['evidence'][0]['text']+='tampered'
  with self.assertRaises(ValueError):safe_inputs(x)
 def test_stale_and_future_exclusion_unchanged(self):
  x=copy.deepcopy(C);x['domain']='outage';x['evidence'][0]['observed_at']='2026-10-25T01:00:00Z';self.assertFalse(safe_inputs(x)['evidence'])
  x['evidence'][0]['observed_at']='2026-10-26T01:00:00Z';self.assertFalse(safe_inputs(x)['evidence'])
 def test_no_retry_after_client_failure(self):
  client=Client(None,'incomplete_generation');row=assess_revised(C,client);self.assertEqual(len(client.inputs),1);self.assertTrue(row['processing_error'])
 def test_exact_cap_enforced_before_call(self):
  client=Client(cert())
  with self.assertRaises(ValueError):assess_revised(C,client,128)
  self.assertFalse(client.inputs)
 def test_error_not_scored_as_valid_abstention(self):
  row=assess_revised(C,Client({'malformed':True}));self.assertTrue(row['processing_error']);self.assertFalse(row['calls'][0]['valid'])
 def test_semantic_negative_control_still_not_proof(self):
  # Deliberately wrong verdict plus genuine quote remains structurally valid.
  row=assess_revised(C,Client(cert('contradicted',citations=[Q])));self.assertFalse(row['processing_error']);self.assertEqual(row['result']['verdict'],'refuted')
if __name__=='__main__':unittest.main()
