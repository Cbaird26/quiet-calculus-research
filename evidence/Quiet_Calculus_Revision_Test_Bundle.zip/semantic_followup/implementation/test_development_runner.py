import copy,json,tempfile,time,unittest
from pathlib import Path
from run_development import MODELS,Recorder,ranking_for,verify_freeze
from development_cases import build
from semantic_followup_revision import safe_inputs
from zora_pilot.core import digest,write_json
from zora_pilot.network import LOCAL

def payload(model='zora:fast'):
 return {'model':model,'options':{'temperature':0,'seed':42,'num_predict':768,'num_ctx':8192},'think':False}
def stats(errors=0,wrong=0,correct=0,abstain=0):
 return {'processing_errors':errors,'incorrect_definite_judgments':wrong,'correct':correct,'unnecessary_abstentions':abstain}
class RunnerTests(unittest.TestCase):
 def test_all_eight_cases_valid_four_shared_groups_and_labels_excluded(self):
  data=build();self.assertEqual(len(data['cases']),8);self.assertEqual(len({c['record_group'] for c in data['cases']}),4)
  for c in data['cases']:
   model=safe_inputs(c);self.assertTrue(model['evidence']);self.assertFalse(model['excluded_evidence']);self.assertNotIn('gold',model);self.assertNotIn('record_group',model);self.assertNotIn('label_rationale',model)
 def test_each_pair_shares_evidence_not_claim(self):
  cases=build()['cases']
  for a,b in zip(cases[::2],cases[1::2]):self.assertEqual(a['evidence'],b['evidence']);self.assertNotEqual(a['claim'],b['claim'])
 def test_counter_caps_posts_before_transport(self):
  with tempfile.TemporaryDirectory() as t:
   calls=[];r=Recorder(Path(t),lambda *args:calls.append(args) or b'{}');r.context={'model':'zora:fast','case_id':'test'}
   for _ in range(16):r(LOCAL+'/api/chat',payload(),local=True)
   with self.assertRaises(ValueError):r(LOCAL+'/api/chat',payload(),local=True)
   self.assertEqual(r.count,16);self.assertEqual(len(calls),16);self.assertEqual(len((Path(t)/'initiated.jsonl').read_text().splitlines()),16)
 def test_failed_transport_consumes_one_attempt_and_preserves_error(self):
  with tempfile.TemporaryDirectory() as t:
   def fail(*args):raise TimeoutError('fixture timeout')
   r=Recorder(Path(t),fail);r.context={'model':'zora:fast','case_id':'test'}
   with self.assertRaises(TimeoutError):r(LOCAL+'/api/chat',payload(),local=True)
   self.assertEqual(r.count,1);m=json.loads((Path(t)/'01.meta.json').read_text());self.assertEqual(m['status'],'request_error');self.assertTrue((Path(t)/'01.request.json').exists())
 def test_unexpected_budget_prevents_transport(self):
  with tempfile.TemporaryDirectory() as t:
   r=Recorder(Path(t),lambda *a:self.fail('Transport should not run'));r.context={'model':'zora:fast','case_id':'test'};p=payload();p['options']['num_predict']=769
   with self.assertRaises(ValueError):r(LOCAL+'/api/chat',p,local=True)
   self.assertEqual(r.count,0)
 def test_total_limit_prevents_extra_request(self):
  with tempfile.TemporaryDirectory() as t:
   clock=[0];r=Recorder(Path(t),lambda *a:self.fail('Transport should not run'),lambda:clock[0]);clock[0]=1800;r.context={'model':'zora:fast','case_id':'test'}
   with self.assertRaises(ValueError):r(LOCAL+'/api/chat',payload(),local=True)
   self.assertEqual(r.count,0)
 def test_selection_lexicographic_each_priority_and_tie(self):
  a,b=MODELS
  examples=[(stats(errors=0,wrong=5),stats(errors=1,wrong=0),a),(stats(wrong=0,correct=0),stats(wrong=1,correct=8),a),(stats(correct=7,abstain=1),stats(correct=6,abstain=0),a),(stats(correct=6,abstain=1),stats(correct=6,abstain=0),b),(stats(),stats(),a)]
  for x,y,winner in examples:self.assertEqual(ranking_for({a:x,b:y})[0]['model'],winner)
 def test_freeze_hash_tamper_detected(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);(p/'candidate.py').write_text('one');write_json(p/'DEVELOPMENT_FREEZE.json',{'files':{'candidate.py':digest(b'one')}});verify_freeze(p);(p/'candidate.py').write_text('two')
   with self.assertRaises(ValueError):verify_freeze(p)
if __name__=='__main__':unittest.main()
