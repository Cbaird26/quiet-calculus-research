"""Seal completed development after runner process exits and logs stop changing."""
import json
from pathlib import Path
from zora_pilot.core import digest,now,read_json,write_json
from run_development import MODELS,ranking_for,verify_freeze
ROOT=Path(__file__).resolve().parent
def main():
 if (ROOT/'IMPLEMENTATION_FREEZE.json').exists():raise RuntimeError('Final freeze already exists; no overwrite')
 freeze=verify_freeze();selection=read_json(ROOT/'MODEL_SELECTION.json');result=read_json(ROOT/'development_run/RESULTS.json')
 assert result['complete'] and selection['complete']
 assert result['initiated_requests']==selection['initiated_requests']==16
 assert selection['results_sha256']==digest((ROOT/'development_run/RESULTS.json').read_bytes())
 assert selection['development_freeze_sha256']==digest((ROOT/'DEVELOPMENT_FREEZE.json').read_bytes())
 assert selection['models']==result['models']==freeze['models']
 assert selection['ranking']==ranking_for(result['metrics'])
 assert selection['selected_model']==selection['ranking'][0]['model']
 assert selection['selected_model_digest']==selection['models'][selection['selected_model']]['digest']
 cases=[c['id'] for c in read_json(ROOT/'development_cases.json')['cases']]
 expected=[(model,case) for model in MODELS for case in cases]
 assert [(r['model'],r['case_id']) for r in result['rows']]==expected
 raw=ROOT/'development_run/raw_calls'
 entries=[json.loads(s) for s in (raw/'initiated.jsonl').read_text().splitlines()]
 assert [(e['model'],e['case_id']) for e in entries]==expected
 assert len(list(raw.glob('*.request.json')))==len(list(raw.glob('*.meta.json')))==16
 for index in range(1,17):
  prefix=f'{index:02d}';meta=read_json(raw/(prefix+'.meta.json'))
  assert meta['status'] in ('response_received','request_error')
  assert meta['request_sha256']==digest((raw/(prefix+'.request.json')).read_bytes())
  if meta['status']=='response_received':assert meta['response_sha256']==digest((raw/(prefix+'.response.json')).read_bytes())
 files={p.relative_to(ROOT).as_posix():digest(p.read_bytes()) for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='IMPLEMENTATION_FREEZE.json'}
 write_json(ROOT/'IMPLEMENTATION_FREEZE.json',{'created_at':now(),'status':'candidate_and_model_selection_frozen_before_fresh_holdout','files':files,'selected_model':selection['selected_model'],'selected_model_digest':selection['selected_model_digest'],'models':selection['models'],'development_calls':16,'development_freeze_sha256':selection['development_freeze_sha256'],'caveat':'Development model selection only. Semantic labels and guards remain fallible; no physical evidence or general superiority established.'})
 print('IMPLEMENTATION_FREEZE.json '+digest((ROOT/'IMPLEMENTATION_FREEZE.json').read_bytes()))
 print('Inventory files: '+str(len(files)))
if __name__=='__main__':main()
