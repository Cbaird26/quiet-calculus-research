"""Eight author-visible development claims in four paired synthetic records."""
import copy
from pathlib import Path
from zora_pilot.core import evidence,write_json
AS_OF='2026-10-25T12:00:00Z'
def source(eid,text,family):
    return evidence(eid,text,'https://'+family+'.invalid/record',family,'2026-10-25T11:00:00Z','2026-10-25T10:30:00Z')
def build():
    specs=[
      ('open_scope','security_advisory',[
        source('notice','The Oriole mitigation notice recommends disabling feature J. This notice does not include validation experiments or efficacy results.','oriole')],[
        ('At least one laboratory has experimentally validated the Oriole mitigation.','insufficient_evidence','The notice omits validation results; it does not establish whether validation occurred elsewhere.'),
        ('No laboratory has ever experimentally validated the Oriole mitigation.','insufficient_evidence','An omission in this notice does not establish global nonexistence of validation.')]),
      ('document_scope','security_advisory',[
        source('bulletin','The complete Saffron bulletin contains configuration instructions only. It includes no trial outcomes.','saffron')],[
        ('The Saffron bulletin includes no trial outcomes.','supported','The record explicitly establishes the negative claim at document scope.'),
        ('The Saffron bulletin includes at least one trial outcome.','refuted','The same complete-document statement directly contradicts presence of an outcome.')]),
      ('bounded_event','security_advisory',[
        source('study','The complete execution log for Juniper study 7 records zero mitigation trials by the Juniper team during October 20, 2026. No trials were run by that team in that study on that date.','juniper')],[
        ('The Juniper team ran at least one mitigation trial in Juniper study 7 on October 20, 2026.','refuted','Explicit zero execution refutes the positive claim within the named study, team and date.'),
        ('The Juniper team ran no mitigation trials in Juniper study 7 on October 20, 2026.','supported','Explicit zero execution supports the bounded negative claim.')]),
      ('unresolved_conflict','outage',[
        source('panel_a','Monitor A reports: At 10:00 UTC on October 25, 2026, the Kestrel upload endpoint was fully operational. Monitor A and Monitor B both directly observed the same endpoint at that time; neither report has priority, a retraction, or a correction.','monitor-a'),
        source('panel_b','Monitor B reports: At 10:00 UTC on October 25, 2026, the Kestrel upload endpoint was not fully operational. Monitor A and Monitor B both directly observed the same endpoint at that time; neither report has priority, a retraction, or a correction.','monitor-b')],[
        ('The Kestrel upload endpoint was fully operational at 10:00 UTC on October 25, 2026.','insufficient_evidence','The two contemporaneous credible same-scope statements conflict without precedence.'),
        ('The Kestrel upload endpoint was not fully operational at 10:00 UTC on October 25, 2026.','insufficient_evidence','Changing claim polarity does not resolve the same unresolved contradiction.')])]
    cases=[]
    for pair_index,(group,domain,items,claims) in enumerate(specs,1):
        for polarity_index,(claim,gold,rationale) in enumerate(claims,1):
            cases.append({'id':f'F{pair_index}{polarity_index}','record_group':group,'pair':pair_index,'domain':domain,'as_of':AS_OF,'claim':claim,'evidence':copy.deepcopy(items),'gold':gold,'label_rationale':rationale})
    return {'metadata':{'name':'Five-field development set','provenance':'AI-authored synthetic development records and provisional labels; no independent human adjudication. Four record groups, two claims per group, not eight independent events. Never used as a held-out performance estimate.','cases':8,'record_groups':4,'labels':{'supported':2,'refuted':2,'insufficient_evidence':4},'authorship':'Candidate author; labels are visible during development but excluded from model input.','novelty':'New fictional records for this second-stage candidate; designed to exercise the two known mechanisms, not independently sampled.'},'cases':cases}
if __name__=='__main__':write_json(Path(__file__).with_name('development_cases.json'),build())
