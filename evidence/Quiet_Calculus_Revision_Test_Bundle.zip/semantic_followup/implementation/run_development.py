"""Frozen single-use 16-request local development comparison. No inference on import."""
from __future__ import annotations
import argparse,contextlib,json,os,signal,time
from pathlib import Path
from zora_pilot import network
from zora_pilot.core import digest,encoded,now,read_json,write_json
from zora_pilot.evaluation import metrics
from semantic_followup_revision import assess_revised
ROOT=Path(__file__).resolve().parent
MODELS=('zora:fast','gemma4:12b-it-qat')
MAX_CALLS=16
PER_CALL_SECONDS=90
TOTAL_SECONDS=1800
class DeadlineExceeded(TimeoutError):pass
@contextlib.contextmanager
def deadline(seconds):
    def expired(signum,frame):raise DeadlineExceeded('90-second wall-clock request deadline exceeded')
    previous=signal.signal(signal.SIGALRM,expired)
    signal.setitimer(signal.ITIMER_REAL,seconds)
    try:yield
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        signal.signal(signal.SIGALRM,previous)
def verify_freeze(root=ROOT):
    freeze=read_json(root/'DEVELOPMENT_FREEZE.json')
    for rel,want in freeze['files'].items():
        if digest((root/rel).read_bytes())!=want:raise ValueError('Frozen artifact changed: '+rel)
    return freeze
def ranking_for(stats):
    entries=[]
    for name in MODELS:
        m=stats[name]
        key=[m['processing_errors'],m['incorrect_definite_judgments'],-m['correct'],m['unnecessary_abstentions'],0 if name=='zora:fast' else 1]
        entries.append({'model':name,'selection_key':key,'metrics':m})
    return sorted(entries,key=lambda e:e['selection_key'])
class Recorder:
    """Persist each initiated request BEFORE transport; one immutable ledger slot per POST."""
    def __init__(self,folder,transport,clock=time.monotonic):
        self.folder=folder;self.transport=transport;self.clock=clock;self.started=clock();self.count=0;self.context=None
    def __call__(self,url,payload=None,timeout=20,local=False):
        if payload is None:return self.transport(url,payload,timeout,local)
        if url!=network.LOCAL+'/api/chat' or not local:raise ValueError('Only local chat requests accepted')
        if self.count>=MAX_CALLS:raise ValueError('Development request cap reached; no retry or extra request permitted')
        if self.clock()-self.started>=TOTAL_SECONDS:raise ValueError('Development total time limit reached')
        if self.context is None:raise ValueError('Request has no frozen case/model context')
        if payload['model']!=self.context['model'] or payload['options']!={'temperature':0,'seed':42,'num_predict':768,'num_ctx':8192} or payload['think'] is not False:raise ValueError('Unexpected model or generation settings')
        self.count+=1
        prefix=f'{self.count:02d}'
        request=self.folder/(prefix+'.request.json')
        # Preserve actual property order; archive JSON sorting must not alter wire order.
        request.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
        entry={'number':self.count,**self.context,'initiated_at':now(),'timeout_seconds':PER_CALL_SECONDS,'request_sha256':digest(request.read_bytes()),'status':'initiated'}
        meta=self.folder/(prefix+'.meta.json');write_json(meta,entry)
        with (self.folder/'initiated.jsonl').open('ab') as f:f.write(json.dumps(entry).encode()+b'\n');f.flush();os.fsync(f.fileno())
        begin=self.clock()
        try:
            with deadline(min(PER_CALL_SECONDS,max(0.001,TOTAL_SECONDS-(self.clock()-self.started)))):
                response=self.transport(url,payload,PER_CALL_SECONDS,local)
            responsefile=self.folder/(prefix+'.response.json');responsefile.write_bytes(response)
            entry.update(status='response_received',response_sha256=digest(response))
            return response
        except BaseException as exc:
            entry.update(status='request_error',error_type=type(exc).__name__,error=str(exc))
            raise
        finally:
            entry['wall_seconds']=round(self.clock()-begin,6);entry['finished_at']=now();write_json(meta,entry)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--start-authorized',action='store_true');args=parser.parse_args()
    if not args.start_authorized:raise SystemExit('Inference requires the explicit --start-authorized switch after parent authorization.')
    freeze=verify_freeze();cases=read_json(ROOT/'development_cases.json')['cases']
    if len(cases)!=8 or len({c['id'] for c in cases})!=8:raise ValueError('Expected exactly eight unique development claims')
    run=ROOT/'development_run';run.mkdir(exist_ok=False);raw=run/'raw_calls';raw.mkdir()
    started=now();tick=time.monotonic();rows=[]
    # These constructors only GET installed metadata and do not load models.
    clients={name:network.Ollama(name,timeout=PER_CALL_SECONDS) for name in MODELS}
    model_info={name:c.info for name,c in clients.items()}
    if model_info!=freeze['models']:raise ValueError('Installed model metadata changed after freeze')
    write_json(run/'models_at_start.json',model_info)
    original=network.request_bytes;recorder=Recorder(raw,original);network.request_bytes=recorder
    try:
        for model in MODELS:
            for original_case in cases:
                case={k:original_case[k] for k in ('id','domain','as_of','claim','evidence')}
                recorder.context={'model':model,'case_id':case['id']}
                row=assess_revised(case,clients[model],generation_cap=768);row['model']=model;rows.append(row)
                with (run/'rows.jsonl').open('ab') as f:f.write(json.dumps(row,ensure_ascii=False).encode()+b'\n');f.flush();os.fsync(f.fileno())
                write_json(run/'progress.json',{'started_at':started,'rows':len(rows),'initiated_requests':recorder.count,'last_case':case['id'],'last_model':model})
                print(f"{len(rows):02d}/16 {model} {case['id']}: {'processing_error' if row['processing_error'] else row['result']['verdict']}",flush=True)
    finally:network.request_bytes=original
    gold={c['id']:c['gold'] for c in cases}
    stats={name:metrics([r for r in rows if r['model']==name],gold) for name in MODELS}
    for name,m in stats.items():
        definite=sum(not r['processing_error'] and r['result']['verdict']!='insufficient_evidence' for r in rows if r['model']==name)
        m['definite_count']=definite;m['selective_error']=m['incorrect_definite_judgments']/definite if definite else None
    complete=len(rows)==16 and recorder.count==16
    result={'complete':complete,'started_at':started,'completed_at':now(),'elapsed_seconds':round(time.monotonic()-tick,6),'initiated_requests':recorder.count,'models':model_info,'metrics':stats,'rows':rows,'dataset_sha256':freeze['files']['development_cases.json'],'development_freeze_sha256':digest((ROOT/'DEVELOPMENT_FREEZE.json').read_bytes()),'token_caveat':'Reported tokens only. Interrupted/timeout calls may consume unreported compute; request failures are preserved and never counted as valid abstentions.','independence_caveat':'Eight author-visible development claims from four shared record groups; model selection evidence, not held-out validation.'}
    write_json(run/'RESULTS.json',result)
    if not complete:raise RuntimeError('Incomplete development: no model may be selected')
    ranking=ranking_for(stats);selected=ranking[0]['model']
    selection={'selected_model':selected,'selected_model_digest':model_info[selected]['digest'],'models':model_info,'ranking':ranking,'rule':['min processing failures','min incorrect definite judgments','max total correct','min unnecessary abstentions','prefer zora:fast on exact tie'],'complete':True,'initiated_requests':recorder.count,'results_sha256':digest((run/'RESULTS.json').read_bytes()),'development_freeze_sha256':digest((ROOT/'DEVELOPMENT_FREEZE.json').read_bytes()),'selected_at':now(),'caveat':'Selection is based only on eight author-visible paired development claims per model; it is not general performance evidence.'}
    write_json(ROOT/'MODEL_SELECTION.json',selection)
    print('Selected '+selected+' by the frozen lexicographic rule.',flush=True)
if __name__=='__main__':main()
