"""Create the pre-inference freeze once; metadata GET only, no model load/chat."""
import json,platform,subprocess,sys
from pathlib import Path
from zora_pilot.core import digest,now,read_json,write_json
from zora_pilot.network import Ollama
from semantic_followup_revision import PROMPT,CONFIG,method_info
from run_development import MODELS,MAX_CALLS,PER_CALL_SECONDS,TOTAL_SECONDS
ROOT=Path(__file__).resolve().parent
SOURCE=Path('/Users/christophermichaelbaird/Documents/ChatGPT/ZoraASI/zora_integrity_pilot/zora_pilot')
def main():
 if (ROOT/'DEVELOPMENT_FREEZE.json').exists():raise RuntimeError('Development is already frozen; no overwrites')
 subprocess.run([sys.executable,str(ROOT/'development_cases.py')],check=True,cwd=ROOT)
 checked=subprocess.run([sys.executable,'-m','unittest','-v','test_followup','test_development_runner'],cwd=ROOT,text=True,capture_output=True)
 (ROOT/'software_checks.txt').write_text(checked.stdout+checked.stderr)
 if checked.returncode:raise RuntimeError('Software checks failed; no freeze')
 sources={}
 for path in sorted((ROOT/'zora_pilot').glob('*.py')):
  original=SOURCE/path.name
  current=digest(path.read_bytes());source_hash=digest(original.read_bytes())
  if current!=source_hash:raise RuntimeError('Baseline dependency changed: '+path.name)
  sources[path.relative_to(ROOT).as_posix()]={'original':str(original),'sha256':current}
 if len(sources)!=9:raise RuntimeError('Expected nine unchanged baseline Python files')
 # Constructor only reads installed /api/tags; it does not load model weights.
 models={name:Ollama(name).info for name in MODELS}
 (ROOT/'PROMPT.txt').write_text(PROMPT)
 write_json(ROOT/'METHOD.json',method_info())
 write_json(ROOT/'MODEL_METADATA.json',{'observed_at':now(),'models':models,'method':'GET /api/tags only; no model loads or generation','interpretation':'Larger model metadata is not evidence of better performance.'})
 write_json(ROOT/'SOURCE_HASHES.json',sources)
 write_json(ROOT/'ENVIRONMENT.json',{'captured_at':now(),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'machine':platform.machine(),'network':'Fixed loopback Ollama only; no remote inference or source collection'})
 protocol={'created_at':now(),'stage':'disclosed second-stage candidate prompted by prior-stage errors','candidate_count':1,'development_cases':8,'underlying_record_groups':4,'model_order':list(MODELS),'case_order':[c['id'] for c in read_json(ROOT/'development_cases.json')['cases']],'maximum_initiated_requests':MAX_CALLS,'per_call_wall_seconds':PER_CALL_SECONDS,'total_wall_seconds':TOTAL_SECONDS,'config':CONFIG,'retries':0,'tuning':'No code, prompt, configuration, or development-label edits after this freeze; no second candidate.','selection':['fewer processing failures','fewer incorrect definite judgments','more total correct','fewer unnecessary abstentions','zora:fast on tie'],'outputs':['all initiated requests, response bytes or error','latency and reported tokens','model metadata and complete ranking'],'scope':'Eight author-visible synthetic claims from four paired records; model selection only, no independent performance estimate. No physical evidence.','heldout_access':'Candidate author must not inspect any heldout records/results during candidate preparation or selection.','resource_caveat':'Model order is fixed in blocks to avoid repeated weight loading; timing includes first-call load overhead. Tokens are only those reported by completed API responses.','authorization':'No calls until explicit parent authorization; runner requires --start-authorized.'}
 write_json(ROOT/'DEVELOPMENT_PROTOCOL.json',protocol)
 excluded={'DEVELOPMENT_FREEZE.json','IMPLEMENTATION_FREEZE.json','MODEL_SELECTION.json'}
 files={p.relative_to(ROOT).as_posix():digest(p.read_bytes()) for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and 'development_run' not in p.parts and p.name not in excluded}
 write_json(ROOT/'DEVELOPMENT_FREEZE.json',{'created_at':now(),'status':'frozen_before_inference','files':files,'models':models,'config':CONFIG,'call_cap':MAX_CALLS,'no_inference_started':True,'limitations':'Hash agreement verifies byte identity, not semantic correctness.'})
 print('DEVELOPMENT_FREEZE.json '+digest((ROOT/'DEVELOPMENT_FREEZE.json').read_bytes()))
 print('Frozen files: '+str(len(files)))
if __name__=='__main__':main()
