#!/usr/bin/env python3
"""Replay exposed follow-up cases outside the delivered evidence tree."""
from pathlib import Path
import shutil,subprocess,sys
root=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('Usage: python3 -B reproduce_to.py /absolute/path/to/new-replay-root')
dest=Path(sys.argv[1]).expanduser().resolve()
if dest.exists() or dest==root.parent or root.parent in dest.parents:raise SystemExit('Choose a new destination outside the delivered revision evidence tree.')
def ignore(src,names):
 omitted={n for n in names if n=='__pycache__' or n.endswith('.pyc')}
 if Path(src).resolve()==root:omitted.update(set(names)&{'raw_calls','result.json','result.sha256','summary.json','progress.json','audit.json','run.log'})
 return omitted
follow=dest/'semantic_followup';shutil.copytree(root,follow,ignore=ignore)
prior=dest/'semantic';prior.mkdir()
for name in ['result.json','audit.json']:shutil.copy2(root.parent/'semantic'/name,prior/name)
(dest/'REPLAY_NOTICE.txt').write_text('This is a replay of the exposed follow-up benchmark, not a fresh held-out test. The semantic sibling contains only the two immutable first-stage reference records needed for hash binding, not its complete original evidence. The original full bundle remains unchanged.\n')
subprocess.run([sys.executable,'-B','evaluate.py','--run'],cwd=follow,check=True)
subprocess.run([sys.executable,'-B','audit_results.py'],cwd=follow,check=True)
print('Replay saved to',dest)
