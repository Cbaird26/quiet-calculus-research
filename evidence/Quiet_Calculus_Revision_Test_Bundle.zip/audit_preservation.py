#!/usr/bin/env python3
"""Confirm earlier evidence and manuscript results were preserved, not rewritten."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
record=json.loads((ROOT/'prior-results-preservation.json').read_text())
original=Path(record['prior_root']);failures=[]
for item in record['files']:
 p=original/item['path']
 if not p.exists() or sha(p)!=item['sha256']:failures.append(item['path'])
archive=BASE/'output/pdf/quiet-calculus-version-3-archive'
for name,key in [('Quiet_Calculus_Scientific_Paper.pdf','pdf_sha256'),('Quiet_Calculus_Overleaf.zip','overleaf_zip_sha256'),('Quiet_Calculus_Local_Test_Bundle.zip','test_zip_sha256')]:
 if sha(archive/name)!=record['version3_delivery'][key]:failures.append('archived '+name)
paper=BASE/'output/pdf/quiet-calculus-scientific-paper-2026-10-25'
with zipfile.ZipFile(archive/'Quiet_Calculus_Overleaf.zip') as z:
 original_results=z.read('sections/14_local_tests.tex')
 if original_results!=(paper/'sections/14_local_tests.tex').read_bytes():failures.append('original result section changed')
 sources=json.loads(z.read('data/research_sources.json'))['sources']
 for item in sources:
  if sha(item['path'])!=item['sha256']:failures.append('source '+item['path'])
report={'passed':not failures,'earlier_experiment_files_checked':len(record['files']),'version3_archives_checked':3,'original_results_section_byte_identical':not 'original result section changed' in failures,'research_sources_checked':len(sources),'failures':failures,'scope':'Artifact/source integrity, not truth or scientific validation.'}
(ROOT/'preservation_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
assert not failures,failures
