#!/usr/bin/env python3
"""Artifact and arithmetic audit without any model calls or label changes."""
from pathlib import Path
import hashlib,json,sys
from collections import Counter
from datetime import datetime
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'implementation'))
from zora_pilot.core import model_input
from zora_pilot.pipeline import PROMPTS
from semantic_revision import PROMPT,CONFIG,map_certificate,safe_inputs
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
checks=[]
def check(condition,description):
 checks.append({'passed':bool(condition),'description':description})
 if not condition:raise AssertionError(description)

freeze=read(ROOT/'evaluation_freeze.json');data=read(ROOT/'heldout/dataset.json');result=read(ROOT/'result.json')
implementation_freeze=read(ROOT/'implementation/IMPLEMENTATION_FREEZE.json')
holdout_freeze=read(ROOT/'heldout/FREEZE.json')
check(implementation_freeze['authoritative'],'corrected implementation marker is authoritative')
for rel,digest in implementation_freeze['files'].items():check(sha(ROOT/'implementation'/rel)==digest,'implementation inventory '+rel)
for rel,digest in holdout_freeze['files'].items():check(sha(ROOT/'heldout'/rel)==digest,'holdout inventory '+rel)
check(sha(ROOT/'heldout/FREEZE.json')==freeze['holdout_freeze_sha256'],'heldout freeze hash')
check(datetime.fromisoformat(holdout_freeze['frozen_utc'])<datetime.fromisoformat(freeze['created_at']),'holdout sealed before evaluation')
check(datetime.fromisoformat(implementation_freeze['frozen_at'])<datetime.fromisoformat(freeze['created_at']),'implementation sealed before evaluation')
check(sha(ROOT/'result.json')==(ROOT/'result.sha256').read_text().strip(),'sealed result hash')
for rel,digest in freeze['files'].items():check(sha(ROOT/rel)==digest,'unchanged '+rel)
check(len(result['rows'])==72 and result['complete'],'complete paired observations')
check(len({c['id'] for c in data['cases']})==36,'unique case identities')
case_map={c['id']:c for c in data['cases']};seen=[]
records=sorted((ROOT/'raw_calls').glob('*.request.json'));check(len(records)==72,'72 raw requests')
rawcounts=Counter();tokens={a:[0,0] for a in ['old_single','revised_single']}
for request in records:
 r=read(request);meta=r['row'];arm=meta['arm'];cid=meta['case_id'];seen.append((cid,arm));payload=r['payload'];case=case_map[cid]
 check(datetime.fromisoformat(r['started_at'])>datetime.fromisoformat(freeze['created_at']),'request after freeze '+cid+' '+arm)
 expected=model_input(case) if arm=='old_single' else safe_inputs(case)
 check(json.loads(payload['messages'][1]['content'])==expected,'allowlisted exact evidence input '+cid+' '+arm)
 check(payload['messages'][0]['content']==(PROMPTS['baseline'] if arm=='old_single' else PROMPT),'frozen prompt '+cid+' '+arm)
 check(payload['options']=={'temperature':0,'seed':42,'num_predict':768,'num_ctx':8192},'fixed inference settings '+cid+' '+arm)
 check(payload['model']==CONFIG['model'] and payload['think'] is False,'fixed local model '+cid+' '+arm)
 response=request.with_name(request.name.replace('.request.json','.response.json'))
 error=request.with_name(request.name.replace('.request.json','.error.json'))
 row=next(x for x in result['rows'] if x['case_id']==cid and x['mode']==arm)
 if response.exists():
  raw=read(response);tokens[arm][0]+=raw.get('prompt_eval_count',0);tokens[arm][1]+=raw.get('eval_count',0)
  check(row['calls'][0]['raw_content']==raw.get('message',{}).get('content',''),'raw output bound to row '+cid+' '+arm)
  if arm=='revised_single' and not row['processing_error']:
   wire=json.loads(raw['message']['content'])
   check(map_certificate(wire,expected['evidence'])==row['result'],'certificate mapping reproduced '+cid)
 else:check(error.exists() and row['processing_error'],'transport failure retained '+cid+' '+arm)
 rawcounts[arm]+=1
check(len(seen)==len(set(seen))==72,'no retries or duplicate arm-case rows')
schedule=[]
for block,start in enumerate(range(0,36,6)):
 for arm in (['revised_single','old_single'] if block%2==0 else ['old_single','revised_single']):
  schedule.extend((case['id'],arm) for case in data['cases'][start:start+6])
check(seen==schedule,'frozen balanced block schedule')
recomputed={}
for arm in ['old_single','revised_single']:
 rows=[r for r in result['rows'] if r['mode']==arm]
 valid=[r for r in rows if not r['processing_error']]
 definite=[r for r in valid if r['result']['verdict']!='insufficient_evidence']
 counts={'cases':len(rows),'correct':sum(r['result']['verdict']==case_map[r['case_id']]['gold'] for r in valid),'processing_errors':len(rows)-len(valid),'incorrect_definite_judgments':sum(r['result']['verdict']!=case_map[r['case_id']]['gold'] for r in definite),'unnecessary_abstentions':sum(r['result']['verdict']=='insufficient_evidence' and case_map[r['case_id']]['gold']!='insufficient_evidence' for r in valid),'false_confirmations':sum(r['result']['verdict']=='supported' and case_map[r['case_id']]['gold']!='supported' for r in valid),'input_tokens':tokens[arm][0],'output_tokens':tokens[arm][1]}
 for k,v in counts.items():check(v==result['metrics'][arm][k],'independent metric '+arm+' '+k)
 recomputed[arm]=counts
old,new=[recomputed[x] for x in ['old_single','revised_single']]
gate=new['incorrect_definite_judgments']<old['incorrect_definite_judgments'] and new['correct']>=old['correct'] and new['unnecessary_abstentions']<=old['unnecessary_abstentions'] and new['processing_errors']<=old['processing_errors']
check(gate==result['gate']['passed'],'frozen joint gate arithmetic')
report={'passed':True,'checks':len(checks),'check_details':checks,'recomputed':recomputed,'result_sha256':sha(ROOT/'result.json'),'scope':'Independent artifact and arithmetic checks on the same recorded run; no new inference, human labels, or physical evidence.'}
(ROOT/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='check_details'},indent=2))
