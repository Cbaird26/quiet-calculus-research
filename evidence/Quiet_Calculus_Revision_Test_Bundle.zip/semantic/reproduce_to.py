#!/usr/bin/env python3
"""Replay the exposed semantic benchmark in a new directory; never overwrite evidence."""
from pathlib import Path
import shutil,subprocess,sys
root=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('Usage: python3 -B reproduce_to.py /absolute/path/to/new-directory')
dest=Path(sys.argv[1]).expanduser().resolve()
if not dest.is_absolute() or dest.exists() or dest==root.parent or root.parent in dest.parents:raise SystemExit('Choose a new destination outside the delivered revision evidence tree.')
def ignore(src,names):
 omitted={n for n in names if n=='__pycache__' or n.endswith('.pyc')}
 if Path(src).resolve()==root:
  omitted.update(set(names)&{'raw_calls','result.json','result.sha256','summary.json','progress.json','audit.json','run.log'})
 return omitted
shutil.copytree(root,dest,ignore=ignore)
# --run verifies all frozen inputs and the exact local model; no new case labels are invented.
# This is a replay of already exposed cases, not a new held-out generalization test.
subprocess.run([sys.executable,'-B','evaluate.py','--run'],cwd=dest,check=True)
subprocess.run([sys.executable,'-B','audit_results.py'],cwd=dest,check=True)
print('Replay saved to',dest)
