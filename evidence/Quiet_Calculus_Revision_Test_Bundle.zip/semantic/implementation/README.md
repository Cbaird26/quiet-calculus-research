# Scope/witness semantic revision

This additive, isolated revision targets two observed failures: inferring global
nonexistence from missing reported results, and treating unresolved same-scope
source disagreement as a definite refutation. The original pilot files are
copied unchanged under `zora_pilot/`; `SOURCE_HASHES.json` binds the nine source
files. No original research tree was edited.

## Importable interface

```python
from zora_pilot.network import Ollama
from zora_pilot.pipeline import assess              # unchanged comparator
from semantic_revision import assess_revised

client = Ollama("zora:fast", timeout=60)
old = assess(case, client, mode="baseline", per_role_cap=256)
new = assess_revised(case, client, generation_cap=768)
```

The case has `id`, `domain`, `as_of`, `claim`, and `evidence`. Expected labels are
neither needed nor read. The new function uses outer and nested evidence field
allowlists; case ID is returned for bookkeeping but is absent from model input.
It performs exactly one client call and returns the prior pilot row shape:
`result`, `calls`, `processing_error`, token counts, elapsed time and exclusions.
Raw certificate, final mapping rule and generated text remain in the call record.
An existing local model client is supplied by the caller. The evaluation runner
must verify the installed model digest against `method_info()['config']`; the
function does not inspect accounts, fetch evidence or download a model.

Both arms use a 768-token generation allowance and context 8192, temperature 0,
seed 42 and thinking disabled through the unchanged local client. Extra schema
and prompt fields may increase actual input/output tokens and latency. Equal
allowance is not equal total compute. The experiment records those differences.

## Mechanism

The model emits a compact scope/witness certificate instead of a final decision. A single shared list of up to two quotations is referenced by integer indices (`pos_ref`, `neg_ref`, `complete_ref`, `resolution_ref`); -1 means absent:

- Exact scope, attribution and open/explicitly exhaustive world assumption.
- Positive and negative witness kinds and their exact quotations.
- Whether all necessary positive parts of a claim are supported.
- Any explicit completeness evidence needed for inference from omission.
- Whether relevant evidence is in conflict and whether supplied, cited
  supersession, priority, or differing scope resolves it.

The deterministic mapper rejects unrecognized/malformed certificates and bad
citations as processing errors. It does not read reasoning prose to guess a
verdict. Unsupported omissions cannot serve as witnesses. Closed-world
inference requires both an explicitly exhaustive assumption and a completeness
quotation. Any declared unresolved conflict dominates individual witnesses;
opposed deciding witnesses require a cited resolution. Genuine unilateral
positive/negative witnesses still yield supported/refuted judgments. Document
content and explicitly exhaustive-domain claims remain eligible for decisions.

These are semantic fields selected by a fallible model. A genuine quotation
can still be misclassified as a witness, falsely called exhaustive, or attached
to an invented priority. The mapper validates structural consistency, not
semantic entailment, source truth, or logical completeness. The negative-control
test deliberately supplies a wrong semantic certificate with a genuine quote
and confirms this remaining limitation. There is no case-ID or keyword-based
verdict override and no oracle metadata. The method is a combined prompt,
output-schema and decision-mapping revision; it is not a causal ablation of its
individual parts and does not prove universal correction of either failure.

## Development and immutable evaluation boundary

`test_semantic_revision.py` contains 21 software regression/invariant tests,
including decisive answers, open-world omission, explicit closed-world cases,
conflict/precedence, hidden-label exclusion, processing failures and a semantic
negative control. Run `python3 -m unittest test_semantic_revision -v`.

`development/` preserves the initial large-certificate attempt: its first call timed out at 60 seconds and its second pending call was explicitly interrupted. The variant source, script, initial freeze, request bytes, partial checkpoint, error and abort reason remain archived. The cause of that timeout is not established by this comparison.

`development-compact/` preserves the first compact candidate. Four calls completed; two unnecessarily abstained, on directly stated document contents and narrow publisher attribution. Its fifth call was interrupted before another schema/prompt revision. The earlier `ABORTED.json` was written from an out-of-date snapshot and is retained unchanged; `DEVELOPMENT_REPORT.json` gives the corrected counts. All outputs and that unfavorable result remain preserved. The final category is `unsupported_absence_inference`, explicitly distinguished from direct statements about absence within the claim's own scope. This is a generic semantic distinction; there are no case-ID, source-name, or keyword verdict rules.

`development-final/` preserves the next typed compact candidate's completed six-case run: 4/6 provisional matches. It corrected the narrow document-content absence but still misclassified an external existence claim as a record claim, and unnecessarily abstained on narrow publisher attribution in the presence of opposing world evidence. The unfavorable outputs remain unchanged.

The final revision adds a generic claim-scope and literal-compatibility instruction: determine attribution from the claim itself, not from the existence of documents in the input; reporting a proposition is compatible with that proposition being false; absence of a report is compatible with an event existing elsewhere. There is no lexical/case-specific verdict override. The deterministic mapping and quote validation remain the same as the typed compact candidate.

`development-scope-final/` holds four separately recorded final-candidate development calls, covering open-world omission, explicit document-content absence, genuine same-domain refutation, and unresolved conflict. It includes a code/data freeze, exact requests/responses, provisional labels and all outcomes. These repeatedly inspected development examples are not held out or independently adjudicated.

Seventeen calls were actually initiated across all four variants: two in the initial attempt, five in the first compact attempt, six in the typed compact attempt, and four in the final scope-clarification run. The original 12-call development allowance was extended to 16 with root authorization before held-out inference. The actual count exceeded that cap by one: the compact runner began its fifth request before the interrupt arrived. This protocol deviation is retained and disclosed; no model output was excluded or relabeled to improve performance. Two pending calls were deliberately interrupted between revisions. Reusing development examples after disclosed revisions is not held-out evidence. Failed attempts are not scored as successful abstentions, and no variant automatically retries. No held-out test files or content were accessed by this author.
The separate evaluation author and root runner retain the new test cases.

`IMPLEMENTATION_FREEZE.json` is written only after development and final checks.
It records every implementation/protocol/development file hash and source hash.
No implementation, prompt, schema, configuration or documentation changes are
permitted after that marker for the planned held-out evaluation. A later change
requires another revision and a newly protected test set. This is a local
internal freeze, not a public independent preregistration.

These computations observe model/software behavior only. They provide no
physical evidence, field detection, or machine-consciousness measurement.

Final development readiness result: 4/4 provisional matches in 52.53 seconds, zero processing failures, on four repeatedly inspected regression cases. This is not a held-out performance claim. DEVELOPMENT_REPORT.json is the authoritative development accounting.

Freeze correction: the first marker was inadvertently written after a preceding accounting assertion failed. It is preserved byte-for-byte as IMPLEMENTATION_FREEZE.superseded-count-error.json. Before any held-out inference, only documentation/accounting/freeze metadata were corrected with root authorization. All Python code, model prompt, schema, mapping and configuration stayed byte-identical. The authoritative marker is IMPLEMENTATION_FREEZE.json. The earlier freeze_implementation.py helper is preserved as part of that history and must not be used to regenerate this corrected record.
