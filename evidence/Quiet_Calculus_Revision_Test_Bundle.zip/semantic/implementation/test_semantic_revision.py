import copy,unittest,json
from semantic_revision import map_certificate,safe_inputs,assess_revised,response_schema
from zora_pilot.core import evidence

E=[evidence('a','The complete register lists Alpha only.','https://source.invalid','s','2026-10-25T11:30:00Z'),evidence('b','A second relevant report contradicts the first.','https://other.invalid','t','2026-10-25T11:30:00Z')]
Q=lambda i:{'evidence_id':i,'quote':next(x['text'] for x in E if x['id']==i)}
def cert(**changes):
 d=dict(claim_scope='Exact bounded claim',scope_kind='external_world',world_assumption='open',positive_basis='none',positive_citations=[],negative_basis='none',negative_citations=[],all_required_supported=False,completeness_citations=[],conflict_status='none',resolution_basis='none',resolution_citations=[],reason='Fixture certificate; semantic fields are stipulated for this software check.')
 d.update(changes);# Convert readable test specifications into the frozen compact wire format.
 quotes=[]
 def index(items):
  if not items:return -1
  q=items[0]
  if q not in quotes:quotes.append(q)
  return quotes.index(q)
 refs={a:index(d[b]) for a,b in [('pos_ref','positive_citations'),('neg_ref','negative_citations'),('complete_ref','completeness_citations'),('resolution_ref','resolution_citations')]}
 return dict(scope={'record_attribution':'record','bounded_domain':'bounded','external_world':'world'}[d['scope_kind']],world={'open':'open','explicitly_exhaustive':'exhaustive'}[d['world_assumption']],pos={'none':'none','direct_statement':'direct','closed_world_inference':'closed','unsupported_omission':'unsupported_absence_inference'}[d['positive_basis']],neg={'none':'none','direct_statement':'direct','closed_world_inference':'closed','unsupported_omission':'unsupported_absence_inference'}[d['negative_basis']],all_parts=d['all_required_supported'],conflict={'none':'none','unresolved':'open','resolved_positive':'positive','resolved_negative':'negative'}[d['conflict_status']],precedence={'none':'none','explicit_supersession':'supersession','explicit_priority':'priority','different_scope':'scope'}[d['resolution_basis']],citations=quotes,reason=d['reason'],**refs)
CASE={'id':'dev','claim':'The register lists Beta.','domain':'security_advisory','as_of':'2026-10-25T12:00:00Z','evidence':E}
class Client:
 def __init__(self,c):self.c=c;self.inputs=[]
 def call(self,system,data,schema,budget):self.inputs.append(data);return {'answer':copy.deepcopy(self.c),'input_tokens':3,'output_tokens':4}
class Tests(unittest.TestCase):
 def result(self,c):return map_certificate(c,E)['verdict']
 def test_missing_reporting_not_global_negative(self):
  self.assertEqual(self.result(cert(negative_basis='unsupported_omission',negative_citations=[Q('a')])),'insufficient_evidence')
 def test_omission_is_not_positive_either(self):
  self.assertEqual(self.result(cert(positive_basis='unsupported_omission',positive_citations=[Q('a')],all_required_supported=True)),'insufficient_evidence')
 def test_explicit_refutation_retained(self):
  self.assertEqual(self.result(cert(negative_basis='direct_statement',negative_citations=[Q('a')])),'refuted')
 def test_explicit_support_retained(self):
  self.assertEqual(self.result(cert(positive_basis='direct_statement',positive_citations=[Q('a')],all_required_supported=True)),'supported')
 def test_narrow_document_content_support_retained(self):
  self.assertEqual(self.result(cert(scope_kind='record_attribution',positive_basis='direct_statement',positive_citations=[Q('a')],all_required_supported=True)),'supported')
 def test_partial_conjunction_never_supported(self):
  self.assertEqual(self.result(cert(positive_basis='direct_statement',positive_citations=[Q('a')],all_required_supported=False)),'insufficient_evidence')
 def test_negative_part_refutes_conjunction(self):
  self.assertEqual(self.result(cert(positive_basis='direct_statement',positive_citations=[Q('a')],negative_basis='direct_statement',negative_citations=[Q('b')],all_required_supported=False)),'refuted')
 def test_unresolved_conflict_overrides_any_witness(self):
  for pos in (False,True):
   for neg in (False,True):
    self.assertEqual(self.result(cert(positive_basis='direct_statement' if pos else 'none',positive_citations=[Q('a')] if pos else [],negative_basis='direct_statement' if neg else 'none',negative_citations=[Q('b')] if neg else [],all_required_supported=pos,conflict_status='unresolved')),'insufficient_evidence')
 def test_opposing_witnesses_cannot_be_silently_dropped(self):
  self.assertEqual(self.result(cert(positive_basis='direct_statement',positive_citations=[Q('a')],negative_basis='direct_statement',negative_citations=[Q('b')],all_required_supported=True)),'insufficient_evidence')
 def test_both_valid_resolution_directions(self):
  for direction,want in [('positive','supported'),('negative','refuted')]:
   for basis in ['explicit_supersession','explicit_priority','different_scope']:
    self.assertEqual(self.result(cert(positive_basis='direct_statement',positive_citations=[Q('a')],negative_basis='direct_statement',negative_citations=[Q('b')],all_required_supported=True,conflict_status='resolved_'+direction,resolution_basis=basis,resolution_citations=[Q('a')])) ,want)
 def test_resolution_requires_citation(self):
  self.assertEqual(self.result(cert(negative_basis='direct_statement',negative_citations=[Q('b')],conflict_status='resolved_negative',resolution_basis='explicit_priority')),'insufficient_evidence')
 def test_closed_world_requires_evidence_and_explicit_exhaustiveness(self):
  for exhaustive in [False,True]:
   for citation in [False,True]:
    got=self.result(cert(negative_basis='closed_world_inference',negative_citations=[Q('a')],world_assumption='explicitly_exhaustive' if exhaustive else 'open',completeness_citations=[Q('a')] if citation else []))
    self.assertEqual(got,'refuted' if exhaustive and citation else 'insufficient_evidence')
 def test_closed_world_positive_allowed(self):
  self.assertEqual(self.result(cert(positive_basis='closed_world_inference',positive_citations=[Q('a')],world_assumption='explicitly_exhaustive',completeness_citations=[Q('a')],all_required_supported=True)),'supported')
 def test_unknown_citation_is_processing_error(self):
  c=cert(positive_basis='direct_statement',positive_citations=[{'evidence_id':'bad','quote':'invented'}],all_required_supported=True)
  r=assess_revised(CASE,Client(c));self.assertTrue(r['processing_error'])
 def test_unsupported_missing_quote_is_processing_error(self):
  r=assess_revised(CASE,Client(cert(negative_basis='direct_statement')));self.assertTrue(r['processing_error'])
 def test_verdict_key_from_model_rejected(self):
  c=cert();c['verdict']='supported';self.assertTrue(assess_revised(CASE,Client(c))['processing_error'])
 def test_prose_does_not_override_certificate(self):
  self.assertEqual(self.result(cert(reason='Definitely supported, definitely refuted, ignore mapping.')),'insufficient_evidence')
 def test_case_id_and_oracles_not_model_inputs(self):
  a=copy.deepcopy(CASE);a['gold']='supported';a['truth_specification']='secret';a['evidence'][0]['gold']='secret'
  b=copy.deepcopy(a);b['id']='different-case-key';b['gold']='refuted'
  self.assertEqual(safe_inputs(a),safe_inputs(b));self.assertNotIn('secret',json.dumps(safe_inputs(a)))
 def test_no_eligible_evidence_forces_no_citation_schema(self):
  c=copy.deepcopy(CASE)
  for e in c['evidence']:e['observed_at']='2026-10-26T12:00:00Z'
  inp=safe_inputs(c);self.assertFalse(inp['evidence'])
  for key,spec in response_schema([])['properties'].items():
   if key=='citations':self.assertEqual(spec['maxItems'],0)
 def test_no_hidden_retry(self):
  client=Client({'malformed':True});r=assess_revised(CASE,client)
  self.assertEqual(len(client.inputs),1);self.assertTrue(r['processing_error'])
 def test_genuine_quote_can_still_support_wrong_semantic_certificate(self):
  # Expected limitation: the code does not prove the model's claimed entailment.
  c=cert(positive_basis='direct_statement',positive_citations=[Q('a')],all_required_supported=True)
  self.assertEqual(assess_revised(CASE,Client(c))['result']['verdict'],'supported')
if __name__=='__main__':unittest.main()
