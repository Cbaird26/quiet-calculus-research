"""Eight authored development cases; never opens held-out inputs."""
import json,time,hashlib,platform,sys
from pathlib import Path
from semantic_revision import assess_revised,method_info,CONFIG
from zora_pilot.core import evidence,now,write_json,digest,seal
import zora_pilot.network as net
ROOT=Path(__file__).resolve().parent;D=ROOT/'development-scope-final';D.mkdir(exist_ok=False)
T='2026-10-25T12:00:00Z';O='2026-10-25T11:40:00Z'
def e(i,text,family='publisher',obs=O):return evidence(i,text,'https://'+family+'.invalid/record',family,obs)
def c(i,claim,ev,gold):return dict(id=i,domain='security_advisory',claim=claim,as_of=T,evidence=ev,gold=gold)
cases=[
c('DEV01','Experimental verification of the Falcon mitigation exists.',[e('a','The Falcon notice recommends disabling previews. This document provides no efficacy test results.')],'insufficient_evidence'),
c('DEV02','The Opal notice contains no efficacy test results.',[e('a','The Opal notice contains no efficacy test results. It provides a recommendation only.')],'supported'),
c('DEV03','The Vale team conducted an efficacy experiment in study V9.',[e('a','Vale team study V9 methods: no efficacy experiment was conducted in this study. Only recommendations were drafted.')],'refuted'),
c('DEV04','Sable publisher reports that its service has recovered.',[e('a','Sable publisher report: our service has recovered.','sable'),e('b','An independent probe reports Sable remains unavailable at the same time.','probe')],'supported'),
c('DEV05','Tern service has recovered.',[e('a','Tern publisher: all regions recovered at 11:30 UTC.','tern'),e('b','Independent Tern monitor: all regions remain unavailable at 11:30 UTC. No precedence or reconciliation is available.','monitor')],'insufficient_evidence'),
c('DEV06','The complete Umber register lists component Delta as affected.',[e('a','The complete Umber register of affected components for this issue contains exactly Alpha and Beta. This is an exhaustive list.')],'refuted'),
c('DEV07','The complete Wren test log contains zero failed trials.',[e('a','The complete Wren log contains every trial in the study: 12 passed, zero failed. No trials are omitted.')],'supported'),
c('DEV08','The latest Yarrow report says the incident is resolved.',[e('a','Yarrow report 11:00 UTC: incident unresolved.','yarrow','2026-10-25T11:05:00Z'),e('b','Yarrow correction 11:35 UTC explicitly supersedes the 11:00 report: incident resolved.','yarrow')],'supported')]
cases=[cases[i] for i in (0,1,2,4)]
write_json(D/'dataset.json',{'metadata':{'purpose':'Authored development and regression cases; not held out.','author':'implementation author','physical_evidence':False},'cases':cases})
client=net.Ollama('zora:fast',60);assert client.info['digest']==CONFIG['model_digest']
freeze={'frozen_at':now(),'method':method_info(),'model':client.info,'files':{str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in [ROOT/'semantic_revision.py',ROOT/'run_development.py',D/'dataset.json']},'environment':{'python':sys.version,'platform':platform.platform()},'max_calls':4,'per_call_timeout':60,'total_runtime_cap':600}
write_json(D/'freeze.json',freeze)
orig=net.request_bytes;count=0;t0=time.monotonic()
def record(url,payload=None,timeout=20,local=False):
 global count
 assert local and url==net.LOCAL+'/api/chat';assert count<4
 if time.monotonic()-t0>=600:raise TimeoutError('development total limit')
 count+=1;stem=D/f'call-{count:02d}'
 write_json(str(stem)+'.request.json',{'payload':payload,'started_at':now()})
 try:
  raw=orig(url,payload,timeout=timeout,local=local);Path(str(stem)+'.response.json').write_bytes(raw);return raw
 except Exception as exc:write_json(str(stem)+'.error.json',{'error':str(exc)});raise
net.request_bytes=record
rows=[]
for case in cases:
 row=assess_revised({k:case[k] for k in ['id','domain','as_of','claim','evidence']},client)
 row['provisional_expected']=case['gold'];row['matches_expected']=not row['processing_error'] and row['result']['verdict']==case['gold'];rows.append(row)
 write_json(D/'progress.json',{'rows':rows});print(case['id'],row['result']['verdict'],'expected',case['gold'],'error',row['processing_error'],flush=True)
result={'complete':len(rows)==4,'created_at':now(),'rows':rows,'correct':sum(r['matches_expected'] for r in rows),'calls':count,'elapsed_seconds':time.monotonic()-t0,'freeze_unchanged':all(digest((ROOT/p).read_bytes())==h for p,h in freeze['files'].items()),'development_only':True}
seal(D,result);print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
