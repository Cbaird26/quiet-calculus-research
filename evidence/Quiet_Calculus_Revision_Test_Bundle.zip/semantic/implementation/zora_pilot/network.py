"""Fixed public GET endpoints and fixed loopback inference; no model-selected URLs."""
from __future__ import annotations

import json
import time
import urllib.request
from urllib.parse import urlsplit

from .core import digest, evidence, new_folder, now, seal

SOURCES = {
    "cisa-kev": "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json",
    "github-status": "https://www.githubstatus.com/api/v2/summary.json",
    "cloudflare-status": "https://www.cloudflarestatus.com/api/v2/summary.json",
}
LOCAL = "http://127.0.0.1:11434"
MAX_BYTES = 6 * 1024 * 1024


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError("Redirects are disabled")


def request_bytes(url, payload=None, timeout=20, local=False):
    if local:
        if url not in (LOCAL + "/api/tags", LOCAL + "/api/chat"):
            raise ValueError("Only fixed loopback inference endpoints are permitted")
    elif payload is not None or url not in SOURCES.values():
        raise ValueError("Public access is GET-only and restricted to the source allowlist")
    headers = {"Accept": "application/json", "User-Agent": "ZoraASI-Local-Pilot/0.1"}
    if payload is not None:
        headers["Content-Type"] = "application/json"
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    req = urllib.request.Request(url, data=json.dumps(payload).encode() if payload is not None else None,
                                 headers=headers, method="POST" if payload is not None else "GET")
    with opener.open(req, timeout=timeout) as response:
        raw = response.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError("Response size limit exceeded")
    return raw


class Ollama:
    def __init__(self, model="zora:fast", timeout=120):
        self.model, self.timeout = model, timeout
        tags = json.loads(request_bytes(LOCAL + "/api/tags", local=True))
        matches = [m for m in tags.get("models", []) if m["name"] == model]
        if (not matches or ":cloud" in model or matches[0].get("remote_host") or matches[0].get("remote_model")
                or not isinstance(matches[0].get("size"), int) or matches[0]["size"] <= 0):
            raise ValueError("Choose an already installed local model; no downloads or cloud fallback")
        self.info = {k: matches[0].get(k) for k in ("name", "digest", "size", "details")}

    def call(self, system, data, schema, budget):
        start = time.monotonic()
        payload = {"model": self.model, "stream": False, "think": False, "format": schema,
                   "messages": [{"role": "system", "content": system},
                                {"role": "user", "content": json.dumps(data, ensure_ascii=False)}],
                   "options": {"temperature": 0, "seed": 42, "num_predict": budget, "num_ctx": 8192}}
        raw = json.loads(request_bytes(LOCAL + "/api/chat", payload, timeout=self.timeout, local=True))
        result = {"elapsed_seconds": round(time.monotonic() - start, 3),
                  "input_tokens": raw.get("prompt_eval_count", 0), "output_tokens": raw.get("eval_count", 0),
                  "done_reason": raw.get("done_reason"), "raw_content": raw.get("message", {}).get("content", "")}
        # A truncated response must not be treated as a valid abstention or confirmation.
        if not raw.get("done") or raw.get("done_reason") == "length":
            result["error"] = "incomplete_generation"
            return result
        try:
            result["answer"] = json.loads(result["raw_content"])
        except (ValueError, TypeError):
            result["error"] = "invalid_json"
        return result


def source_cases(key, data, captured):
    url, cases = SOURCES[key], []
    if key == "cisa-kev":
        entries = data["vulnerabilities"]
        if not isinstance(entries, list) or not entries:
            raise ValueError("Missing/empty KEV catalog")
        for entry in sorted(entries, key=lambda x: x["dateAdded"], reverse=True)[:3]:
            cve = entry["cveID"]
            text = json.dumps({"publisher": "CISA", "catalog": "Known Exploited Vulnerabilities",
                               "entry": entry}, ensure_ascii=False, sort_keys=True)
            cases.append({"id": "cisa-" + cve, "domain": "security_advisory", "as_of": captured,
                          "claim": f"CISA lists {cve} in its Known Exploited Vulnerabilities catalog at the capture time.",
                          "evidence": [evidence("catalog-entry", text, url, "cisa", captured)]})
    else:
        page, status, incidents = data["page"], data["status"], data["incidents"]
        expected_host = urlsplit(url).hostname
        if urlsplit(page["url"]).hostname != expected_host or not isinstance(incidents, list):
            raise ValueError("Unexpected status-page identity or incident schema")
        if not isinstance(status.get("indicator"), str) or not isinstance(status.get("description"), str):
            raise ValueError("Missing status indicator")
        service = "GitHub" if key == "github-status" else "Cloudflare"
        text = json.dumps({"publisher": service, "page": page, "status": status,
                           "unresolved_incident_count": len(incidents)}, ensure_ascii=False, sort_keys=True)
        cases.append({"id": key + "-summary", "domain": "outage", "as_of": captured,
                      "claim": f"At capture, {service}'s status page reports indicator '{status['indicator']}' and {len(incidents)} unresolved incidents.",
                      "evidence": [evidence("status-summary", text, url, key, captured)]})
        for incident in incidents[:2]:
            text = json.dumps(incident, ensure_ascii=False, sort_keys=True)
            cases.append({"id": key + "-" + incident["id"], "domain": "outage", "as_of": captured,
                          "claim": f"At capture, {service} reports incident '{incident['name']}' with status '{incident['status']}'.",
                          "evidence": [evidence("incident", text, url, key, captured)]})
    return cases


def collect(keys):
    folder = new_folder("collections")
    sources, cases = [], []
    for key in keys:
        try:
            raw = request_bytes(SOURCES[key])
            captured = now()
            data = json.loads(raw)
            new_cases = source_cases(key, data, captured)
            filename = key + ".raw.json"
            (folder / filename).write_bytes(raw)
            sources.append({"id": key, "url": SOURCES[key], "status": "ok", "captured_at": captured,
                            "raw_file": filename, "sha256": digest(raw), "case_count": len(new_cases)})
            cases.extend(new_cases)
        except Exception as exc:
            sources.append({"id": key, "url": SOURCES[key], "status": "fetch_error",
                            "error": str(exc), "attempted_at": now()})
    result = {"kind": "collection", "created_at": now(), "sources": sources, "cases": cases,
              "coverage": "Only these publisher reports; absence is not evidence of Internet-wide health.",
              "review": "pending", "public_release": False}
    seal(folder, result)
    return folder, result
