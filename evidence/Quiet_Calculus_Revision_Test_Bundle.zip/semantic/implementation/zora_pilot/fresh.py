"""Deterministic fresh challenge cases from allowlisted, frozen publisher snapshots."""
from __future__ import annotations

import json
from datetime import date, timedelta
from pathlib import Path

from .core import digest, evidence, load_sealed, now, validate_case, write_json


def build_fresh(collection_path, exclude_cves=()):
    folder = Path(collection_path)
    collection = load_sealed(folder)
    if collection.get("kind") != "collection":
        raise ValueError("Expected a sealed source collection")
    sources = {s["id"]: s for s in collection["sources"]}
    cases = []

    def read_source(key):
        source = sources[key]
        if source["status"] != "ok":
            raise ValueError("Fresh benchmark requires all three sources; missing " + key)
        path = (folder / source["raw_file"]).resolve()
        if path.parent != folder.resolve():
            raise ValueError("Raw source path escaped collection")
        raw = path.read_bytes()
        if digest(raw) != source["sha256"]:
            raise ValueError("Raw source hash mismatch")
        return source, json.loads(raw)

    def add(group, domain, source, text, pointer, claims):
        item = evidence("record", text, source["url"], source["id"], source["captured_at"])
        item["raw_source_sha256"] = source["sha256"]
        item["raw_json_pointer"] = pointer
        for index, (claim, gold, rationale) in enumerate(claims, 1):
            case = {"id": f"{group}-{index}", "group_id": group, "domain": domain,
                    "claim": claim, "as_of": source["captured_at"], "evidence": [dict(item)],
                    "gold": gold, "gold_rationale": rationale,
                    "label_review": "pending_independent_human_review"}
            validate_case(case)
            cases.append(case)

    source, catalog = read_source("cisa-kev")
    indexed = sorted(enumerate(catalog["vulnerabilities"]), key=lambda pair: (pair[1]["dateAdded"], pair[1]["cveID"]), reverse=True)
    selected = [(i, entry) for i, entry in indexed if entry["cveID"] not in set(exclude_cves)][:2]
    if len(selected) != 2:
        raise ValueError("Need two unused KEV entries")
    for index, entry in selected:
        cve, vendor, product = entry["cveID"], entry["vendorProject"], entry["product"]
        wrong_due = (date.fromisoformat(entry["dueDate"]) + timedelta(days=7)).isoformat()
        text = json.dumps({"publisher": "CISA", "entry": entry}, ensure_ascii=False, sort_keys=True)
        add(cve, "security_advisory", source, text, f"/vulnerabilities/{index}", [
            (f"CISA's captured KEV record for {cve} identifies vendorProject as '{vendor}' and product as '{product}'.", "supported", "Exact vendorProject and product fields in the captured record."),
            (f"The dueDate field in CISA's captured KEV record for {cve} is '{wrong_due}'.", "refuted", f"The actual dueDate field is {entry['dueDate']}; the claim is seven days later."),
            (f"By the capture time, every organization affected by {cve} had completed the required remediation.", "insufficient_evidence", "A remediation requirement or deadline does not establish universal compliance.")])

    for key, publisher in (("github-status", "GitHub"), ("cloudflare-status", "Cloudflare")):
        source, summary = read_source(key)
        components = [(i, c) for i, c in enumerate(summary["components"]) if not c.get("group") and isinstance(c.get("status"), str)]
        if not components:
            raise ValueError("No concrete status components")
        index, component = sorted(components, key=lambda pair: pair[1]["id"])[0]
        actual = component["status"]
        wrong = "major_outage" if actual != "major_outage" else "operational"
        text = json.dumps({"publisher": publisher, "component": component}, ensure_ascii=False, sort_keys=True)
        subject = f"component '{component['name']}' (id {component['id']})"
        add(key, "outage", source, text, f"/components/{index}", [
            (f"The captured {publisher} status feed reports {subject} with status '{actual}'.", "supported", "Exact captured component status, not a claim about later real-time health."),
            (f"The captured {publisher} status feed reports {subject} with status '{wrong}'.", "refuted", f"The reported status is {actual}, which directly contradicts the claimed field value."),
            (f"Exactly 730 customer requests failed for {publisher} {subject} during the 24 hours preceding capture.", "insufficient_evidence", "The supplied component record contains no count of failed customer requests over that interval.")])

    return {"metadata": {"name": "Fresh publisher-snapshot challenge v1", "kind": "snapshot_derived_challenge",
                         "created_at": now(), "case_count": len(cases), "record_groups": 4,
                         "source_collection_sha256": digest((folder / "result.json").read_bytes()),
                         "sources": list(sources.values()), "excluded_cves": sorted(exclude_cves),
                         "label_provenance": "Programmatic field matches/mismatches plus authored unsupported outcome claims; independent human adjudication pending",
                         "evaluation_note": "New claims generated after protocol freeze; no model predictions used for selection or prompt tuning. Twelve correlated claims from four records, not twelve independent incidents.",
                         "independent_holdout": False,
                         "limitations": ["Small, deliberately balanced challenge set", "Three related claims per record", "Not representative of natural rumor frequency", "Labels have no independent human review", "New capture may contain unchanged feed data"]}, "cases": cases}


def write_fresh(collection_path, destination, exclude_cves=()):
    if Path(destination).exists():
        raise ValueError("Refusing to replace an existing fresh dataset")
    result = build_fresh(collection_path, exclude_cves)
    write_json(destination, result)
    return result
