"""Local evidence-review pilot. No publication capability."""

__version__ = "0.1.0"
