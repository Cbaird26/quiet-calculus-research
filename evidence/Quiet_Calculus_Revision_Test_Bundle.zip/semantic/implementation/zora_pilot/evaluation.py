"""Descriptive seed-benchmark metrics; no statistical superiority claims."""
from __future__ import annotations

import html
import shutil
import statistics
from pathlib import Path

from .core import ROOT, VERDICTS, digest, encoded, new_folder, now, read_json, seal, write_json
from .pipeline import assess, protocol


def ratio(n, d):
    return round(n / d, 4) if d else None


def metrics(rows, gold):
    n = len(rows)
    valid = [r for r in rows if not r["processing_error"]]
    definite = [r for r in valid if r["result"]["verdict"] != "insufficient_evidence"]
    supported = [r for r in valid if r["result"]["verdict"] == "supported"]
    unknown = [r for r in rows if gold[r["case_id"]] == "insufficient_evidence"]
    non_support = [r for r in rows if gold[r["case_id"]] != "supported"]
    answerable = [r for r in rows if gold[r["case_id"]] != "insufficient_evidence"]
    calls = [c for r in rows for c in r["calls"]]
    matrix = {g: {p: 0 for p in (*VERDICTS, "processing_error")} for g in VERDICTS}
    for row in rows:
        p = "processing_error" if row["processing_error"] else row["result"]["verdict"]
        matrix[gold[row["case_id"]]][p] += 1
    return {"cases": n, "correct": sum(r["result"]["verdict"] == gold[r["case_id"]] for r in valid),
            "accuracy_including_errors": ratio(sum(r["result"]["verdict"] == gold[r["case_id"]] for r in valid), n),
            "false_confirmations": sum(gold[r["case_id"]] != "supported" for r in supported),
            "false_confirmation_rate_among_non_supported": ratio(sum(gold[r["case_id"]] != "supported" for r in supported), len(non_support)),
            "supported_precision": ratio(sum(gold[r["case_id"]] == "supported" for r in supported), len(supported)),
            "decisive_coverage": ratio(len(definite), n),
            "unnecessary_abstentions": sum(not r["processing_error"] and r["result"]["verdict"] == "insufficient_evidence" for r in answerable),
            "unnecessary_abstention_rate": ratio(sum(not r["processing_error"] and r["result"]["verdict"] == "insufficient_evidence" for r in answerable), len(answerable)),
            "incorrect_definite_judgments": sum(r["result"]["verdict"] != gold[r["case_id"]] for r in definite),
            "disagreements": sum(r["aggregation"] == "verdict_disagreement_preserved" for r in rows),
            "appropriate_abstention_recall": ratio(sum(not r["processing_error"] and r["result"]["verdict"] == "insufficient_evidence" for r in unknown), len(unknown)),
            "processing_errors": n - len(valid),
            "valid_response_rate": ratio(sum(c["valid"] for c in calls), len(calls)),
            "citation_check": "Exact quote membership only; semantic entailment is not automatically scored.",
            "input_tokens": sum(r["input_tokens"] for r in rows), "output_tokens": sum(r["output_tokens"] for r in rows),
            "wall_seconds": round(sum(r["wall_seconds"] for r in rows), 3),
            "median_case_seconds": round(statistics.median(r["wall_seconds"] for r in rows), 3) if rows else None,
            "confusion_matrix": matrix}


def render_report(folder, result):
    """Self-contained static HTML: no scripts, remote assets, network requests, or forms."""
    esc = html.escape
    heading = "Local benchmark" if result["kind"] == "benchmark" else "Local claim review"
    parts = ["<!doctype html><html lang='en'><meta charset='utf-8'><meta name='viewport' content='width=device-width'>",
             "<meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'\">",
             "<title>ZoraASI local pilot</title><style>body{font:16px system-ui;max-width:1050px;margin:40px auto;padding:0 20px;line-height:1.55;color:#17232d;background:#f6f8fa}h1,h2{line-height:1.2}table{border-collapse:collapse;width:100%;background:white}td,th{padding:10px;border:1px solid #ccd4da;text-align:left}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:white;padding:16px}details{margin:12px 0}small{color:#526575}.banner{padding:16px;background:#fff2cd;border-left:5px solid #b27b00}</style>",
             f"<h1>ZoraASI · {heading}</h1><p class='banner'><b>LOCAL DRAFT · HUMAN REVIEW PENDING</b><br>No publication capability. Review decisions are recorded separately against the result hash.</p>",
             f"<p>Model: <b>{esc(str(result['model']['name']))}</b> · Created: {esc(result['created_at'])}</p>"]
    if result["kind"] == "benchmark":
        parts.append(f"<p>{esc(result['dataset_metadata'].get('name', 'Local diagnostic set'))}. Labels remain provisional and require independent human adjudication. These descriptive results do not establish real-world reliability or superiority.</p>")
        parts.append("<table><tr><th>Measure</th><th>Three roles</th><th>Single pass</th></tr>")
        for key in ("cases", "correct", "accuracy_including_errors", "false_confirmations", "incorrect_definite_judgments", "unnecessary_abstentions", "decisive_coverage", "appropriate_abstention_recall", "processing_errors", "input_tokens", "output_tokens", "wall_seconds"):
            parts.append(f"<tr><td>{esc(key.replace('_', ' '))}</td><td>{result['metrics']['three_role'][key]}</td><td>{result['metrics']['baseline'][key]}</td></tr>")
        parts.append("</table>")
    if result.get("sources"):
        parts.append("<h2>Source coverage</h2><table><tr><th>Source</th><th>Fetch status</th><th>Capture or error</th></tr>")
        for source in result["sources"]:
            parts.append(f"<tr><td>{esc(source['id'])}</td><td>{esc(source['status'])}</td><td>{esc(source.get('error') or source.get('captured_at', 'Unknown'))}</td></tr>")
        parts.append("</table><p>Only these captured publisher reports were assessed. Fetch failures are gaps in coverage.</p>")
    parts.append(f"<p>{esc(result['protocol']['budget_caveat'])}</p>")
    if result.get("input_provenance"):
        parts.append(f"<p><b>Provenance:</b> {esc(result['input_provenance'])}</p>")
    parts.append("<p>Exact source quotes are checked mechanically. A matching quote can still be irrelevant or misleading; a person must review whether it supports the judgment.</p>")
    case_lookup = {c["id"]: c for c in result["cases"]}
    for row in result["rows"]:
        case = case_lookup[row["case_id"]]
        parts.append(f"<details><summary><b>{esc(row['case_id'])}</b> · {esc(row['mode'])} · {esc(row['result']['verdict'])}{' · ERROR' if row['processing_error'] else ''}</summary><p>{esc(case['claim'])}</p><p>{esc(row['result']['reason'])}</p>")
        parts.append(f"<p>As of: {esc(case['as_of'])} · Source families: {row['source_family_count']}</p>")
        for e in case["evidence"]:
            parts.append(f"<p><b>{esc(e['id'])}</b> — {esc(e['source_url'])}<br><small>Observed {esc(e['observed_at'])} · SHA-256 {esc(e['text_sha256'])}</small></p><pre>{esc(e['text'])}</pre>")
        for call in row["calls"]:
            details = {"answer": call.get("answer"), "validation_error": call.get("error"), "raw_content": call.get("raw_content")}
            parts.append(f"<details><summary>{esc(call['role'])} · {'valid JSON and citations' if call['valid'] else 'ERROR'}</summary><pre>{esc(encoded(details).decode())}</pre></details>")
        parts.append("</details>")
    parts.append("</html>")
    (Path(folder) / "report.html").write_text("\n".join(parts), encoding="utf-8")


def benchmark(dataset_path, client, cap=256, case_ids=None):
    dataset = read_json(dataset_path)
    cases = dataset["cases"]
    if len({c["id"] for c in cases}) != len(cases):
        raise ValueError("Duplicate benchmark case IDs")
    if case_ids:
        requested = set(case_ids)
        if not requested <= {c["id"] for c in cases}:
            raise ValueError("Unknown benchmark case id")
        cases = [c for c in cases if c["id"] in requested]
    if not cases or any(c.get("gold") not in VERDICTS for c in cases):
        raise ValueError("Benchmark requires cases and valid gold labels")
    folder = new_folder("benchmarks")
    shutil.copytree(ROOT / "zora_pilot", folder / "code" / "zora_pilot", ignore=shutil.ignore_patterns("__pycache__"))
    rows = []
    # Freeze before inference. Result contains the evaluated cases, all prompts and raw responses.
    write_json(folder / "dataset.json", dataset)
    result = {"kind": "benchmark", "created_at": now(), "model": client.info,
              "dataset_sha256": digest(encoded(dataset)), "dataset_metadata": dataset["metadata"],
              "protocol": protocol(cap), "cases": cases, "rows": rows, "review": "pending",
              "public_release": False, "complete": False,
              "development_note": dataset["metadata"].get("evaluation_note", "Initial seed cases were used to debug integration and refine prompts; this is not an untouched holdout.")}
    write_json(folder / "progress.json", result)
    for index, case in enumerate(cases):
        # Alternate order to reduce systematic warm-cache/order advantage; still descriptive.
        order = ("baseline", "three_role") if index % 2 else ("three_role", "baseline")
        for mode in order:
            row = assess(case, client, mode, cap)
            rows.append(row)
            write_json(folder / "progress.json", result)
            print(f"{case['id']} {mode}: {row['result']['verdict']}" + (" [processing error]" if row['processing_error'] else ""), flush=True)
    gold = {c["id"]: c["gold"] for c in cases}
    result["metrics"] = {m: metrics([r for r in rows if r["mode"] == m], gold) for m in ("three_role", "baseline")}
    result["complete"] = True
    result["completed_at"] = now()
    seal(folder, result)
    render_report(folder, result)
    return folder, result
