"""Paired old/new protocol comparison on the identical frozen fresh cases."""
from __future__ import annotations

import html
import importlib
import importlib.util
import shutil
import sys
import uuid
from pathlib import Path

from .core import ROOT, VERDICTS, digest, encoded, load_sealed, model_input, new_folder, now, read_json, seal, write_json
from .evaluation import metrics, render_report
from .pipeline import assess, protocol

ARMS = [("original", "baseline"), ("revised", "three_role"), ("original", "three_role"), ("revised", "baseline")]


def freeze_protocol(destination, original_run, cap=256):
    destination = Path(destination)
    if destination.exists():
        raise ValueError("Protocol freeze already exists")
    if not 128 <= cap <= 1024:
        raise ValueError("Generation cap must be 128..1024")
    original = load_sealed(original_run)
    write_json(destination, {"frozen_at": now(), "revised_protocol": protocol(cap),
                             "model": original["model"],
                             "original_result_sha256": digest((Path(original_run) / "result.json").read_bytes()),
                             "original_protocol": original["protocol"], "per_role_cap": cap,
                             "planned_arms": ARMS, "selection_rule": "Two unused KEV records and one component per status provider; three balanced claims per record",
                             "primary_measures": ["unnecessary_abstentions", "incorrect_definite_judgments", "false_confirmations", "appropriate_abstention_recall"],
                             "no_fresh_case_tuning": True, "review": "pending", "public_release": False})


def load_original(original_run, target):
    original_run, target = Path(original_run), Path(target)
    old = load_sealed(original_run)
    for name, expected in old["protocol"]["source_code_sha256"].items():
        if Path(name).name != name or digest((original_run / "code" / "zora_pilot" / name).read_bytes()) != expected:
            raise ValueError("Original source snapshot integrity failure")
    shutil.copytree(original_run / "code" / "zora_pilot", target, ignore=shutil.ignore_patterns("__pycache__"))
    package_name = "_zora_preserved_" + uuid.uuid4().hex
    spec = importlib.util.spec_from_file_location(package_name, target / "__init__.py", submodule_search_locations=[str(target)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[package_name] = module
    spec.loader.exec_module(module)
    return importlib.import_module(package_name + ".pipeline")


def validate_dataset(dataset):
    cases = dataset.get("cases", [])
    if not cases or len({c["id"] for c in cases}) != len(cases):
        raise ValueError("Fresh cases must have unique IDs")
    for case in cases:
        if case.get("gold") not in VERDICTS:
            raise ValueError("Every benchmark case needs a provisional reference label")
        model_input(case)


def comparison_report(folder, result):
    esc = html.escape
    content = ["<!doctype html><html lang='en'><meta charset='utf-8'><meta name='viewport' content='width=device-width'>",
               "<meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'\">",
               "<title>ZoraASI protocol comparison</title><style>body{font:16px system-ui;max-width:1100px;margin:40px auto;padding:0 20px;line-height:1.5;color:#17232d;background:#f6f8fa}table{border-collapse:collapse;width:100%;background:white}th,td{padding:10px;border:1px solid #ccd4da;text-align:left}.banner{padding:16px;background:#fff2cd}a{color:#1455a0}</style>",
               "<h1>ZoraASI · Fresh-case protocol comparison</h1><p class='banner'><b>LOCAL DRAFT · HUMAN REVIEW PENDING</b><br>Original results are preserved. No publication capability.</p>",
               f"<p>Model: {esc(result['model']['name'])} · {len(result['cases'])} claims from {result['dataset_metadata']['record_groups']} records. Same model, same cases, original and revised protocols.</p>",
               "<p>Cases were generated after the protocol freeze and were not used for tuning. Reference labels remain provisional. Claims share four source records; this is a small constructed challenge, not an independent or representative accuracy estimate.</p>",
               "<table><tr><th>Measure</th><th>Original single pass</th><th>Original three roles</th><th>Revised single pass</th><th>Revised three roles</th></tr>"]
    keys = ["original/baseline", "original/three_role", "revised/baseline", "revised/three_role"]
    for metric in ("cases", "correct", "unnecessary_abstentions", "incorrect_definite_judgments", "false_confirmations", "decisive_coverage", "appropriate_abstention_recall", "disagreements", "processing_errors", "input_tokens", "output_tokens", "wall_seconds"):
        values = "".join(f"<td>{result['metrics'][key][metric]}</td>" for key in keys)
        content.append(f"<tr><td>{esc(metric.replace('_', ' '))}</td>{values}</tr>")
    content.append("</table><p>Generation allowance is matched within each protocol: 256 tokens per role or 768 for the single pass. Total input/compute is not equal. All actual reported token counts and timings are retained.</p>")
    content.append("<h2>Evidence and assessments</h2><ul>")
    for revision in ("original", "revised"):
        content.append(f"<li><a href='{revision}/report.html'>{revision.title()} protocol: every source, role assessment, citation and disagreement</a></li>")
    content.append("</ul><p>Snapshot hashes, source code, dataset, protocol freeze and raw model responses are stored beside this report. A matching quotation establishes traceability, not semantic correctness.</p></html>")
    (Path(folder) / "report.html").write_text("\n".join(content), encoding="utf-8")


def compare(dataset_path, original_run, freeze_path, client):
    dataset, frozen = read_json(dataset_path), read_json(freeze_path)
    validate_dataset(dataset)
    cap = frozen["per_role_cap"]
    current = protocol(cap)
    if current != frozen["revised_protocol"]:
        raise ValueError("Code or protocol changed after freeze; create a new preregistration before using fresh cases")
    if client.info.get("digest") != frozen["model"]["digest"]:
        raise ValueError("Local model differs from the frozen model digest")
    if digest((Path(original_run) / "result.json").read_bytes()) != frozen["original_result_sha256"]:
        raise ValueError("Original run differs from protocol freeze")
    if dataset["metadata"].get("protocol_freeze_sha256") != digest(Path(freeze_path).read_bytes()):
        raise ValueError("Fresh dataset is not bound to this protocol freeze")
    folder = new_folder("comparisons")
    shutil.copytree(ROOT / "zora_pilot", folder / "code" / "zora_pilot", ignore=shutil.ignore_patterns("__pycache__"))
    legacy = load_original(original_run, folder / "code_original" / "zora_pilot")
    write_json(folder / "dataset.json", dataset)
    write_json(folder / "protocol-freeze.json", frozen)
    result = {"kind": "comparison", "created_at": now(), "complete": False, "model": client.info,
              "dataset_sha256": digest(encoded(dataset)), "dataset_metadata": dataset["metadata"],
              "protocol_freeze_sha256": digest(encoded(frozen)),
              "protocols": {"original": legacy.protocol(cap), "revised": current},
              "cases": dataset["cases"], "rows": [], "review": "pending", "public_release": False}
    write_json(folder / "progress.json", result)
    print("Comparison: " + str(folder), flush=True)
    for index, case in enumerate(dataset["cases"]):
        # Rotate all four arms so no protocol/mode systematically receives the first call.
        rotation = index % len(ARMS)
        for revision, mode in ARMS[rotation:] + ARMS[:rotation]:
            implementation = legacy.assess if revision == "original" else assess
            row = implementation(case, client, mode, cap)
            row["protocol_variant"] = revision
            result["rows"].append(row)
            write_json(folder / "progress.json", result)
            print(f"{case['id']} {revision}/{mode}: {row['result']['verdict']}" + (" [processing error]" if row["processing_error"] else ""), flush=True)
    gold = {c["id"]: c["gold"] for c in dataset["cases"]}
    result["metrics"] = {}
    for revision in ("original", "revised"):
        rows = [r for r in result["rows"] if r["protocol_variant"] == revision]
        arm_metrics = {mode: metrics([r for r in rows if r["mode"] == mode], gold) for mode in ("baseline", "three_role")}
        for mode, value in arm_metrics.items():
            result["metrics"][revision + "/" + mode] = value
        arm = {**result, "kind": "benchmark", "rows": rows, "metrics": arm_metrics,
               "protocol": result["protocols"][revision], "complete": True, "completed_at": now()}
        seal(folder / revision, arm)
        render_report(folder / revision, arm)
    result["complete"], result["completed_at"] = True, now()
    seal(folder, result)
    comparison_report(folder, result)
    return folder, result
