from __future__ import annotations

import argparse
import os
import shutil
import sys
import uuid
from pathlib import Path

from .core import ROOT, digest, load_sealed, model_input, new_folder, now, read_json, seal, write_json
from .evaluation import benchmark, render_report
from .network import SOURCES, Ollama, collect
from .pipeline import assess, protocol


def review(folder, reviewer, decision, note, seconds=None):
    folder = Path(folder).resolve()
    result = load_sealed(folder)
    if result["kind"] not in ("evaluation", "benchmark", "comparison") or not result.get("complete"):
        raise ValueError("Only a completed evaluation or benchmark can be reviewed")
    if not reviewer.strip() or not note.strip():
        raise ValueError("Reviewer and substantive review note required")
    if decision not in ("approve", "reject", "needs_changes"):
        raise ValueError("Invalid review decision")
    if seconds is not None and seconds < 0:
        raise ValueError("Review time cannot be negative")
    record = {"reviewer": reviewer, "decision": decision, "note": note, "reviewed_at": now(),
              "result_sha256": digest((folder / "result.json").read_bytes()), "review_seconds": seconds,
              "public_release": False, "meaning": "Local human review record only; no publication authorization or action"}
    path = folder / "reviews" / (uuid.uuid4().hex + ".json")
    write_json(path, record)
    return path


def evaluate(collection_folder, client, cap, case_ids=None):
    collection_folder = Path(collection_folder)
    collection = load_sealed(collection_folder)
    if collection.get("kind") != "collection":
        raise ValueError("Expected a source collection")
    for source in collection["sources"]:
        if source["status"] == "ok":
            raw_path = (collection_folder / source["raw_file"]).resolve()
            if raw_path.parent != collection_folder.resolve():
                raise ValueError("Raw source path escaped collection directory")
            if digest(raw_path.read_bytes()) != source["sha256"]:
                raise ValueError("Raw source hash mismatch")
    cases = collection["cases"]
    if case_ids:
        if not set(case_ids) <= {c["id"] for c in cases}:
            raise ValueError("Unknown case id")
        cases = [c for c in cases if c["id"] in set(case_ids)]
    if not cases:
        raise ValueError("No claims available; inspect feed errors, do not infer health")
    folder = new_folder("evaluations")
    shutil.copytree(ROOT / "zora_pilot", folder / "code" / "zora_pilot", ignore=shutil.ignore_patterns("__pycache__"))
    result = {"kind": "evaluation", "created_at": now(), "model": client.info,
              "collection_sha256": digest((collection_folder / "result.json").read_bytes()),
              "sources": collection["sources"], "cases": cases, "rows": [], "protocol": protocol(cap),
              "complete": False, "review": "pending", "public_release": False}
    for case in cases:
        result["rows"].append(assess(case, client, "three_role", cap))
        write_json(folder / "progress.json", result)
        print(case["id"] + ": " + result["rows"][-1]["result"]["verdict"], flush=True)
    result["complete"] = True
    result["completed_at"] = now()
    seal(folder, result)
    render_report(folder, result)
    return folder, result


def assess_file(path, client, cap):
    """Evaluate one user-supplied claim with embedded evidence; never fetch its URLs."""
    case = read_json(path)
    model_input(case)  # Validate the complete case before any model call.
    folder = new_folder("evaluations")
    shutil.copytree(ROOT / "zora_pilot", folder / "code" / "zora_pilot", ignore=shutil.ignore_patterns("__pycache__"))
    result = {"kind": "evaluation", "created_at": now(), "model": client.info,
              "input_file_sha256": digest(Path(path).read_bytes()), "cases": [case],
              "input_provenance": "User-supplied evidence; source origins require human verification",
              "rows": [assess(case, client, "three_role", cap)], "protocol": protocol(cap),
              "complete": True, "review": "pending", "public_release": False}
    seal(folder, result)
    render_report(folder, result)
    return folder, result


def main(argv=None):
    os.umask(0o077)
    parser = argparse.ArgumentParser(description="ZoraASI local, read-only evidence-review pilot")
    commands = parser.add_subparsers(dest="command", required=True)
    doctor = commands.add_parser("doctor", help="Check an installed local model, without inference or downloads")
    doctor.add_argument("--model", default="zora:fast")
    get = commands.add_parser("collect", help="Read allowlisted public feeds into local snapshots")
    get.add_argument("--online", action="store_true", required=True, help="Explicitly enable public GET requests for this invocation")
    get.add_argument("--sources", nargs="+", choices=sorted(SOURCES), default=list(SOURCES))
    bench = commands.add_parser("benchmark", help="Compare both workflows on frozen local cases")
    bench.add_argument("--dataset", type=Path, default=ROOT / "data" / "seed-v1.json")
    run = commands.add_parser("evaluate", help="Run three roles over an existing frozen collection")
    run.add_argument("collection", type=Path)
    check = commands.add_parser("assess", help="Review a local claim JSON with embedded evidence; no public network access")
    check.add_argument("case_file", type=Path)
    compare_cmd = commands.add_parser("compare", help="Run original and revised protocols on the same frozen fresh dataset")
    compare_cmd.add_argument("--dataset", type=Path, required=True)
    compare_cmd.add_argument("--original-run", type=Path, required=True)
    compare_cmd.add_argument("--freeze", type=Path, required=True)
    compare_cmd.add_argument("--model", default="zora:fast")
    compare_cmd.add_argument("--timeout", type=int, default=120)
    for p in (bench, run, check):
        p.add_argument("--model", default="zora:fast")
        p.add_argument("--per-role-cap", type=int, default=256)
        p.add_argument("--case-ids", nargs="+")
        p.add_argument("--timeout", type=int, default=120)
    inspect = commands.add_parser("inspect", help="Verify artifact hash and show metadata")
    inspect.add_argument("folder", type=Path)
    rev = commands.add_parser("review", help="Record a human's local review; never publishes")
    rev.add_argument("folder", type=Path)
    rev.add_argument("--reviewer", required=True)
    rev.add_argument("--decision", choices=("approve", "reject", "needs_changes"), required=True)
    rev.add_argument("--note", required=True)
    rev.add_argument("--review-seconds", type=float)
    args = parser.parse_args(argv)
    try:
        if args.command == "doctor":
            import json
            print(json.dumps({"endpoint": "http://127.0.0.1:11434", "model": Ollama(args.model).info}, indent=2))
        elif args.command == "collect":
            folder, result = collect(list(dict.fromkeys(args.sources)))
            print(folder)
            for source in result["sources"]:
                print(source["id"] + ": " + source["status"] + (" — " + source["error"] if "error" in source else ""))
            return 0 if all(s["status"] == "ok" for s in result["sources"]) else 2
        elif args.command in ("benchmark", "evaluate", "assess"):
            if not 128 <= args.per_role_cap <= 1024 or not 1 <= args.timeout <= 300:
                raise ValueError("Generation cap must be 128..1024 and timeout 1..300 seconds")
            client = Ollama(args.model, args.timeout)
            if args.command == "benchmark":
                folder, result = benchmark(args.dataset, client, args.per_role_cap, args.case_ids)
            elif args.command == "assess":
                if args.case_ids:
                    raise ValueError("assess reads one claim; --case-ids does not apply")
                folder, result = assess_file(args.case_file, client, args.per_role_cap)
            else:
                folder, result = evaluate(args.collection, client, args.per_role_cap, args.case_ids)
            print("Local result: " + str(folder / "report.html"), flush=True)
            return 2 if any(r["processing_error"] for r in result["rows"]) else 0
        elif args.command == "compare":
            from .comparison import compare
            if not 1 <= args.timeout <= 300:
                raise ValueError("Timeout must be 1..300 seconds")
            folder, result = compare(args.dataset, args.original_run, args.freeze, Ollama(args.model, args.timeout))
            print("Local comparison: " + str(folder / "report.html"))
            return 2 if any(r["processing_error"] for r in result["rows"]) else 0
        elif args.command == "inspect":
            result = load_sealed(args.folder)
            print(f"Hash verified · {result['kind']} · {len(result.get('cases', []))} cases · {result['created_at']}")
            print("Local artifact; public release disabled. Review records are separate, bound to result.sha256.")
        elif args.command == "review":
            print(review(args.folder, args.reviewer, args.decision, args.note, args.review_seconds))
        return 0
    except (ValueError, KeyError, OSError) as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
