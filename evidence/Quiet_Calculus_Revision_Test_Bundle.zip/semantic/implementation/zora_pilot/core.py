"""Data validation, snapshot integrity, and local-only artifact storage."""
from __future__ import annotations

import hashlib
import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATE = ROOT / "state"
VERDICTS = ("supported", "refuted", "insufficient_evidence")


def now():
    return datetime.now(timezone.utc).isoformat()


def parse_time(value):
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        raise ValueError("Timestamps must include a timezone")
    return dt.astimezone(timezone.utc)


def digest(data):
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def encoded(data):
    return json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2).encode("utf-8") + b"\n"


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    with temp.open("xb") as f:
        os.chmod(temp, 0o600)
        f.write(encoded(data))
    temp.replace(path)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def new_folder(kind):
    folder = STATE / kind / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8])
    folder.mkdir(parents=True, mode=0o700)
    return folder


def seal(folder, data):
    """Local integrity check, not a signature or proof that content is true."""
    folder = Path(folder)
    write_json(folder / "result.json", data)
    (folder / "result.sha256").write_text(digest((folder / "result.json").read_bytes()) + "\n")


def load_sealed(folder):
    folder = Path(folder)
    raw = (folder / "result.json").read_bytes()
    if digest(raw) != (folder / "result.sha256").read_text().strip():
        raise ValueError("Artifact hash mismatch; review is invalid")
    return json.loads(raw)


def evidence(eid, text, source_url, source_family, observed_at, published_at=None):
    return {"id": eid, "text": text, "text_sha256": digest(text), "source_url": source_url,
            "source_family": source_family, "observed_at": observed_at,
            "published_at": published_at, "authority": "publisher_statement"}


def validate_case(case):
    if not isinstance(case.get("id"), str) or not case["id"]:
        raise ValueError("Claim requires an id")
    if case.get("domain") not in ("security_advisory", "outage"):
        raise ValueError("Only security advisories and outages are in scope")
    if not isinstance(case.get("claim"), str) or not 1 <= len(case["claim"]) <= 1500:
        raise ValueError("Claim must contain 1..1500 characters")
    parse_time(case["as_of"])
    ids = set()
    for item in case["evidence"]:
        if item["id"] in ids:
            raise ValueError("Duplicate evidence id")
        ids.add(item["id"])
        if digest(item["text"]) != item["text_sha256"]:
            raise ValueError("Evidence hash mismatch")
        if not item.get("source_family") or not item.get("source_url"):
            raise ValueError("Source identity required")
        parse_time(item["observed_at"])
        if item.get("published_at"):
            parse_time(item["published_at"])


def eligible_evidence(case):
    """Strict snapshot cutoff; later captures cannot masquerade as historical evidence."""
    validate_case(case)
    cutoff = parse_time(case["as_of"])
    kept, excluded = [], []
    max_age = 6 * 3600 if case["domain"] == "outage" else 30 * 86400
    for item in case["evidence"]:
        observed = parse_time(item["observed_at"])
        published = parse_time(item["published_at"]) if item.get("published_at") else observed
        reason = None
        if observed > cutoff or published > cutoff:
            reason = "after_cutoff"
        elif (cutoff - observed).total_seconds() > max_age:
            reason = "stale_snapshot"
        if reason:
            excluded.append({"id": item["id"], "reason": reason})
        else:
            kept.append(item)
    if len(json.dumps(kept)) > 12000:
        raise ValueError("Evidence exceeds context limit; split the claim instead of silently truncating")
    return kept, excluded


def model_input(case):
    items, excluded = eligible_evidence(case)
    # Explicit allowlist: gold labels and benchmark metadata never enter a prompt.
    return {"claim": case["claim"], "domain": case["domain"], "as_of": case["as_of"],
            "evidence": items, "excluded_evidence": excluded,
            "source_families": sorted({e["source_family"] for e in items})}


def check_assessment(answer, items, collector=False):
    if not isinstance(answer, dict):
        raise ValueError("Model output must be an object")
    if collector:
        if not isinstance(answer.get("observations"), str):
            raise ValueError("Collector requires observations")
    elif answer.get("verdict") not in VERDICTS:
        raise ValueError("Invalid verdict")
    if not isinstance(answer.get("reason"), str) or not answer["reason"].strip():
        raise ValueError("Nonempty reason required")
    citations = answer.get("citations")
    if not isinstance(citations, list):
        raise ValueError("Citations must be a list")
    known = {e["id"]: e["text"] for e in items}
    for cite in citations:
        if not isinstance(cite, dict) or cite.get("evidence_id") not in known:
            raise ValueError("Unknown citation")
        quote = cite.get("quote")
        if not isinstance(quote, str) or not quote.strip() or quote not in known[cite["evidence_id"]]:
            raise ValueError("Citation quote is not an exact source substring")
    if not collector and answer["verdict"] != "insufficient_evidence" and not citations:
        raise ValueError("Supported/refuted judgments require source quotes")
    # Exact quotes establish traceability, not entailment. Human semantic review remains required.
    return answer
