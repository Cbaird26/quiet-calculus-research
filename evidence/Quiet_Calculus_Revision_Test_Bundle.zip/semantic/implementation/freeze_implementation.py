"""Seal completed implementation without reading the held-out directory."""
from pathlib import Path
import json,hashlib,platform,sys
from datetime import datetime,timezone
from semantic_revision import method_info
ROOT=Path(__file__).resolve().parent
out=ROOT/'IMPLEMENTATION_FREEZE.json'
assert not out.exists(),'Never replace a freeze'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dev=json.loads((ROOT/'development-scope-final/result.json').read_text())
assert dev['complete'] and dev['calls']==4 and dev['freeze_unchanged']
assert 'Ran 21 tests' in (ROOT/'unit-tests.txt').read_text() and (ROOT/'unit-tests.txt').read_text().rstrip().endswith('OK')
files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='IMPLEMENTATION_FREEZE.json']
frozen={'frozen_at':datetime.now(timezone.utc).isoformat(),'method':method_info(),'files':{str(p.relative_to(ROOT)):h(p) for p in files},
 'source_hashes':json.loads((ROOT/'SOURCE_HASHES.json').read_text()),'software_tests':{'tests':21,'passed':True,'log_sha256':h(ROOT/'unit-tests.txt')},
 'development':{'final_cases':4,'final_calls':4,'initiated_calls_total':16,'initial_timeout':1,'interrupted_calls_total':2,'first_compact_unnecessary_abstention':1,'typed_compact_matches':4,'typed_compact_cases':6,'correct':dev['correct'],'result_sha256':h(ROOT/'development-scope-final/result.json'),'provisional_author_labels':True,'extended_to_16_before_holdout_with_root_authorization':True},
 'heldout_access':'None by implementation author; do not read sibling heldout directory.',
 'mutation_rule':'No changes after this marker before/during held-out inference.','environment':{'python':sys.version,'platform':platform.platform()}}
out.write_text(json.dumps(frozen,indent=2,sort_keys=True)+'\n')
print(json.dumps({'freeze_sha256':h(out),'files':len(files),'development_correct':dev['correct'],'software_tests':21}))
