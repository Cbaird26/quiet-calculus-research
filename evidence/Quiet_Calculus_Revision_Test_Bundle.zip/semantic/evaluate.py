#!/usr/bin/env python3
"""Frozen paired local inference; no case labels are supplied to either implementation."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,math,platform,sys,time

ROOT=Path(__file__).resolve().parent
IMPL=ROOT/'implementation'
sys.path.insert(0,str(IMPL))

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text())
def save(p,data):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n');tmp.replace(p)

PROTOCOL={
 'version':'4.0','arms':['old_single','revised_single'],'planned_cases':36,'planned_calls':72,
 'case_order':'Six blocks of six cases in frozen dataset order. Run all six cases of one arm, then all six of the other; revised first in even blocks and old first in odd blocks. This balances which arm is first while reducing repeated prompt-prefill cost.',
 'model_name':'zora:fast','model_digest':'a92f9fa6055834220446827338ecf10952b65304b2c77295df92bdb3cd22b6a5',
 'generation_cap_each_arm':768,'context_tokens':8192,'temperature':0,'seed':42,
 'per_call_timeout_seconds':60,'total_runtime_cap_seconds':3600,
 'primary_gate':{'incorrect_definite_judgments':'strictly lower than old_single','correct_including_processing_failures':'no lower than old_single','unnecessary_abstentions':'no higher than old_single','processing_errors':'no higher than old_single'},
 'targeted_diagnostics':'Six family-specific descriptive count tables and case-level regressions; no multiplicity-adjusted family claims.',
 'statistical_scope':'Counts and paired discordances on a fixed constructed test; no population superiority or calibrated probabilities.',
 'resource_scope':'Same model and generation cap; unequal prompt/token cost is measured, not treated as matched total compute.',
 'failure_rule':'No retries or excluded failures. Interrupted or timed-out rows remain failed/missing and cannot satisfy the completion gate.',
 'label_scope':'Separate AI-authored cases and provisional labels, withheld from implementation author; no independent human adjudication.',
 'adaptation_rule':'No implementation, prompt, label or case edits after freeze; development cases remain separate.',
 'evidence_scope':'Synthetic local model behavior and software checks only; no physical evidence.'
}

def files_to_freeze():
 return [ROOT/'evaluate.py',ROOT/'root_label_review.json',ROOT/'preflight_schedule_note.json',ROOT/'heldout/dataset.json',*sorted(f for f in IMPL.rglob('*') if f.is_file() and f.suffix in {'.py','.json','.txt','.md'} and '__pycache__' not in f.parts)]

def freeze():
 f=ROOT/'evaluation_freeze.json'
 assert not f.exists(),'Never replace an existing evaluation freeze'
 assert (IMPL/'IMPLEMENTATION_FREEZE.json').exists(),'Wait for implementation author freeze'
 assert (ROOT/'heldout/FREEZE.json').exists(),'Wait for holdout author freeze'
 data=read(ROOT/'heldout/dataset.json');assert len(data['cases'])==36
 import zora_pilot.network as net
 from zora_pilot.core import model_input
 client=net.Ollama(PROTOCOL['model_name'],60)
 assert client.info['digest']==PROTOCOL['model_digest']
 for c in data['cases']:
  assert c['gold'] in {'supported','refuted','insufficient_evidence'}
  for e in c['evidence']:
   assert set(e)<={'id','text','text_sha256','source_url','source_family','observed_at','published_at','authority'},'Unexpected evidence metadata'
  inputs=model_input(c)
  assert set(inputs)=={'claim','domain','as_of','evidence','excluded_evidence','source_families'}
 frozen={'created_at':now(),'protocol':PROTOCOL,'model':client.info,'environment':{'python':sys.version,'platform':platform.platform()},'files':{str(x.relative_to(ROOT)):sha(x) for x in files_to_freeze()},'holdout_freeze_sha256':sha(ROOT/'heldout/FREEZE.json')}
 save(f,frozen);(ROOT/'evaluation_freeze.sha256').write_text(sha(f)+'\n');print('Evaluation freeze: '+sha(f))

def run():
 from zora_pilot.pipeline import assess
 from semantic_revision import assess_revised
 from zora_pilot.core import model_input
 from zora_pilot.evaluation import metrics
 import zora_pilot.network as net
 frozen=read(ROOT/'evaluation_freeze.json')
 assert sha(ROOT/'evaluation_freeze.json')==(ROOT/'evaluation_freeze.sha256').read_text().strip()
 assert frozen['protocol']==PROTOCOL
 for rel,digest in frozen['files'].items():assert sha(ROOT/rel)==digest,rel
 assert not (ROOT/'result.json').exists() and not (ROOT/'raw_calls').exists(),'Use a fresh reproduction directory'
 data=read(ROOT/'heldout/dataset.json');client=net.Ollama(PROTOCOL['model_name'],60)
 assert client.info==frozen['model']
 rawdir=ROOT/'raw_calls';rawdir.mkdir()
 original=net.request_bytes;count=0;current={};start=time.monotonic()
 def record(url,payload=None,timeout=20,local=False):
  nonlocal count
  assert local and url==net.LOCAL+'/api/chat'
  left=PROTOCOL['total_runtime_cap_seconds']-(time.monotonic()-start)
  if left<=0:raise TimeoutError('frozen_total_runtime_exhausted')
  inputs=json.loads(payload['messages'][1]['content'])
  assert set(inputs)=={'claim','domain','as_of','evidence','excluded_evidence','source_families'}
  count+=1;prefix=rawdir/f'{count:03d}'
  save(str(prefix)+'.request.json',{'row':current,'started_at':now(),'url':url,'payload':payload,'timeout_seconds':min(timeout,left)})
  try:
   raw=original(url,payload,timeout=min(timeout,left),local=True);Path(str(prefix)+'.response.json').write_bytes(raw);return raw
  except Exception as exc:
   save(str(prefix)+'.error.json',{'error':str(exc),'at':now()});raise
 net.request_bytes=record
 rows=[];result={'version':'4.0','created_at':now(),'kind':'paired_synthetic_semantic_revision','protocol':PROTOCOL,'evaluation_freeze_sha256':sha(ROOT/'evaluation_freeze.json'),'model':client.info,'cases':data['cases'],'dataset_metadata':data['metadata'],'rows':rows,'complete':False,'physical_evidence':False,'public_release':False}
 scheduled=[]
 for b,start_index in enumerate(range(0,len(data['cases']),6)):
  for arm in (['revised_single','old_single'] if b%2==0 else ['old_single','revised_single']):
   scheduled.extend((case,arm) for case in data['cases'][start_index:start_index+6])
 for case,arm in scheduled:
  clean={k:case[k] for k in ['id','domain','as_of','claim','evidence']}
  if time.monotonic()-start>=PROTOCOL['total_runtime_cap_seconds']:break
  current={'case_id':case['id'],'arm':arm};t=time.monotonic()
  try:
   row=assess(clean,client,'baseline',256) if arm=='old_single' else assess_revised(clean,client,generation_cap=768)
  except Exception as exc:
   row={'case_id':case['id'],'result':{'verdict':'insufficient_evidence','reason':'processing_error','citations':[]},'processing_error':True,'aggregation':'processing_error','calls':[],'input_tokens':0,'output_tokens':0,'wall_seconds':time.monotonic()-t,'fatal_error':str(exc)}
  row['mode']=arm;rows.append(row);save(ROOT/'progress.json',result)
  print(case['id'],arm,row['result']['verdict'],'error='+str(row['processing_error']),flush=True)
 gold={c['id']:c['gold'] for c in data['cases']}
 result['metrics']={}
 for arm in PROTOCOL['arms']:
  values=[r for r in rows if r['mode']==arm];m=metrics(values,gold)
  m['selective_error']=m['incorrect_definite_judgments']/sum(not r['processing_error'] and r['result']['verdict']!='insufficient_evidence' for r in values) if any(not r['processing_error'] and r['result']['verdict']!='insufficient_evidence' for r in values) else None
  m['total_tokens']=m['input_tokens']+m['output_tokens'];result['metrics'][arm]=m
 old,new=[result['metrics'][a] for a in PROTOCOL['arms']]
 gate={'fewer_incorrect_definite':new['incorrect_definite_judgments']<old['incorrect_definite_judgments'],'no_accuracy_drop':new['correct']>=old['correct'],'no_extra_unnecessary_abstention':new['unnecessary_abstentions']<=old['unnecessary_abstentions'],'no_extra_processing_failure':new['processing_errors']<=old['processing_errors'],'all_planned_rows_complete':len(rows)==72}
 result['gate']={**gate,'passed':all(gate.values())}
 family={}
 for c in data['cases']:
  label=c.get('family',c.get('test_family','unknown'))
  family.setdefault(label,[]).append(c['id'])
 result['family_metrics']={fam:{arm:metrics([r for r in rows if r['case_id'] in ids and r['mode']==arm],gold) for arm in PROTOCOL['arms']} for fam,ids in family.items()}
 paired=[]
 for c in data['cases']:
  matched={r['mode']:r for r in rows if r['case_id']==c['id']}
  if len(matched)==2:
   correct={a:not matched[a]['processing_error'] and matched[a]['result']['verdict']==c['gold'] for a in PROTOCOL['arms']}
   paired.append({'case_id':c['id'],'family':c.get('family',c.get('test_family','unknown')),'gold':c['gold'],'old':matched['old_single']['result']['verdict'],'revised':matched['revised_single']['result']['verdict'],'old_correct':correct['old_single'],'revised_correct':correct['revised_single']})
 result.update(paired=paired,completed_at=now(),elapsed_seconds=time.monotonic()-start,inference_calls=count,complete=len(rows)==72,frozen_files_preserved=all(sha(ROOT/r)==h for r,h in frozen['files'].items()))
 save(ROOT/'result.json',result);(ROOT/'result.sha256').write_text(sha(ROOT/'result.json')+'\n')
 summary={k:v for k,v in result.items() if k not in {'rows','cases'}};summary['result_sha256']=sha(ROOT/'result.json');save(ROOT/'summary.json',summary)
 print(json.dumps({'complete':result['complete'],'inference_calls':count,'metrics':result['metrics'],'gate':result['gate'],'elapsed_seconds':result['elapsed_seconds']},indent=2))

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--freeze',action='store_true');ap.add_argument('--run',action='store_true');args=ap.parse_args()
 if args.freeze==args.run:raise SystemExit('Specify exactly one of --freeze or --run')
 freeze() if args.freeze else run()
