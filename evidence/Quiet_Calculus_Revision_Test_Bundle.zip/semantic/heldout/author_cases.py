"""Fictional holdout authoring. No model calls, network, or implementation imports."""
from pathlib import Path
import json,hashlib,random,datetime
ROOT=Path(__file__).resolve().parent
CASES=[]
ASOF='2026-10-25T18:00:00Z'
FAMILIES={
 'omission_negative':'Open-world omission versus explicit negative evidence',
 'closed_document':'Document-scoped and closed-world absence',
 'unresolved_conflict':'Unresolved same-scope conflict',
 'justified_resolution':'Justified temporal or authority resolution',
 'quantifier_scope':'Quantifier and scope transfer',
 'ordinary_controls':'Ordinary entailment and refutation controls'}
def sha(s):return hashlib.sha256(s.encode() if isinstance(s,str) else s).hexdigest()
def evidence(text,family,published='2026-10-25T17:30:00Z',observed='2026-10-25T17:55:00Z'):
 return {'text':text,'text_sha256':sha(text),'source_family':family,
         'source_url':'https://'+family+'.invalid/record','authority':'publisher_statement',
         'published_at':published,'observed_at':observed}
def add(code,family,domain,claim,records,gold,rationale,quotes,rule,audit,formal=None):
 es=[]
 for i,r in enumerate(records,1):
  q=dict(r);q['id']='e'+str(i);es.append(q)
 CASES.append({'author_code':code,'family':family,'domain':domain,'as_of':ASOF,
  'claim':claim,'evidence':es,'gold':gold,'gold_rationale':rationale,
  'gold_quotes':[{'evidence_id':'e'+str(i),'quote':q} for i,q in quotes],
  'truth_specification':{'relation':{'supported':'entailed','refuted':'contradicted','insufficient_evidence':'not_determined'}[gold],
                        'rule':rule,**({'formal_fixture':formal} if formal else {})},
  'second_pass_audit':audit})

# Open-world omission versus explicit negative evidence: 2 supported, 2 refuted, 2 insufficient.
add('OW1','omission_negative','outage',
 'The Kestrel Tickets recovery log records no failed retry among its 24 post-reroute checks.',
 [evidence('Kestrel Tickets, event KT-614. Recovery check batch R contains 24 retries after the reroute. Outcome counters for batch R: completed 24; failed 0. These counters cover every retry in R.','kestrel-tickets')],
 'supported','The claim is restricted to the recorded batch R, whose exhaustive counters give zero failures. It does not claim uninterrupted service outside that batch.',
 [(1,'Outcome counters for batch R: completed 24; failed 0.'),(1,'These counters cover every retry in R.')],
 'An exhaustive zero counter supports the negative existential for that batch.',
 'Checked the denominator and event scope: all 24 retries belong to the same named post-reroute batch, so this is explicit negative evidence, not silence.')
add('OW2','omission_negative','security_advisory',
 'Rivet Instruments classifies Juniper firmware 7.4 as unaffected by RI-228.',
 [evidence('Rivet Instruments RI-228 disposition sheet. Juniper 7.3: affected. Juniper 7.4: unaffected. The 7.4 entry is a completed assessment, not an untested-version placeholder.','rivet-instruments')],
 'supported','The exact product, version and advisory match a completed unaffected classification. A nearby affected version does not transfer that label to 7.4.',
 [(1,'Juniper 7.4: unaffected.'),(1,'The 7.4 entry is a completed assessment, not an untested-version placeholder.')],
 'A completed explicitly negative classification entails the matching negative claim.',
 'Checked that unaffected is an assessment value rather than omission, a default field, or a different product/version.')
add('OW3','omission_negative','outage',
 'The Meridian Parcel operator reports uninterrupted delivery of every batch in West Quay during interval W.',
 [evidence('Meridian Parcel incident MP-731, interval W from 16:40 to 17:00 UTC. West Quay batch ledger: 89 delivered and 11 dropped. The dropped batches did not reach their destinations during W; later retries are outside this ledger.','meridian-parcel')],
 'refuted','The claim says every batch was delivered without interruption during W. Eleven batches explicitly failed to arrive during that same interval, providing counterexamples.',
 [(1,'West Quay batch ledger: 89 delivered and 11 dropped.'),(1,'The dropped batches did not reach their destinations during W; later retries are outside this ledger.')],
 'An observed failure within the quantified set refutes an all-success claim.',
 'Checked that later retry success cannot repair the historical uninterrupted-delivery assertion; the counterexamples share region and interval.')
add('OW4','omission_negative','security_advisory',
 'Tundra Forms certifies that all three maintained branches are free of the TF-492 parsing flaw.',
 [evidence('Tundra Forms TF-492 maintained-branch assessment. Branches Cedar and Hazel are cleared. Branch Willow remains classified as affected: a malformed import bypasses its length guard. This sheet is the certification for the three maintained branches.','tundra-forms')],
 'refuted','Willow is one of the three maintained branches and is classified as affected. Therefore the report cannot certify the universal negative claimed.',
 [(1,'Branch Willow remains classified as affected: a malformed import bypasses its length guard.'),(1,'This sheet is the certification for the three maintained branches.')],
 'One affected member contradicts a claim that every member is unaffected.',
 'Checked that the claimed three-branch universe is the same certified universe; Willow is not an obsolete or external branch.')
add('OW5','omission_negative','outage',
 'No upload request failed anywhere on Noon Atlas during window N.',
 [evidence('Noon Atlas note NA-863, window N. The operations digest highlights thumbnail generation at East Pier and map-tile reads at Hill Yard; both checks completed. Upload-request logs are kept in a separate service journal that is not part of this digest.','noon-atlas')],
 'insufficient_evidence','Successful thumbnail and tile checks do not establish upload outcomes across the service. The supplied digest omits the relevant journal, leaving both an upload failure and no upload failure compatible with the record.',
 [(1,'The operations digest highlights thumbnail generation at East Pier and map-tile reads at Hill Yard; both checks completed.'),(1,'Upload-request logs are kept in a separate service journal that is not part of this digest.')],
 'Open-world omission does not establish a negative event claim outside documented observations.',
 'Countermodels checked: the separate journal can contain an upload failure or contain none without changing any supplied sentence. Neither the claim nor its negation is determined.')
add('OW6','omission_negative','security_advisory',
 'Copper Trace library 1.8 is affected by CT-576.',
 [evidence('Copper Trace CT-576 laboratory excerpt. The sample examined here uses library 1.6, where the decoder fault is reproducible. This excerpt contains the first sample only; the project maintains separate assessment sheets for other releases.','copper-trace')],
 'insufficient_evidence','The only observed release is 1.6, whereas the claim concerns 1.8. Omitted assessments may classify 1.8 either way; no release-inheritance rule is supplied.',
 [(1,'The sample examined here uses library 1.6, where the decoder fault is reproducible.'),(1,'This excerpt contains the first sample only; the project maintains separate assessment sheets for other releases.')],
 'A positive result for one release cannot be transferred to another without a stated link.',
 'Checked that 1.8 is neither explicitly excluded nor covered by a range. The distinction is missing evidence, not a negative classification.')

# Closed documents: 3 supported, 2 refuted, 1 insufficient.
add('CD1','closed_document','security_advisory',
 'Build 6.2 is absent from the affected-build field of the complete Moss Ledger ML-304 notice.',
 [evidence('Complete Moss Ledger notice ML-304, revision C. Product: ledger agent. Affected-build field, all entries: 6.0; 6.1; 6.3. Recommended action: install 6.4. End of notice; no entries or sections have been omitted from this transcription.','moss-ledger')],
 'supported','The claim is about membership in a particular fully supplied field. Its complete entries do not include 6.2, which supports document-scoped absence without claiming real-world immunity.',
 [(1,'Affected-build field, all entries: 6.0; 6.1; 6.3.'),(1,'End of notice; no entries or sections have been omitted from this transcription.')],
 'For an explicitly complete finite document field, nonmembership determines absence from that field.',
 'Checked that the claim says absent from the field, not unaffected in nature. The completeness statement licenses this narrow negative conclusion.',
 {'universe_type':'document_field','complete_members':['6.0','6.1','6.3'],'query_member':'6.2','membership':False})
add('CD2','closed_document','security_advisory',
 'Under the Sable Check SC-945 release-check rule, build S5 has the classification not affected.',
 [evidence('Sable Check SC-945 toy release fixture. Assessed universe: S1, S2, S3, S4, S5, S6, with every member completed. For this fixture the classification affected holds exactly when flag=1; flag=0 means not affected. Complete flag rows: S1=1, S2=0, S3=1, S4=1, S5=0, S6=0. No statement about deployments outside this fixture is made.','sable-check')],
 'supported','The fixture supplies an explicit biconditional classification rule and the exact value S5=0. The negative conclusion follows within that toy rule, not by extrapolating to outside deployments.',
 [(1,'flag=0 means not affected.'),(1,'Complete flag rows: S1=1, S2=0, S3=1, S4=1, S5=0, S6=0.')],
 'Apply the explicit completed-flag classification rule to S5.',
 'Verified the rule is iff/zero-defined, the member is in the completed universe, and the claim remains within the fixture.',
 {'universe_type':'toy_completed_rule','flags':{'S1':1,'S2':0,'S3':1,'S4':1,'S5':0,'S6':0},'affected_iff_flag':1,'query_member':'S5','query_classification':'not affected'})
add('CD3','closed_document','outage',
 'The complete Amber Ferry incident extract AF-118 contains no recovery-time value.',
 [evidence('Amber Ferry AF-118: full incident extract. Fields present are incident ID AF-118, detection time 17:06 UTC, affected function departure-board refresh, and contact operations desk. This is the entire stored extract, including all field values.','amber-ferry')],
 'supported','The supplied extract explicitly enumerates all stored fields and values, with no recovery-time field/value. The claim concerns this document, not whether service ever recovered.',
 [(1,'Fields present are incident ID AF-118, detection time 17:06 UTC, affected function departure-board refresh, and contact operations desk.'),(1,'This is the entire stored extract, including all field values.')],
 'Exhaustive document-field enumeration permits a document-scoped absence conclusion.',
 'Checked the distinction between a missing recovery value and an unrecovered service. Only the former is claimed.',
 {'universe_type':'document_fields','complete_fields':['incident ID','detection time','affected function','contact'],'query_field':'recovery time','membership':False})
add('CD4','closed_document','security_advisory',
 'The affected-version table in Flint Archive FA-207 includes version 3.5.',
 [evidence('Flint Archive FA-207, complete affected-version table: 2.1 | 2.2 | 3.4. The table is reproduced in full; the notice has no additional affected-version entries. The compatibility matrix in a different publication is not included.','flint-archive')],
 'refuted','The claim is a positive membership assertion about a complete, explicitly closed table. Version 3.5 is not one of its entries, so the narrow document claim is false.',
 [(1,'complete affected-version table: 2.1 | 2.2 | 3.4.'),(1,'The table is reproduced in full; the notice has no additional affected-version entries.')],
 'An absent member in an expressly complete table contradicts a claimed table membership.',
 'Checked that the omitted compatibility matrix is irrelevant: the claim names only this affected-version table.',
 {'universe_type':'document_field','complete_members':['2.1','2.2','3.4'],'query_member':'3.5','membership':False})
add('CD5','closed_document','outage',
 'The Elm Water EW-382 status report declares no impacted component.',
 [evidence('Elm Water telemetry dashboard, report EW-382. Complete impacted-component roster: reservoir-level feed; pump-cycle export. Other dashboard sections contain contact details and charts only. Both roster entries are marked impacted in this report.','elm-water')],
 'refuted','The report explicitly marks two components impacted. Those entries directly contradict the assertion that the report declares none.',
 [(1,'Complete impacted-component roster: reservoir-level feed; pump-cycle export.'),(1,'Both roster entries are marked impacted in this report.')],
 'Two explicitly impacted entries refute document-scoped zero affected members.',
 'Checked that the two names denote separate dashboard functions and are actual impacted entries, not examples or mitigation suggestions.')
add('CD6','closed_document','security_advisory',
 'Marble Build M3 is unaffected by MB-669 in running deployments.',
 [evidence('Marble Build MB-669 assessment register. Complete universe of assessed builds in this register: M1 and M2. Both completed assessments are unaffected. M3 is a different build that was not assessed for this register. This register has no deployment observations.','marble-build')],
 'insufficient_evidence','Completeness is restricted to assessed builds M1 and M2. It does not close the universe of all releases or deployments, so M3 may be affected or unaffected without contradicting the register.',
 [(1,'Complete universe of assessed builds in this register: M1 and M2.'),(1,'M3 is a different build that was not assessed for this register.'),(1,'This register has no deployment observations.')],
 'Closed-world reasoning is restricted to its declared universe and predicate.',
 'Countermodels checked for M3: either real deployment outcome leaves the completed M1/M2 register unchanged. This must not be turned into refutation merely because M3 is absent.')

# All six genuine unresolved conflicts are insufficient. Family metadata is never model input.
add('UC1','unresolved_conflict','outage',
 'Cloud Loom CL-851 has the official disposition resolved at 17:20 UTC.',
 [evidence('Cloud Loom signed incident export CL-851, sequence 8, effective 17:20 UTC: disposition resolved. This export is issued by the operations desk.','cloud-loom'),
  evidence('Cloud Loom signed incident export CL-851, sequence 8, effective 17:20 UTC: disposition investigating. This export is also issued by the operations desk; its signature and sequence match the other supplied export.','cloud-loom')],
 'insufficient_evidence','The two same-authority exports assign incompatible unique dispositions to the same incident, sequence and instant. Neither timestamp nor sequence supplies a priority rule, so a definite resolved or not-resolved judgment would arbitrarily select one.',
 [(1,'sequence 8, effective 17:20 UTC: disposition resolved.'),(2,'sequence 8, effective 17:20 UTC: disposition investigating.')],
 'Unresolved equally applicable contradictory status records require abstention; reporting that one text says resolved is a different claim.',
 'Checked event, authority, sequence and effective time all coincide. The claim asks for the official disposition, not whether a resolved sentence appears somewhere.')
add('UC2','unresolved_conflict','security_advisory',
 'The controlling final classification for Inkstone Printer firmware 2.6 under IP-462 is affected.',
 [evidence('Inkstone Printer IP-462 final assessment, revision F, signed by the release board: firmware 2.6 classification affected. Scope is the production parser with default options.','inkstone-printer'),
  evidence('Inkstone Printer IP-462 final assessment, revision F, signed by the release board: firmware 2.6 classification unaffected. Scope is the production parser with default options.','inkstone-printer')],
 'insufficient_evidence','Two equally authoritative records bearing the same final revision classify the same firmware and configuration oppositely. This is a conflict in classification, not merely one successful and one failed stochastic trial.',
 [(1,'firmware 2.6 classification affected.'),(2,'firmware 2.6 classification unaffected.')],
 'Same-revision, same-scope incompatible final classifications cannot be resolved by arbitrary ordering.',
 'Checked that default options, production parser, release board and revision F agree. No correction, supersession or more-authoritative document is supplied.')
add('UC3','unresolved_conflict','outage',
 'Mooring Queue delivered continuously throughout interval Q, 17:00 to 17:30 UTC.',
 [evidence('Mooring Queue MQ-175 audit record, interval Q 17:00-17:30 UTC. Signed delivery audit A certifies delivery continued without a gap throughout Q.','mooring-queue'),
  evidence('Mooring Queue MQ-175 audit record, interval Q 17:00-17:30 UTC. Signed delivery audit B records delivery stopped from 17:12 to 17:16 UTC. Audits A and B have the same audit status and neither is designated a replacement.','mooring-queue')],
 'insufficient_evidence','One signed audit explicitly certifies continuity and the other explicitly records an interruption within the same interval. Equal audit standing and no replacement relation leave the factual claim disputed.',
 [(1,'certifies delivery continued without a gap throughout Q.'),(2,'records delivery stopped from 17:12 to 17:16 UTC.'),(2,'Audits A and B have the same audit status and neither is designated a replacement.')],
 'A direct temporal contradiction between unranked applicable audit records remains unresolved.',
 'Checked that the gap lies strictly within Q, the service and event match, and no independent authority or correction settles which audit is correct.')
add('UC4','unresolved_conflict','security_advisory',
 'Cedar Desk CD-528 requires an attacker to sign in before reaching the vulnerable endpoint.',
 [evidence('Cedar Desk CD-528 access assessment for endpoint /import, default deployment. Final access class: unauthenticated; a caller without a session can reach the vulnerable endpoint. Assessment signed by the security owner.','cedar-desk'),
  evidence('Cedar Desk CD-528 access assessment for endpoint /import, default deployment. Final access class: authenticated; every caller must sign in before reaching the vulnerable endpoint. Assessment signed by the security owner at the same revision.','cedar-desk')],
 'insufficient_evidence','The same-owner final assessments directly disagree on whether login is necessary for the identical endpoint and configuration. Neither is identified as corrected or superseded.',
 [(1,'a caller without a session can reach the vulnerable endpoint.'),(2,'every caller must sign in before reaching the vulnerable endpoint.')],
 'Opposed necessary-access conditions for the same configuration remain an unresolved conflict.',
 'Checked this is not one document about exploit success and another about endpoint access: both explicitly address reaching the same vulnerable endpoint.')
add('UC5','unresolved_conflict','outage',
 'The North relay in Fable Map FM-339 is operational at 17:45 UTC.',
 [evidence('Fable Map FM-339 official relay bulletin, edition 21, effective 17:45 UTC. North relay condition: operational. The bulletin covers the North relay itself, not only the public web page.','fable-map'),
  evidence('Fable Map FM-339 official relay bulletin, edition 21, effective 17:45 UTC. North relay condition: unavailable. This is the same relay and service boundary as the other edition-21 bulletin.','fable-map')],
 'insufficient_evidence','Opposing condition values apply to the same relay, official edition, effective instant and boundary. There is no principled way to rank these two current records.',
 [(1,'North relay condition: operational.'),(2,'North relay condition: unavailable.'),(2,'This is the same relay and service boundary as the other edition-21 bulletin.')],
 'Same-scope incompatible status values require unresolved-conflict abstention.',
 'Checked that a healthy status page cannot reconcile the reports: both records expressly concern the relay service itself.')
add('UC6','unresolved_conflict','security_advisory',
 'At 17:40 UTC, the release authority permits distribution of Pine Spool PS-902 patch 4.2.',
 [evidence('Pine Spool PS-902 release register, effective 17:40 UTC, authorization record R7. Patch 4.2 distribution is permitted. This is a release-authority authorization, not a mirror availability check.','pine-spool'),
  evidence('Pine Spool PS-902 release register, effective 17:40 UTC, authorization record R7. Patch 4.2 distribution is prohibited. This entry is signed by the same release authority, with the same record identifier.','pine-spool')],
 'insufficient_evidence','The two matching authorization records give contradictory permissions at the same time. The difference cannot be reconciled as a downloadable mirror versus an official permission.',
 [(1,'Patch 4.2 distribution is permitted.'),(2,'Patch 4.2 distribution is prohibited.')],
 'Unranked conflicting authority decisions on one authorization record leave permission unresolved.',
 'Checked identical patch, authority, record and effective time. The claim is permission, so download status cannot settle it.')

# Justified resolutions: 3 supported, 3 refuted.
add('JR1','justified_resolution','security_advisory',
 'The controlling Quarry Lens QL-416 notice classifies build 8.0 as affected.',
 [evidence('Quarry Lens QL-416, revision 1, published 16:00 UTC: build 8.0 affected.','quarry-lens',published='2026-10-25T16:00:00Z'),
  evidence('Quarry Lens QL-416, revision 2, published 17:10 UTC. This correction replaces revision 1 for the affected-build classification: the earlier build number was a transcription error. Build 8.0 is unaffected; build 8.1 is affected.','quarry-lens',published='2026-10-25T17:10:00Z')],
 'refuted','The same publisher explicitly supersedes the earlier classification through an identified correction. The controlling revision says 8.0 is unaffected, contradicting the claim.',
 [(2,'This correction replaces revision 1 for the affected-build classification: the earlier build number was a transcription error.'),(2,'Build 8.0 is unaffected; build 8.1 is affected.')],
 'Explicit same-scope correction supersedes a specified earlier revision.',
 'Checked authority and scope continuity. This uses an explicit replacement relation, not the invalid rule that any later text always wins.')
add('JR2','justified_resolution','outage',
 'The latest supplied Bay Lantern BL-783 operator status is restored.',
 [evidence('Bay Lantern BL-783 operator timeline. Update 16:25 UTC: service unavailable.','bay-lantern',published='2026-10-25T16:25:00Z'),
  evidence('Bay Lantern BL-783 operator timeline. Update 17:35 UTC: service restored. This update replaces the current-status value of the 16:25 entry; that earlier interruption remains part of the history.','bay-lantern',published='2026-10-25T17:35:00Z')],
 'supported','The claim asks for the latest supplied status, and the eligible later operator update explicitly replaces the current-status field with restored. It does not erase the historical outage.',
 [(2,'Update 17:35 UTC: service restored.'),(2,'This update replaces the current-status value of the 16:25 entry; that earlier interruption remains part of the history.')],
 'Use the explicit current-status update for a latest-status claim while retaining historical facts.',
 'Checked both timestamps are in cutoff and within the six-hour window. The claimed predicate is latest supplied status, not uninterrupted past operation.')
add('JR3','justified_resolution','security_advisory',
 'According to the maintainer notice for Bracken Sync BS-604, a repair package has not yet been released.',
 [evidence('Bracken Sync BS-604 maintainer notice. A repair package is still withheld from release; users should temporarily disable directory mirroring. This text is the maintainer release notice.','bracken-sync'),
  evidence('Community newsletter on Bracken Sync BS-604: our editor believes a repair is already out. The editor is not a maintainer and cites no release notice.','bracken-community')],
 'supported','The claim is expressly about what the maintainer notice says. That notice states the package remains withheld, whereas the community belief is a different, lower-relevance source and does not change the maintainer statement.',
 [(1,'A repair package is still withheld from release; users should temporarily disable directory mirroring.'),(2,'The editor is not a maintainer and cites no release notice.')],
 'Respect the named-source scope of the claim; a community belief is not the maintainer release notice.',
 'Checked the claim does not require proving that no unauthorized package exists anywhere. It asks only for the maintainer release statement.')
add('JR4','justified_resolution','outage',
 'At the evidence cutoff, the published Harbor Loom HL-257 schedule assigns status active to 18:00 UTC.',
 [evidence('Harbor Loom HL-257 published service schedule, edition 4. Status is paused from 17:20 through 18:30 UTC, including both endpoints. This edition is the controlling published schedule at 17:50 UTC.','harbor-loom',published='2026-10-25T17:50:00Z'),
  evidence('Harbor Loom HL-257 schedule, edition 5, published 18:10 UTC. The revised schedule assigns active from 17:50 onward and replaces edition 4.','harbor-loom',published='2026-10-25T18:10:00Z',observed='2026-10-25T18:12:00Z')],
 'refuted','The later revision was published and captured after the 18:00 cutoff and cannot enter this as-of judgment. The eligible schedule assigns paused at 18:00, contradicting active. This is about the published schedule, not actual physical operation.',
 [(1,'Status is paused from 17:20 through 18:30 UTC, including both endpoints.')],
 'Exclude later-published or later-observed evidence before resolving an as-of document claim.',
 'Checked the future correction is ineligible even though it describes a retroactive interval. The claim is the schedule known by the cutoff; it is not a claim about what later history establishes.')
add('JR5','justified_resolution','security_advisory',
 'The final Orchard Mesh OM-815 advisory includes release 6.3 in its affected set.',
 [evidence('Orchard Mesh OM-815 draft D0: affected set {6.2}. This draft is pending review.','orchard-mesh',published='2026-10-25T15:20:00Z'),
  evidence('Orchard Mesh OM-815 final F1, approved at 17:05 UTC. This final notice supersedes draft D0. Affected set {6.2, 6.3}; fixed set {6.4}.','orchard-mesh',published='2026-10-25T17:05:00Z')],
 'supported','The final notice explicitly supersedes the draft and contains 6.3 in the affected set. Draft omission cannot override a complete final positive entry.',
 [(2,'This final notice supersedes draft D0.'),(2,'Affected set {6.2, 6.3}; fixed set {6.4}.')],
 'An explicitly approved final replacement controls a final-document membership query.',
 'Checked that 6.3 appears in the affected set rather than the fixed set; the replacement is explicit and eligible.')
add('JR6','justified_resolution','outage',
 'The Pebble Post PP-963 timeline places the mail relay in state available at 16:00 UTC.',
 [evidence('Pebble Post PP-963 operator timeline: unavailable from 15:30 until 16:45 UTC; restored at 16:45 UTC and available thereafter. The latest entry at 17:25 UTC reports available and does not revise the earlier interval.','pebble-post')],
 'refuted','The claim concerns a historical instant inside the explicitly unavailable interval. The later available state does not change the earlier state at 16:00.',
 [(1,'unavailable from 15:30 until 16:45 UTC; restored at 16:45 UTC and available thereafter.'),(1,'The latest entry at 17:25 UTC reports available and does not revise the earlier interval.')],
 'Resolve status by the claimed effective time rather than blindly selecting the latest status value.',
 'Checked 16:00 lies strictly inside the unavailable interval, avoiding endpoint ambiguity. No retrospective correction is asserted.')

# Scope transfer: 1 supported, 2 refuted, 3 insufficient.
add('QS1','quantifier_scope','outage',
 'The Alder Rail AR-431 test report contains at least one tested site with an interrupted data feed.',
 [evidence('Alder Rail AR-431 feed trials. Tested sites: Depot Nine, Orchard Crossing and Salt Platform. Depot Nine completed continuously; Orchard Crossing lost its feed for 40 seconds; Salt Platform completed continuously. The trial makes no claim about untested sites.','alder-rail')],
 'supported','Orchard Crossing is explicitly a tested site and has a recorded interruption. That single witness is enough for the existential claim, despite the lack of coverage of other sites.',
 [(1,'Tested sites: Depot Nine, Orchard Crossing and Salt Platform.'),(1,'Orchard Crossing lost its feed for 40 seconds;')],
 'A within-scope witness entails at least one; untested sites do not defeat that existential.',
 'Checked the claim is existential over tested sites, not universal over the network, and the interrupted site belongs to that set.')
add('QS2','quantifier_scope','security_advisory',
 'Every platform enumerated in the Birch Frame BF-552 advisory is affected.',
 [evidence('Birch Frame BF-552 enumerated platforms and dispositions: Granite desktop, affected; Linen tablet, unaffected; Copper kiosk, affected. These are the three platforms enumerated in this advisory.','birch-frame')],
 'refuted','Linen tablet is an enumerated platform with an explicit unaffected disposition, so it is a counterexample to every enumerated platform being affected.',
 [(1,'Linen tablet, unaffected;'),(1,'These are the three platforms enumerated in this advisory.')],
 'An explicit negative member refutes the universal positive over the enumerated set.',
 'Checked the qualifier enumerated restricts the universe correctly; the counterexample is not an unlisted or untested device.')
add('QS3','quantifier_scope','outage',
 'All affected regions in the Wren Beacon WB-706 incident are in the South district.',
 [evidence('Wren Beacon WB-706 impact report. South district: Reed Bay affected. East district: Lime Ridge affected. North district: no affected region recorded. Reed Bay and Lime Ridge are distinct regions in their stated districts.','wren-beacon')],
 'refuted','The report supplies an affected East-district region, Lime Ridge. That direct counterexample contradicts the claim that every affected region belongs to South.',
 [(1,'East district: Lime Ridge affected.'),(1,'Reed Bay and Lime Ridge are distinct regions in their stated districts.')],
 'One explicitly out-of-scope affected region refutes an only-in-South claim.',
 'Checked the district membership is explicit and distinct, so no inferred geography is needed.')
add('QS4','quantifier_scope','outage',
 'Every subscriber in the Valley district lost access during the Iris Harbor IH-293 interruption.',
 [evidence('Iris Harbor IH-293 test observation. A single probe account in the Valley district lost access at 17:11 UTC. The test used one subscriber account; it did not sample or enumerate other subscribers.','iris-harbor')],
 'insufficient_evidence','One lost-access account establishes an existential event, not the universal subscriber claim. The other subscribers may all have failed or some may have remained connected.',
 [(1,'A single probe account in the Valley district lost access at 17:11 UTC.'),(1,'The test used one subscriber account; it did not sample or enumerate other subscribers.')],
 'A single positive witness does not entail a universal and does not by itself refute it.',
 'Countermodels checked: both universal failure and partial failure include this probe observation. No explicit unaffected account is supplied, so refuted would also overreach.')
add('QS5','quantifier_scope','security_advisory',
 'The signed Juncture Box JB-687 update was installed on device D during the check.',
 [evidence('Juncture Box JB-687 check specification: if the signed update is installed on a device, that device emits indicator OK. This is a one-way guarantee; the specification imposes no restriction on indicators from other device states. Device D check log: indicator OK.','juncture-box')],
 'insufficient_evidence','The rule says installed implies OK, and the observation supplies OK. It does not say only installed devices can emit OK; therefore installation and noninstallation are both compatible with the stated one-way rule and log.',
 [(1,'if the signed update is installed on a device, that device emits indicator OK.'),(1,'This is a one-way guarantee; the specification imposes no restriction on indicators from other device states.'),(1,'Device D check log: indicator OK.')],
 'Do not affirm the consequent of a one-way implication.',
 'Formal assignments checked: installed=true, OK=true and installed=false, OK=true both satisfy the rule. The claim cannot be inferred or contradicted.',
 {'universe_type':'propositional_rule','rule':'installed implies OK','observed':{'OK':True},'query':'installed','compatible_values':[True,False]})
add('QS6','quantifier_scope','security_advisory',
 'The patch in Meadow Wire MW-854 prevents every production restart caused by the reported fault.',
 [evidence('Meadow Wire MW-854 staging receipt. Three staging devices accepted the patch file and returned an installation-complete code. This receipt records installation only; no fault-triggering workload was executed, and no production device is represented.','meadow-wire')],
 'insufficient_evidence','Installation acceptance in staging is neither an efficacy test nor a production outcome. The same receipt is compatible with effective prevention, partial prevention or no prevention in production.',
 [(1,'Three staging devices accepted the patch file and returned an installation-complete code.'),(1,'This receipt records installation only; no fault-triggering workload was executed, and no production device is represented.')],
 'Installation success cannot be transferred to universal production fault prevention.',
 'Checked both invalid transfers separately: accepted file is not prevented fault, and staging observations are not production coverage. No counterexample to prevention is observed either.')

# Ordinary controls: 3 supported, 3 refuted.
add('OC1','ordinary_controls','security_advisory',
 'The Osprey Draft OD-361 advisory recommends turning off remote import.',
 [evidence('Osprey Draft OD-361 temporary response. Recommended operator action: turn off remote import by setting remote_import=off. Keep local editing enabled. The recommendation is temporary while a patch is prepared.','osprey-draft')],
 'supported','The claim matches the explicit recommended action. It does not assert that the mitigation has already been performed or proven effective.',
 [(1,'Recommended operator action: turn off remote import by setting remote_import=off.')],
 'An explicit recommendation supports a matching recommendation claim.',
 'Checked the predicate is recommends, not implemented or experimentally verified. No extra outcome is inferred.')
add('OC2','ordinary_controls','outage',
 'The recorded uninterrupted outage interval in Sun Dock SD-478 lasted twelve minutes.',
 [evidence('Sun Dock SD-478 event log. Outage began at 17:03 UTC and ended at 17:15 UTC on the same day. The outage was continuous between those two timestamps, with no intermediate recovery.','sun-dock')],
 'supported','Subtracting 17:03 from 17:15 on the same day gives twelve elapsed minutes. The explicit continuity statement makes this the one outage interval claimed.',
 [(1,'Outage began at 17:03 UTC and ended at 17:15 UTC on the same day.'),(1,'The outage was continuous between those two timestamps, with no intermediate recovery.')],
 'Compute elapsed duration of one explicitly continuous interval.',
 'Checked same-day UTC timestamps and elapsed-time convention; there is no count of inclusive minute labels or multiple intervals to confuse duration.')
add('OC3','ordinary_controls','security_advisory',
 'The Fern Relay FR-519 release notice reports zero published repair artifacts.',
 [evidence('Fern Relay FR-519 release notice. Published repair-artifact count: 0. A work-in-progress branch exists internally, but no artifact from it has been published. The notice is a release report, not an estimate of future development.','fern-relay')],
 'supported','The notice supplies an explicit zero publication count and distinguishes internal work from published artifacts. That is affirmative negative evidence for the release-report claim.',
 [(1,'Published repair-artifact count: 0.'),(1,'A work-in-progress branch exists internally, but no artifact from it has been published.')],
 'An explicit zero publication count entails a matching report of no published artifacts.',
 'Checked the private development branch does not count as publication; the claim is narrowly about the notice.')
add('OC4','ordinary_controls','outage',
 'The current status field in Slate Pantry SP-682 says the inventory feed is operational.',
 [evidence('Slate Pantry SP-682 current status card, captured at 17:55 UTC. Inventory feed status: degraded. Billing export status: operational. These are separate components.','slate-pantry',published='2026-10-25T17:50:00Z')],
 'refuted','The inventory feed is explicitly degraded; operational belongs to a separate billing export. The claim assigns the wrong component value.',
 [(1,'Inventory feed status: degraded.'),(1,'Billing export status: operational. These are separate components.')],
 'Use the status attached to the claimed component, not a nearby component.',
 'Checked exact component identity and current timestamp. No unresolved competing status is supplied for the inventory feed.')
add('OC5','ordinary_controls','security_advisory',
 'The Willow Engine WE-724 notice marks release 5.0 affected.',
 [evidence('Willow Engine WE-724 classification rows. Release 5.0: unaffected after completed review. Release 5.1: affected after completed review. Both entries concern the same engine and flaw.','willow-engine')],
 'refuted','The exact 5.0 row explicitly says unaffected. The positive 5.1 row cannot be substituted for the claimed version.',
 [(1,'Release 5.0: unaffected after completed review.'),(1,'Release 5.1: affected after completed review.')],
 'An explicit opposite classification for the exact version contradicts the claim.',
 'Checked both rows are completed assessments of the same flaw; the decisive distinction is the version number.')
add('OC6','ordinary_controls','outage',
 'According to the Stone Orchard SO-936 incident record, restoration occurred at 17:55 UTC.',
 [evidence('Stone Orchard SO-936 incident record. Restoration occurred at 17:35 UTC. The record was subsequently copied into the archive at 17:55 UTC; that later timestamp is an archive-copy time, not a second restoration.','stone-orchard',published='2026-10-25T17:40:00Z')],
 'refuted','The claim mistakes archive-copy time for event time. The record explicitly assigns restoration to 17:35 and denies a second restoration at the later copy timestamp.',
 [(1,'Restoration occurred at 17:35 UTC.'),(1,'that later timestamp is an archive-copy time, not a second restoration.')],
 'Keep event time separate from archival or observation time.',
 'Checked the claim is according to this record and that the record supplies a unique restoration instant distinct from the later copying event.')

def canonical(d):return json.dumps(d,ensure_ascii=False,sort_keys=True,indent=2)+'\n'
def main():
 # Hide family blocks in case order; this shuffle does not depend on any model output.
 rng=random.Random(2026102536);rng.shuffle(CASES)
 audit=[];labels=[];inputs=[]
 for i,c in enumerate(CASES,1):
  c['id']=c['group_id']=f'SH{i:03d}'
  audit.append({'id':c['id'],'author_code':c.pop('author_code'),'family':c['family'],
                'gold':c['gold'],'review':c.pop('second_pass_audit'),
                'reviewer':'Same AI-assisted author, second semantic pass; not independent human adjudication.'})
  inp={k:c[k] for k in ('id','domain','as_of','claim','evidence')};inputs.append(inp)
  label={k:c[k] for k in ('id','group_id','family','gold','gold_rationale','gold_quotes','truth_specification')};labels.append(label)
  c['input_sha256']=sha(canonical(inp));c['label_sha256']=sha(canonical(label))
 meta={'name':'Quiet Calculus semantic revision holdout: 36 fictional event groups',
       'date_local':'2026-10-25','timezone':'America/New_York','authored_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'cases':36,'unique_event_groups':36,'family_names':FAMILIES,'cases_per_family':6,
       'label_counts':{x:sum(c['gold']==x for c in CASES) for x in ('supported','refuted','insufficient_evidence')},
       'label_provenance':'AI-assisted author-created semantic labels with a second careful pass by the same author; no human-independent or external adjudication.',
       'independence_scope':'Author did not read the new implementation and did not communicate case content to its implementer. Historical evaluation schema and task families were known. Shared task templates and AI authorship limit independence.',
       'source_acquisition':'None. All entities, events and text are fictional; .invalid URLs are metadata and must never be fetched.',
       'model_input_rule':'Only id/domain/as_of/claim/evidence, then the existing core.model_input eligibility allowlist. Never expose gold, family, rationale, quotes, truth rules, hashes or author review to either arm.',
       'unique_events':'Exactly one claim per distinct scenario/event; no case variants reuse an event with a different label.',
       'scope':'Constructed semantic challenge, not prevalence estimate or real-world accuracy benchmark.',
       'case_order_seed':2026102536,'model_calls_by_author':0}
 (ROOT/'dataset.json').write_text(canonical({'cases':CASES,'metadata':meta}))
 (ROOT/'inputs.json').write_text(canonical({'cases':inputs}))
 (ROOT/'labels.json').write_text(canonical({'labels':labels}))
 (ROOT/'SECOND_PASS_REVIEW.json').write_text(canonical({'review_scope':'semantic second pass by same author before freeze','reviews':audit}))
 print('Authored',len(CASES),'unique cases',meta['label_counts'])

if __name__=='__main__':main()
