"""Read-only structural and label-evidence consistency audit, no model calls."""
from pathlib import Path
import json,hashlib,collections,datetime
ROOT=Path(__file__).resolve().parent
def sha(x):return hashlib.sha256(x.encode() if isinstance(x,str) else x).hexdigest()
def canonical(d):return json.dumps(d,ensure_ascii=False,sort_keys=True,indent=2)+'\n'
source=Path('/Users/christophermichaelbaird/Documents/ChatGPT/ZoraASI/zora_integrity_pilot/zora_pilot/core.py')
ns={'__file__':str(source),'__name__':'readonly_original_schema'}
exec(compile(source.read_text(),str(source),'exec'),ns)
d=json.loads((ROOT/'dataset.json').read_text());cases=d['cases']
inputs=json.loads((ROOT/'inputs.json').read_text())['cases']
labels=json.loads((ROOT/'labels.json').read_text())['labels']
audits=json.loads((ROOT/'SECOND_PASS_REVIEW.json').read_text())['reviews']
assert len(cases)==36 and len(inputs)==36 and len(labels)==36 and len(audits)==36
assert len({c['id'] for c in cases})==36
assert len({c['group_id'] for c in cases})==36
counts=collections.Counter(c['gold'] for c in cases)
assert counts=={'supported':12,'refuted':12,'insufficient_evidence':12}
families=collections.Counter(c['family'] for c in cases)
assert len(families)==6 and set(families.values())=={6}
sources={};texts={};exclusions=[];checks=[]
for c,inp,label,audit in zip(cases,inputs,labels,audits):
 ns['validate_case'](c);kept,exc=ns['eligible_evidence'](c)
 assert c['id']==inp['id']==label['id']==audit['id']
 assert c['gold']==label['gold']==audit['gold']
 assert c['input_sha256']==sha(canonical(inp))
 assert c['label_sha256']==sha(canonical(label))
 assert inp=={k:c[k] for k in ('id','domain','as_of','claim','evidence')}
 assert label=={k:c[k] for k in ('id','group_id','family','gold','gold_rationale','gold_quotes','truth_specification')}
 assert c['gold_rationale'] and audit['review'] and c['truth_specification']['rule']
 assert c['gold_quotes']
 byid={e['id']:e for e in c['evidence']};eligible={e['id'] for e in kept}
 for quote in c['gold_quotes']:
  assert quote['evidence_id'] in eligible
  assert quote['quote'] in byid[quote['evidence_id']]['text']
 for e in c['evidence']:
  assert e['text_sha256']==sha(e['text']) and '.invalid/' in e['source_url']
  assert texts.setdefault(e['text'],c['group_id'])==c['group_id']
  assert sources.setdefault(e['source_family'],c['group_id'])==c['group_id']
 f=c['truth_specification'].get('formal_fixture')
 if f:
  if f['universe_type']=='document_field':assert (f['query_member'] in f['complete_members'])==f['membership']
  elif f['universe_type']=='document_fields':assert (f['query_field'] in f['complete_fields'])==f['membership']
  elif f['universe_type']=='toy_completed_rule':assert f['flags'][f['query_member']]==0 and f['query_classification']=='not affected'
  elif f['universe_type']=='propositional_rule':
   assert f['observed']['OK'] is True
   assert all((not installed) or f['observed']['OK'] for installed in f['compatible_values'])
 filtered=ns['model_input'](inp)
 assert not set(filtered)&{'gold','gold_rationale','gold_quotes','family','truth_specification','input_sha256','label_sha256'}
 if exc:exclusions.append({'id':c['id'],'excluded':exc})
 checks.append({'id':c['id'],'schema_valid':True,'quote_substrings_valid':True,'input_hash_valid':True,'label_hash_valid':True,'eligible_evidence_count':len(kept),'excluded_count':len(exc),'label_audit_recorded':True})
assert len(exclusions)==1 and exclusions[0]['excluded']==[{'id':'e2','reason':'after_cutoff'}]
report={'validated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True,
 'case_count':36,'event_group_count':36,'label_counts':dict(counts),'family_counts':dict(families),
 'cross_group_reused_source_families':0,'cross_group_duplicate_evidence_texts':0,
 'expected_exclusions':exclusions,'schema_source':str(source),'schema_sha256':sha(source.read_bytes()),
 'checks':checks,'limit':'Structural/hash/quote and toy-rule checks are not independent human semantic validation.'}
(ROOT/'VALIDATION.json').write_text(canonical(report))
print(canonical({k:v for k,v in report.items() if k!='checks'}))
