# Semantic holdout authorship and label protocol

Local date: 2026-10-25 (America/New_York).

## Purpose and separation

This dataset contains 36 new fictional events, exactly one claim per event, for paired evaluation of an old and a revised evidence-review system. It is an authored semantic challenge, not a sample from real-world event prevalence. No network resources were accessed, and all .invalid URLs are fictional metadata. No clinical subject matter is included.

The author inspected only the previous pilot dataset schema and the original zora_integrity_pilot/zora_pilot/core.py schema/eligibility implementation. The author did not read the new semantic/implementation/ directory, did not execute a model, and did not communicate case content to the implementation agent. Task families and historical task design were already known. This is author/implementer separation within an AI-assisted workflow, not external or human-independent adjudication. A second semantic pass was performed by the same author and is recorded per case. Root may independently flag ambiguity before evaluation; any exclusion or amendment must preserve this frozen version and be recorded before model inference.

## Semantic decision rules

1. Evaluate the proposition actually claimed, including named source/document, product, version, component, quantifier, predicate, and time. Supported means the eligible fictional record entails it under these stated semantics. Refuted requires eligible evidence for its contrary. Insufficient means neither side is determined, or a material applicable conflict remains unresolved.
2. An explicit negative assessment, exhaustive zero counter, or counterexample can justify a negative conclusion. Negation is not by itself grounds for abstention.
3. Omission in an open or partial record establishes neither nonoccurrence nor immunity. A positive fact about one instance cannot automatically be transferred to other instances.
4. Absence from a document or table can be established when that exact document/field is expressly complete. A toy finite classification can use its explicit iff/zero-value rule. Closure applies only to the declared universe and predicate, not to all versions, deployments, or real-world events.
5. A conflict exists only when statements materially oppose each other about the same proposition, scope and time. Equally applicable and equally authoritative unreconciled records require insufficient_evidence for the disputed single state or classification. This rule does not use classical explosion. A claim merely that one document contains a sentence is distinct from a claim about the unique official state.
6. Resolve temporal or authority differences only with a justified relation: an explicit correction/supersession, a designated latest current-status update, a claim scoped to a named primary source, or the claimed effective time. A later snapshot is not automatically a correction of earlier history. Different components and versions are not conflicting reports about one object.
7. Apply the prior core eligibility rules: exclude after-cutoff observations/publications; outage observation age limit six hours, security-advisory limit thirty days. As-of knowledge does not use a later retroactive correction. All cases are authored so that no unstated expiry rule is needed.
8. One witness entails an existential, and one explicit contrary witness refutes a universal over the same set. A witness alone does not entail a universal or refute it. A one-way implication cannot be inverted. Successful installation is not a demonstrated efficacy result.
9. No outside factual assumptions, web lookup, reputational knowledge, or imagined missing evidence may settle a label. These sources are fictional stipulated records, not independently verified observations of the actual world.

## Composition and pairing

Six families contain six cases each: open-world omission/negative evidence; closed documents; unresolved same-scope conflict; justified resolution; quantifier/scope transfer; ordinary controls. Overall labels are 12 supported, 12 refuted, 12 insufficient_evidence. Family balance is intentionally not uniform: genuine unresolved conflicts all have insufficient labels. Family names, labels, rationales, quotes, truth rules and author reviews are excluded from both arms' inputs. Dataset order is shuffled once with fixed seed 2026102536, before any model execution. Exactly one case belongs to each event group, and no evidence text or event is reused across labels.

`dataset.json` is compatible with the prior case shape and includes private evaluation metadata. `inputs.json` contains only id/domain/as_of/claim/evidence for convenience; eligibility still runs through core.model_input. `labels.json` and SECOND_PASS_REVIEW.json are for adjudication and scoring only. Both arms must receive the same eligible input bytes per case, with their arm code and model identity frozen separately by the execution owner. Root determines inference budgets and paired statistical analyses; this author does not select or inspect model outcomes.

## Label review before freezing

The first pass authored an explicit label, a detailed rationale, literal evidence substrings, and a machine-independent semantic rule for every event. The second pass checked: precise scope; time; applicable source identity; negative versus missing evidence; whether closure was properly bounded; whether a purported conflict could be reconciled; whether any priority rule existed; and countermodels for underdetermined claims. Three document-field cases, one flag classification, and the one-way implication include compact formal fixtures where useful. The audit explicitly notes its same-author AI provenance.

Before freezing, validate all 36 cases with the original schema, check quote substring membership and evidence hashes, verify labels and family counts, verify unique event groups/source families/evidence text across groups, recompute per-input and per-label hashes, and check the expected future-evidence exclusion. Do not make any model calls during construction or validation. Freeze every input, label, protocol, authoring and validator file in FREEZE.json. Hashing demonstrates preserved bytes, not truth or independent authorship. After freezing, never silently change labels or tune cases to outcomes. Any correction is a separately versioned pre-inference amendment or a transparently reported post-inference limitation.

## Limits

The 36 groups are distinct fictional events, but templates and author assumptions are shared. They do not constitute 36 independent samples from a natural population. Case wording, balance, and short evidence may make this challenge easier or differently difficult than actual evidence review. The stated semantics create a bounded gold standard; they do not establish human agreement. Root's further review and future human adjudication should be reported separately. A paired performance difference supports only this frozen challenge and configuration, not general reliability or consciousness/physical research claims.
