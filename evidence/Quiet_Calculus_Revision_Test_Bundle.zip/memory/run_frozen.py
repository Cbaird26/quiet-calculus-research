from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
def main():
    if (ROOT/'results/selection_freeze.json').exists() or (ROOT/'results/raw_paths.jsonl').exists():raise SystemExit('Use a new directory to reproduce; existing outcomes preserved')
    freeze=json.loads((ROOT/'freeze.json').read_text())
    for n,h in freeze['files'].items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h,n
    env=dict(os.environ)
    limits=['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']
    for k in limits:env[k]='1'
    receipt={'started_at':datetime.now(timezone.utc).isoformat(),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
        'thread_limits':{k:env[k] for k in limits},'freeze_sha256':hashlib.sha256((ROOT/'freeze.json').read_bytes()).hexdigest(),'runs':[]}
    for script in ['review/test_phase29_engine.py','review/test_benchmark.py','review/test_phase210.py','review/test_causal_gate.py','review/revision_experiment.py']:
        cmd=[sys.executable,'-B',script];log=ROOT/'logs'/(Path(script).stem+'.log');t=time.perf_counter()
        with log.open('w') as fp:p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=fp,stderr=subprocess.STDOUT)
        receipt['runs'].append({'command':cmd,'exit_code':p.returncode,'elapsed_seconds':time.perf_counter()-t,'log':str(log.relative_to(ROOT))})
        receipt['status']='failed' if p.returncode else 'running'
        (ROOT/'results/execution_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        print(script,'exit',p.returncode,'seconds',round(receipt['runs'][-1]['elapsed_seconds'],3),flush=True)
        if p.returncode:raise SystemExit(p.returncode)
    receipt['status']='complete';receipt['completed_at']=datetime.now(timezone.utc).isoformat()
    receipt['integrity_after']={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in freeze['files'].items()}
    assert all(receipt['integrity_after'].values())
    (ROOT/'results/execution_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':main()
