"""Run the sealed revision in a new directory, preserving all existing evidence."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys

def main():
    ap=argparse.ArgumentParser();ap.add_argument('destination',type=Path);a=ap.parse_args()
    root=Path(__file__).resolve().parent;dest=a.destination.expanduser().resolve()
    if dest.exists():raise SystemExit('Destination must not exist')
    freeze=json.loads((root/'freeze.json').read_text());dest.mkdir(parents=True)
    for n in [*freeze['files'],'freeze.json','freeze.sha256']:
        t=dest/n;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/n,t)
    (dest/'results').mkdir();(dest/'logs').mkdir()
    raise SystemExit(subprocess.call([sys.executable,'-B','run_frozen.py'],cwd=dest))

if __name__=='__main__':main()
