Quiet Calculus: additive causal memory revision, local date 2026-10-25

This package leaves all prior research/results read-only. It adds a causal
exponential-weight gate between the unchanged adaptive-memory expert and a
validation-selected fixed-rate expert. The gate learns from past Brier losses.

PROTOCOL.txt contains the derivation, candidate grid, selection rule, seed banks,
correctness/negative controls, revised primary target and unchanged v3 target.
protocol.json is the exact machine-readable configuration. freeze.json seals
both and all executable inputs before new tests or validation. A second seal,
results/selection_freeze.json, records selected settings before held-out tests.

Selection uses only 11 known generator families and 20 new seeds per family.
The two fresh 50-seed banks contain 1100 known-family paths plus 200 paths in
two newly authored transfer families excluded from selection. Transfer is
exploratory and excluded from both confirmatory-style decision gates.

results/raw_paths.jsonl preserves per-path scores and source/forecast hashes.
The first seed of every family in every bank includes complete observed streams,
all three forecast paths, and pre-outcome adaptive gate weights (26 traces).
results/summary.json contains all contrasts, both decision gates and compute.
results/execution_receipt.json and logs/ preserve exact commands, environment,
thread limits, wall times and return codes. audit_results.py independently
replays the selected scalar log-odds update, rescoring traces and checking
statistics, selection, and preservation of the entire prior v3 manifest.

Reproduce in a NEW destination:
  python3 -B reproduce_to.py /absolute/path/to/new-revision-reproduction

No network, model service, dependencies to install, or external actions. The
new target requires benefit over the original adaptive policy AND reduced
worst-scenario excess loss. It does not replace or excuse failure of the old
fixed-comparator target; both remain separately reported. Normal Monte Carlo
intervals are conditional on the declared synthetic design, not guarantees of
external validity, consciousness, or physical-theory confirmation.
