"""Causal squared-loss exponential aggregation of two unchanged experts.

Predict before observing y. Update old expert weights with their issued Brier
losses; optionally restart toward the declared prior for the next forecast.
No scenario, boundary, true probability, or future outcome enters this class.
"""
import math

def probability(p):
    if isinstance(p,bool) or not isinstance(p,(float,int)) or not math.isfinite(p) or not 0<=p<=1:
        raise ValueError('finite probability required')

class CausalGate:
    def __init__(self,eta=.5,prior_adaptive=.25,share=0.):
        if isinstance(eta,bool) or not isinstance(eta,(int,float)) or not math.isfinite(eta) or eta<=0:
            raise ValueError('positive finite eta required')
        probability(prior_adaptive);probability(share)
        if prior_adaptive in (0,1):raise ValueError('prior must give each expert positive mass')
        self.eta=eta;self.prior_adaptive=prior_adaptive;self.share=share
        self.logs=(math.log1p(-prior_adaptive),math.log(prior_adaptive));self.steps=0

    def weights(self):
        f,a=map(math.exp,self.logs);z=f+a;return f/z,a/z

    def predict(self,p_fixed,p_adaptive):
        probability(p_fixed);probability(p_adaptive)
        f,a=self.weights();return f*p_fixed+a*p_adaptive

    def step(self,p_fixed,p_adaptive,y):
        if isinstance(y,bool) or not isinstance(y,int) or y not in (0,1):raise ValueError('binary integer outcome required')
        issued=self.predict(p_fixed,p_adaptive)
        logs=tuple(w-self.eta*(p-y)**2 for w,p in zip(self.logs,(p_fixed,p_adaptive)))
        hi=max(logs);z=hi+math.log(math.fsum(math.exp(w-hi) for w in logs))
        logs=tuple(w-z for w in logs)
        if self.share:
            prior=(1-self.prior_adaptive,self.prior_adaptive)
            logs=tuple(math.log((1-self.share)*math.exp(w)+self.share*p) for w,p in zip(logs,prior))
        self.logs=logs;self.steps+=1
        return issued

def replay(fixed,adaptive,outcomes,params,trace=False):
    if not(len(fixed)==len(adaptive)==len(outcomes)):raise ValueError('equal lengths required')
    g=CausalGate(**params);predictions=[];weights=[]
    for pf,pa,y in zip(fixed,adaptive,outcomes):
        if trace:weights.append(g.weights()[1])
        before=g.predict(pf,pa);q=g.step(pf,pa,y)
        assert q==before
        predictions.append(q)
    return predictions,weights
