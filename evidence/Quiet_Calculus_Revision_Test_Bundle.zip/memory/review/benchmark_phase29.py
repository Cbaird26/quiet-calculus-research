#!/usr/bin/env python3
"""Paired, prequential Phase-2.9 experiment; Python standard library only."""
import argparse
from dataclasses import asdict
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec); sys.modules[name] = obj
    spec.loader.exec_module(obj); return obj
p25 = module('benchmark_p25', ROOT/'reference/phase25_suite.py')
p26 = module('benchmark_p26', ROOT/'reference/phase26_engine.py')
p27 = module('benchmark_p27', ROOT/'reference/phase27_engine.py')
p28 = module('benchmark_p28', ROOT/'reference/phase28_engine.py')
families = module('benchmark_families', ROOT/'reference/phase27_supplied.py')
p29 = module('benchmark_p29', ROOT/'corrected/phase2_9_bayesian_memory.py')
SCENARIOS = ('mixed_9', *p25.SCENARIOS, 'stationary_c', 'short_dwell', 'long_return', 'rare_row_gap')
CONFIGS = {'bayes': {}, 'share': {'share_rate': .02}, 'gap': {'gap_reset': 12},
    'share_gap': {'share_rate': .02, 'gap_reset': 12}, 'ttl': {'ttl': 90},
    'share_gap_ttl': {'share_rate': .02, 'gap_reset': 12, 'ttl': 90},
    'uniform': {'weighting': 'uniform'}, 'no_memory': {'memory_enabled': False}}

def scenario(name, seed):
    if name == 'mixed_9':
        pairs = [p25.A, p25.B, p25.A, p25.B, (.5,.5), (.88,.88), (.08,.12), p25.B, p25.A]
        return [p25.Block(45,*pair,label) for pair,label in zip(pairs,'ABABCDEBA')], 1.
    if name == 'stationary_c': return [p25.Block(405,.5,.5,'C')], .5
    if name == 'short_dwell': return p25.periodic_schedule(horizon=450,duration=10), 1.
    if name == 'long_return': return [p25.Block(n,*pair,label) for n,pair,label in [(90,p25.A,'A'),(270,p25.B,'B'),(90,p25.A,'A')]], 1.
    if name == 'rare_row_gap': return [p25.Block(60,*p25.A,'A'),p25.Block(150,.995,.995,'R'),p25.Block(90,.55,.05,'S')], 1.
    return p25.make_scenario(name, seed)

def datasets(name, seed):
    schedule,q0 = scenario(name,seed)
    return schedule,p25.generate_training(seed),p25.generate_stream(schedule,seed,q0=q0)

def baseline(kind, params, fit):
    if kind == 'mixture':
        obj=p29.Phase29Engine(**params); obj.initialize(fit.p11,fit.p01,fit.marginal)
    else:
        obj = families.FixedEMABaseline(**params) if kind=='ema' else families.TunedCUSUMBaseline(**params)
        obj.p11,obj.p01=fit.p11,fit.p01
    return obj

def run(obj, stream): return [obj.step_update(x,y) for x,y in zip(stream[:-1],stream[1:])]

def candidate_grids():
    return {'ema':[{'lr':i/100} for i in range(1,51)],
        'cusum':[{'lr':lr,'drift':d,'threshold':t} for lr in (.02,.05,.10,.14,.18,.20,.35,.50)
            for d in (.30,.32,.36,.38,.40,.45) for t in (.50,1.,1.25,1.45,1.65,2.5,4.,1e9)],
        'mixture':[{'share_rate':h,'gap_reset':g} for h in (0.,.005,.02,.05,.10) for g in (None,6,12,24)]}

def tune(n=30):
    data=[(s,*datasets('mixed_9',s)[1:]) for s in range(201000000,201000000+n)]
    candidates={}
    for kind,grid in candidate_grids().items():
        candidates[kind]=[]
        for params in grid:
            scores=[{'seed':s,**p25.score(stream[1:],run(baseline(kind,params,fit),stream))} for s,fit,stream in data]
            candidates[kind].append({'params':params,'mean_brier':statistics.mean(r['brier'] for r in scores),
                'mean_bce':statistics.mean(r['bce'] for r in scores),'per_seed':scores})
        print('Validation completed:',kind,len(grid),flush=True)
    return {'selection':'Mixed_9 mean validation Brier only; first grid entry wins exact ties',
        'range':[201000000,201000000+n-1], 'candidate_results':candidates,
        'selected':{kind:min(rows,key=lambda r:r['mean_brier'])['params'] for kind,rows in candidates.items()}}

def models(fit, selected):
    out={name:baseline('mixture',params,fit) for name,params in CONFIGS.items()}
    out['validation_mixture']=baseline('mixture',selected['mixture'],fit)
    for name,cls,kwargs in [('phase25',p25.RefinedQualiaEngineV1_1,{}),
        ('pinned_no_memory',p25.RefinedQualiaEngineV1_1,{'enable_episodic_memory':False}),
        ('phase26',p26.NoveltyAwareEngineV1_2,{}),('phase27',p27.Phase27Engine,{}),('phase28',p28.Phase28Engine,{})]:
        obj=cls(**kwargs);obj.initialize(fit.p11,fit.p01,fit.marginal);out[name]=obj
    for kind in ('ema','cusum'): out['validation_'+kind]=baseline(kind,selected[kind],fit)
    out['prior_fixed_ema']=baseline('ema',{'lr':.28},fit)
    out['prior_fixed_cusum']=baseline('cusum',{'lr':.18,'drift':.40,'threshold':1.},fit)
    return out

def slices(schedule, stream):
    scopes={k:[] for k in ('overall','familiar_return','novel','white_noise','novel_d','novel_e','postnovel_return','early_10','later_than_10','after_row_gap')}
    start=0;seen=set();novel_seen=False;blocks=[]
    for ix,b in enumerate(schedule):
        stop=start+b.dwell;ids=list(range(start,stop));scopes['overall']+=ids
        if b.label in ('C','D','E'): scopes['novel']+=ids;novel_seen=True
        if b.label=='C':scopes['white_noise']+=ids
        if b.label=='D':scopes['novel_d']+=ids
        if b.label=='E':scopes['novel_e']+=ids
        if b.label in seen:
            scopes['familiar_return']+=ids
            if novel_seen and b.label in ('A','B'):scopes['postnovel_return']+=ids
        if ix:scopes['early_10']+=list(range(start,min(start+10,stop)))
        scopes['later_than_10']+=list(range(min(start+10,stop),stop))
        blocks.append({'index':ix,**asdict(b),'start':start,'end':stop});seen.add(b.label);start=stop
    last=[None,None]
    for t,x in enumerate(stream[:-1]):
        if last[x] is not None and t-last[x]>12:scopes['after_row_gap'].append(t)
        last[x]=t
    # Sparse, random-count gap scopes are reported conditional on having an event.
    return {k:v for k,v in scopes.items() if v},blocks

def path_hash(values):return hashlib.sha256(json.dumps(values,separators=(',',':')).encode()).hexdigest()

def evaluate(seed, name, selected, keep_trace=False):
    schedule,fit,stream=datasets(name,seed);scopes,blocks=slices(schedule,stream)
    truths=p25.flatten_schedule(schedule);paths={};events={};base_paths={};archives={};traces={}
    for arm,obj in models(fit,selected).items():
        path=[];base_path=[];diagnostics=[];fulltrace=[]
        for t,(prev,y) in enumerate(zip(stream[:-1],stream[1:])):
            before=obj.predict_proba(prev) if hasattr(obj,'predict_proba') else (obj.p11 if prev else obj.p01)
            issued=obj.step_update(prev,y);assert issued==before
            path.append(issued)
            if isinstance(obj,p29.Phase29Engine):
                d=obj.last_step;base_p=d['base_prediction'];base_path.append(base_p)
                q=truths[t][0 if prev else 1]
                diagnostics.append({'memory_weight':d['memory_weight'],'gap_resets':int(d['gap_reset']),
                    'expired_weight':d['expired_weight'],'new_experts':int(d['new_expert']),
                    'archive_size':d['archive_size'],'oldest_weighted_age':d['oldest_weighted_age'],
                    'conditional_brier_change':(issued-q)**2-(base_p-q)**2})
                if keep_trace:fulltrace.append({'t':t,'prev':prev,'y':y,**{k:v for k,v in d.items() if k!='log_weights'}})
        paths[arm]=path
        if diagnostics:
            events[arm]=diagnostics;base_paths[arm]=base_path
            archives[arm]=[asdict(s) for s in obj.archive]
        if keep_trace and fulltrace:traces[arm]=fulltrace
    assert paths['no_memory']==paths['pinned_no_memory']
    assert all(v==paths['pinned_no_memory'] for v in base_paths.values())
    assert all(v==archives['bayes'] for v in archives.values())
    paths['oracle_regime']=[a if stream[t] else b for t,(a,b) in enumerate(truths)]
    y=stream[1:]
    metrics={scope:{a:p25.score([y[i] for i in ids],[p[i] for i in ids]) for a,p in paths.items()} for scope,ids in scopes.items()}
    aggregate={scope:{a:{key:(sum(trace[i][key] for i in ids) if key in ('gap_resets','new_experts') else statistics.mean(trace[i][key] for i in ids))
        for key in trace[0]} for a,trace in events.items()} for scope,ids in scopes.items()}
    for b in blocks:
        start,stop=b['start'],b['end'];b['metrics']={a:p25.score(y[start:stop],p[start:stop]) for a,p in paths.items()}
    result={'seed':seed,'scenario':name,'training':asdict(fit),'metrics':metrics,'events':aggregate,'blocks':blocks,
        'scope_n':{s:len(ids) for s,ids in scopes.items()},'archive':archives['bayes'],
        'forecast_sha256':{a:path_hash(p) for a,p in paths.items()},
        'identities':{'no_memory_exact':True,'all_shadow_base_paths_exact':True,'all_archives_equal':True}}
    if keep_trace:result['trace']={'stream':stream,'forecasts':paths,'mixture_diagnostics':traces}
    return result

def interval(xs):
    n=len(xs);mean=statistics.mean(xs);sd=statistics.stdev(xs) if n>1 else 0.
    half=1.96*sd/math.sqrt(n)
    return {'n':n,'mean':mean,'sd':sd,'ci95':[mean-half,mean+half] if n>1 else None}

def summarize(rows):
    result={}
    for split in ('primary','replication'):
        result[split]={}
        for name in SCENARIOS:
            rr=[r for r in rows if r['split']==split and r['scenario']==name]
            scopes={}
            for scope in sorted(set().union(*(r['metrics'] for r in rr))):
                subset=[r for r in rr if scope in r['metrics']];arms=subset[0]['metrics'][scope]
                scopes[scope]={'n_seeds_with_scope':len(subset),
                    'metrics':{a:{m:interval([r['metrics'][scope][a][m] for r in subset]) for m in ('brier','bce')} for a in arms},
                    'share_gap_minus':{a:{m:interval([r['metrics'][scope]['share_gap'][m]-r['metrics'][scope][a][m] for r in subset]) for m in ('brier','bce')} for a in arms if a!='share_gap'},
                    'events':{a:{k:interval([r['events'][scope][a][k] for r in subset]) for k in ev} for a,ev in subset[0]['events'][scope].items()}}
            result[split][name]={'scopes':scopes,'identity_counts':{k:sum(r['identities'][k] for r in rr) for k in rr[0]['identities']}}
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'results/benchmark.json')
    ap.add_argument('--seeds',type=int,default=100);ap.add_argument('--validation-seeds',type=int,default=30)
    args=ap.parse_args()
    if not 2<=args.seeds<=10000 or not 2<=args.validation_seeds<=10000:raise ValueError('seed counts must be 2..10000')
    frozen=[ROOT/'PROTOCOL.txt',ROOT/'corrected/phase2_9_bayesian_memory.py',Path(__file__),*sorted((ROOT/'reference').glob('*.py'))]
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in frozen}
    manifest=tune(args.validation_seeds)
    manifest['plan_before_test']={'scenarios':SCENARIOS,'primary':[181000000,181000000+args.seeds-1],
        'replication':[191000000,191000000+args.seeds-1],'configs':CONFIGS,'sha256':hashes,
        'status':'Exploratory; design and validation selection written before evaluating either test bank'}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    raw=(json.dumps(manifest,indent=2)+'\n').encode();args.output.with_name('validation_manifest.json').write_bytes(raw)
    print('Frozen selection:',manifest['selected'],hashlib.sha256(raw).hexdigest(),flush=True)
    rows=[]
    for split,start in [('primary',181000000),('replication',191000000)]:
        for name in SCENARIOS:
            for seed in range(start,start+args.seeds):
                rows.append({'split':split,**evaluate(seed,name,manifest['selected'],keep_trace=(name=='mixed_9' and seed==start))})
            print('Completed',split,name,args.seeds,flush=True)
    assert hashes=={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in frozen}
    report={'metadata':{'selected':manifest['selected'],'validation_manifest_sha256':hashlib.sha256(raw).hexdigest(),
        'seeds_per_bank':args.seeds,'n_paths':len(rows),'n_arms':len(rows[0]['metrics']['overall'])-1,
        'identical_shadow_paths':sum(len(CONFIGS)+1 for _ in rows),'frozen_no_memory_matches':len(rows),
        'statistics':'Pointwise normal 95% Monte Carlo CIs of seed-level paired differences; exploratory, no multiplicity correction. Gap scope conditional on event occurrence.',
        'truth':'Oracle and conditional-risk diagnostics are analysis only, unavailable to learners.',
        'scope':'Functional prediction simulation; no phenomenal consciousness or physical theory validation.'},
        'summary':summarize(rows),'raw_per_seed':rows}
    args.output.write_text(json.dumps(report,separators=(',',':'),allow_nan=False)+'\n')
    for split in report['summary']:
        print('\n',split,'mixed_9 overall')
        for a,ms in report['summary'][split]['mixed_9']['scopes']['overall']['metrics'].items():
            print(a,*(f'{m}={v["mean"]:.8f}' for m,v in ms.items()))
if __name__=='__main__':main()
