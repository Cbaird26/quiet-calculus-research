#!/usr/bin/env python3
"""Deterministic Phase 2.9 invariants; no empirical performance assertions."""
from dataclasses import FrozenInstanceError
import importlib.util
import math
from pathlib import Path
import pickle
import random
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('tested_phase29',ROOT/'corrected/phase2_9_bayesian_memory.py')
mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
Engine=mod.Phase29Engine


def observations(n=240):
    rng=random.Random(73);prev=1
    for t in range(n):
        a,b=(.92,.28) if (t//40)%2==0 else (.15,.85)
        y=int(rng.random()<(a if prev else b))
        yield prev,y
        prev=y


def engine(**kwargs):
    e=Engine(**kwargs);e.initialize(.92,.28,7/9);return e


def loss(y,p):
    return -math.log(p if y else 1-p)


class TestPhase29Engine(unittest.TestCase):
    def test_predict_is_pure_even_when_gap_or_ttl_applies(self):
        e=engine(gap_reset=2,ttl=2)
        for prev,y in [(0,1),(1,1),(1,1),(1,0)]:e.step_update(prev,y)
        before=pickle.dumps(e)
        a=e.predict_proba(0)
        self.assertEqual(a,e.predict_proba(0));self.assertEqual(pickle.dumps(e),before)

    def test_invalid_step_inputs_do_not_mutate(self):
        e=engine();e.step_update(1,0)
        for prev,y in [(2,0),(0,2),(-1,1),(1,float('nan')),(True,0),(0,.5)]:
            before=pickle.dumps(e)
            with self.assertRaises(ValueError):e.step_update(prev,y)
            self.assertEqual(pickle.dumps(e),before)

    def test_invalid_predict_does_not_mutate(self):
        e=engine();before=pickle.dumps(e)
        with self.assertRaises(ValueError):e.predict_proba(float('inf'))
        self.assertEqual(pickle.dumps(e),before)

    def test_invalid_initialize_preserves_existing_run(self):
        e=engine();e.step_update(1,0);before=pickle.dumps(e)
        with self.assertRaises(ValueError):e.initialize(.3,float('nan'),.6)
        self.assertEqual(pickle.dumps(e),before)

    def test_parameter_validation(self):
        bad=[{'share_rate':-.01},{'share_rate':float('nan')},{'share_rate':1.1},
             {'gap_reset':1.5},{'ttl':-1},{'ttl':True},{'max_snapshots':-1},
             {'max_snapshots':True},{'weighting':'unrecognized'},{'memory_enabled':1}]
        for kw in bad:
            with self.assertRaises(ValueError):Engine(**kw)

    def test_initialize_clears_all_run_state(self):
        e=engine(share_rate=.02,gap_reset=12,ttl=90)
        for prev,y in observations():e.step_update(prev,y)
        e.initialize(.92,.28,7/9)
        fresh=engine(share_rate=.02,gap_reset=12,ttl=90)
        self.assertEqual(pickle.dumps(e),pickle.dumps(fresh))

    def test_no_memory_forecasts_exact_pinned_base(self):
        e=engine(memory_enabled=False)
        ref=mod._P25.RefinedQualiaEngineV1_1(enable_episodic_memory=False);ref.initialize(.92,.28,7/9)
        for prev,y in observations():
            before=ref.predict_proba(prev)
            self.assertEqual(e.predict_proba(prev),before)
            self.assertEqual(e.step_update(prev,y),ref.step_update(prev,y))
            self.assertEqual(e.last_step['memory_weight'],0.)
        self.assertGreater(len(e.archive),1)

    def test_common_base_and_immutable_archive_across_policies(self):
        arms=[engine(**kw) for kw in ({},{'share_rate':.02},{'gap_reset':12},
             {'ttl':90},{'share_rate':.02,'gap_reset':12,'ttl':90},
             {'weighting':'uniform'},{'memory_enabled':False})]
        for prev,y in observations():
            for e in arms:e.step_update(prev,y)
            for e in arms[1:]:
                self.assertEqual(pickle.dumps(e.base),pickle.dumps(arms[0].base))
                self.assertEqual(e.archive,arms[0].archive)
        self.assertGreater(len(arms[0].archive),1)

    def test_snapshot_objects_and_existing_parameters_never_mutate(self):
        e=engine();record={0:e.archive[0]}
        with self.assertRaises(FrozenInstanceError):e.archive[0].p11=.3
        for prev,y in observations():
            e.step_update(prev,y)
            for i,snap in record.items():self.assertEqual(e.archive[i],snap)
            record.update(enumerate(e.archive))

    def test_admission_is_distinct_from_every_old_snapshot_and_capped(self):
        e=engine(max_snapshots=3)
        for prev,y in observations(600):
            e.step_update(prev,y)
            self.assertLessEqual(len(e.archive),3)
            if e.last_step['new_expert']:
                new=e.archive[-1]
                for old in e.archive[:-1]:self.assertGreaterEqual(math.hypot(new.p11-old.p11,new.p01-old.p01),.12)
        self.assertEqual(len(e.archive),3)

    def test_birth_is_next_forecast_with_no_birth_likelihood_credit(self):
        e=engine();seen=0
        for prev,y in observations():
            n=len(e.archive);issued=e.predict_proba(prev);ret=e.step_update(prev,y)
            self.assertEqual(issued,ret)
            self.assertEqual(len(e.last_step['weights']),n+1)
            self.assertEqual(len(e.last_step['expert_predictions']),n+1)
            if e.last_step['new_expert']:
                seen+=1
                self.assertEqual(e.archive[-1].born,e.last_step['step_index']+1)
                for row in (0,1):
                    self.assertAlmostEqual(e.last_step['weights_after_admission'][row][-1],.1)
                    self.assertAlmostEqual(e.last_step['weights_after_update'][row][-1],.1)
        self.assertGreater(seen,0)

    def test_likelihood_update_uses_cached_preoutcome_predictions(self):
        e=engine(max_snapshots=1)
        e.step_update(1,0)
        old=e._forecast(0)
        e.step_update(0,1)
        cached=e.last_step
        expected=[w*p for w,p in zip(old['weights'],old['expert_predictions'])]
        expected=[v/sum(expected) for v in expected]
        for a,b in zip(cached['weights_after_update'][0],expected):self.assertAlmostEqual(a,b)
        self.assertEqual(cached['expert_predictions'],old['expert_predictions'])

    def test_bayes_evidence_updates_only_active_row(self):
        e=engine(max_snapshots=1);inactive=e.log_weights[0]
        for y in (0,1,0,0):e.step_update(1,y)
        self.assertEqual(e.log_weights[0],inactive)
        self.assertNotEqual(e.log_weights[1],inactive)

    def test_global_share_changes_inactive_row_once_per_observation(self):
        e=engine(share_rate=.02,max_snapshots=1)
        e.log_weights[0]=(math.log(.8),math.log(.2))
        before=pickle.dumps(e);e.predict_proba(1);e.predict_proba(1)
        self.assertEqual(pickle.dumps(e),before)
        e.step_update(1,1)
        weights=e.last_step['weights_after_update'][0]
        self.assertAlmostEqual(weights[0],.98*.8+.02*.5)
        self.assertAlmostEqual(weights[1],.98*.2+.02*.5)

    def test_gap_reset_strict_boundary_and_observation_clock(self):
        e=engine(gap_reset=12,max_snapshots=1)
        e.step_update(0,1)  # last row0 observation index0
        for _ in range(11):e.step_update(1,1)
        self.assertEqual(e.step_index,12);self.assertFalse(e._forecast(0)['gap_reset'])
        e.step_update(1,0)
        self.assertTrue(e._forecast(0)['gap_reset'])
        e.step_update(0,1)
        self.assertTrue(e.last_step['gap_reset'])
        self.assertEqual(e.last_step['weights'],(.5,.5))
        self.assertEqual(e.last_seen[0],13)

    def test_never_observed_row_does_not_claim_gap_reset(self):
        e=engine(gap_reset=2,max_snapshots=1)
        for _ in range(10):e.step_update(1,1)
        self.assertIsNone(e.last_seen[0]);self.assertFalse(e._forecast(0)['gap_reset'])

    def test_ttl_strict_age_boundary_and_mass_transfer(self):
        e=engine(ttl=90,max_snapshots=1)
        for _ in range(90):e.step_update(1,1)
        self.assertEqual(e.archive[0].born,0)
        self.assertEqual(e._forecast(0)['eligible_memory_count'],1)
        e.step_update(1,1)
        f=e._forecast(0)
        self.assertEqual(f['eligible_memory_count'],0)
        self.assertEqual(f['weights'],(1.,0.));self.assertAlmostEqual(f['expired_weight'],.5)
        self.assertEqual(f['prediction'],e.base.predict_proba(0))

    def test_expired_experts_cannot_revive_and_remain_at_capacity(self):
        e=engine(ttl=1,share_rate=.02,max_snapshots=1)
        for prev,y in observations(120):
            e.step_update(prev,y)
            if e.step_index>1:
                for row in (0,1):self.assertEqual(e._forecast(row)['memory_weight'],0.)
        self.assertEqual(len(e.archive),1);self.assertEqual(e.stats['admissions'],0)

    def test_uniform_control_is_half_base_half_eligible_memory(self):
        e=engine(weighting='uniform')
        for prev,y in observations():e.step_update(prev,y)
        self.assertGreater(len(e.archive),1)
        weights=e._forecast(0)['weights']
        self.assertAlmostEqual(weights[0],.5)
        for w in weights[1:]:self.assertAlmostEqual(w,.5/len(e.archive))

    def test_zero_capacity_reduces_to_base(self):
        e=engine(max_snapshots=0)
        for prev,y in observations(50):
            p=e.base.predict_proba(prev)
            self.assertEqual(e.step_update(prev,y),p)
            self.assertEqual(e.archive,[]);self.assertEqual(e.last_step['weights'],(1.,))

    def test_log_weights_remain_finite_despite_numerical_underflow(self):
        e=Engine(max_snapshots=1);e.initialize(.001,.001,.5)
        for _ in range(3000):
            self.assertTrue(0<e.step_update(1,1)<1)
        self.assertTrue(all(math.isfinite(x) for x in e.log_weights[1]))
        self.assertLess(e.log_weights[1][1],-1000)

    def test_endpoint_likelihoods_finite_and_disabled_forecast_exact(self):
        for p,y in ((0.,1),(1.,0)):
            e=Engine(max_snapshots=1);e.initialize(p,p,p)
            value=e.step_update(1,y)
            self.assertTrue(0<value<1)
            self.assertTrue(all(math.isfinite(x) for x in e.log_weights[1]))
            disabled=Engine(memory_enabled=False);disabled.initialize(p,p,p)
            self.assertEqual(disabled.step_update(1,y),p)

    def test_fixed_bank_log_loss_evidence_identity_and_bound(self):
        # No admission/share/reset/masking: expert0 is the predictable adaptive base,
        # expert1 the immutable initial snapshot. Row-factorized prior=.5/.5.
        e=engine(max_snapshots=1)
        expert_loss=[[0.,0.],[0.,0.]];mix_loss=[0.,0.]
        for row,y in observations(240):
            forecast=e.step_update(row,y);d=e.last_step
            mix_loss[row]+=loss(y,forecast)
            for k,p in enumerate(d['expert_predictions']):expert_loss[row][k]+=loss(y,p)
        for row in (0,1):
            a,b=expert_loss[row];best=min(a,b)
            negative_log_evidence=best-math.log(.5*math.exp(best-a)+.5*math.exp(best-b))
            self.assertAlmostEqual(mix_loss[row],negative_log_evidence,places=10)
            self.assertLessEqual(mix_loss[row],best+math.log(2)+1e-10)
        self.assertLessEqual(sum(mix_loss),sum(x[0] for x in expert_loss)+2*math.log(2)+1e-10)


if __name__=='__main__':
    unittest.main(verbosity=2)
