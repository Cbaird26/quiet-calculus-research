#!/usr/bin/env python3
import copy
import json
import unittest
import benchmark_phase29 as b

SELECTED={'ema':{'lr':.28},'cusum':{'lr':.18,'drift':.4,'threshold':1.},'mixture':{'share_rate':.02,'gap_reset':12}}

class HarnessTests(unittest.TestCase):
    def test_mixed9_exact_frozen_schedule(self):
        s,q=b.scenario('mixed_9',7)
        self.assertEqual(''.join(x.label for x in s),'ABABCDEBA')
        self.assertEqual([(x.p11,x.p01) for x in s],[b.p25.A,b.p25.B,b.p25.A,b.p25.B,(.5,.5),(.88,.88),(.08,.12),b.p25.B,b.p25.A])
        self.assertEqual(sum(x.dwell for x in s),405);self.assertEqual(q,1.)

    def test_previous_scenarios_unchanged(self):
        for name in b.p25.SCENARIOS:self.assertEqual(b.scenario(name,42),b.p25.make_scenario(name,42))

    def test_new_scenarios_explicit(self):
        self.assertEqual(sum(x.dwell for x in b.scenario('short_dwell',1)[0]),450)
        self.assertTrue(all(x.dwell==10 for x in b.scenario('short_dwell',1)[0]))
        self.assertEqual([x.dwell for x in b.scenario('long_return',1)[0]],[90,270,90])
        self.assertEqual([x.dwell for x in b.scenario('rare_row_gap',1)[0]],[60,150,90])

    def test_training_and_stream_reproducible(self):
        s,f,x=b.datasets('mixed_9',987654)
        self.assertEqual((s,f,x),b.datasets('mixed_9',987654))
        self.assertNotEqual(x,b.datasets('mixed_9',987655)[2])
        self.assertEqual(f.n1+f.n0,696)

    def test_grid_is_prespecified(self):
        self.assertEqual({k:len(v) for k,v in b.candidate_grids().items()},{'ema':50,'cusum':384,'mixture':20})
        self.assertIn({'share_rate':.02,'gap_reset':12},b.candidate_grids()['mixture'])

    def test_scope_partition_and_row_gap(self):
        schedule=[b.p25.Block(14,.9,.1,'A'),b.p25.Block(4,.5,.5,'C')]
        stream=[0]+[1]*13+[0]*5
        scopes,blocks=b.slices(schedule,stream)
        self.assertEqual(scopes['after_row_gap'],[14])
        self.assertEqual(scopes['white_noise'],list(range(14,18)))
        self.assertEqual(scopes['early_10'],list(range(14,18)))
        self.assertEqual(blocks[-1]['end'],18)

    def test_full_path_no_memory_and_common_bank(self):
        r=b.evaluate(777777,'rare_row_gap',SELECTED)
        self.assertTrue(all(r['identities'].values()))
        self.assertEqual(r['forecast_sha256']['no_memory'],r['forecast_sha256']['pinned_no_memory'])

    def test_trace_scores_recompute(self):
        r=b.evaluate(888888,'mixed_9',SELECTED,True)
        json.dumps(r,allow_nan=False)
        for arm,path in r['trace']['forecasts'].items():
            self.assertEqual(r['metrics']['overall'][arm],b.p25.score(r['trace']['stream'][1:],path))
        for arm,trace in r['trace']['mixture_diagnostics'].items():
            self.assertEqual(len(trace),405)
            self.assertEqual([x['base_prediction'] for x in trace],r['trace']['forecasts']['no_memory'])

    def test_paired_summary_uses_seeds_not_transitions(self):
        r=b.evaluate(999999,'mixed_9',SELECTED)
        original=b.SCENARIOS
        try:
            b.SCENARIOS=('mixed_9',)
            rows=[{**copy.deepcopy(r),'split':split} for split in ('primary','primary','replication','replication')]
            out=b.summarize(rows)['primary']['mixed_9']['scopes']['overall']
            self.assertEqual(out['metrics']['share_gap']['brier']['n'],2)
            expected=r['metrics']['overall']['share_gap']['brier']-r['metrics']['overall']['bayes']['brier']
            self.assertEqual(out['share_gap_minus']['bayes']['brier']['mean'],expected)
        finally:b.SCENARIOS=original

if __name__=='__main__':unittest.main(verbosity=2)
