"""Deterministic causal invariants, frozen before performance evaluation."""
import copy
import math
import pickle
import random
import unittest
import benchmark_phase29 as b

m = b.module('fresh_test_phase210', b.ROOT/'corrected/phase2_10_adaptive_memory.py')

def observations(n=800):
    rng=random.Random(531477)
    prev=1
    for t in range(n):
        a,c=((.92,.28),(.15,.85),(.8,.8),(.1,.1))[(t//40)%4]
        y=int(rng.random()<(a if prev else c))
        yield prev,y
        prev=y

def make(**kw):
    e=m.Phase210Engine(**kw);e.initialize(.92,.28,7/9);return e

def bank(e):
    return [(s.p11,s.p01,s.born) for s in e.archive]

class CausalTests(unittest.TestCase):
    def test_predict_pure(self):
        e=make()
        for x,y in observations(80):e.step_update(x,y)
        before=pickle.dumps(e)
        for x in (0,1):self.assertEqual(e.predict_proba(x),e.predict_proba(x))
        self.assertEqual(pickle.dumps(e),before)

    def test_invalid_inputs_do_not_mutate(self):
        e=make();e.step_update(1,0)
        for x,y in [(True,0),(0,True),(2,1),(0,float('nan'))]:
            before=pickle.dumps(e)
            with self.assertRaises(ValueError):e.step_update(x,y)
            self.assertEqual(pickle.dumps(e),before)

    def test_forecast_does_not_depend_on_current_outcome(self):
        e=make()
        for x,y in observations(100):
            before=e.predict_proba(x)
            self.assertEqual(copy.deepcopy(e).step_update(x,0),before)
            self.assertEqual(copy.deepcopy(e).step_update(x,1),before)
            self.assertEqual(e.step_update(x,y),before)

    def test_no_memory_is_exact_pinned_base(self):
        e=make(memory_enabled=False)
        p=b.p25.RefinedQualiaEngineV1_1(enable_episodic_memory=False);p.initialize(.92,.28,7/9)
        for x,y in observations():self.assertEqual(e.step_update(x,y),p.step_update(x,y))

    def test_single_hazard_matches_independent_p29_implementation(self):
        for h in (0.,.005,.02,.05,.1,.2):
            e=make(hazards=(h,),replacement='none')
            p=b.p29.Phase29Engine(share_rate=h);p.initialize(.92,.28,7/9)
            for x,y in observations(300):
                self.assertAlmostEqual(e.step_update(x,y),p.step_update(x,y),places=12)
                self.assertEqual(bank(e),bank(p))

    def test_common_base_archive_across_weighting(self):
        arms=[make(replacement='none',**kw) for kw in ({},{'meta_mode':'uniform'},{'hazards':(.02,)},{'memory_enabled':False})]
        for x,y in observations(300):
            for e in arms:e.step_update(x,y)
            for e in arms[1:]:
                self.assertEqual(bank(e),bank(arms[0]))
                self.assertEqual(e.last_step['base_prediction'],arms[0].last_step['base_prediction'])

    def test_admission_gets_no_birth_likelihood_or_utility(self):
        e=make(max_snapshots=3,replacement='fifo');n=0
        for x,y in observations():
            e.step_update(x,y);d=e.last_step
            self.assertEqual(len(d['expert_predictions']),len(d['bank_ids_before'])+1)
            if d['admission']:
                n+=1;self.assertEqual(e.archive[-1].born,d['step_index']+1)
                self.assertEqual(e.utility[e.archive[-1].id],0.)
                for rate in d['new_mass_before_share']:
                    for mass in rate:self.assertAlmostEqual(mass,.1,places=12)
        self.assertGreater(n,0)

    def test_replacement_holds_capacity_and_probability_mass(self):
        for policy in ('fifo','utility'):
            e=make(max_snapshots=2,replacement=policy);replaced=0
            for x,y in observations():
                e.step_update(x,y);d=e.last_step
                self.assertLessEqual(len(e.archive),2)
                for rate in e.rate_log_weights:
                    for row in rate:self.assertAlmostEqual(sum(math.exp(w) for w in row),1.,places=12)
                self.assertAlmostEqual(sum(math.exp(w) for w in e.meta_log_weights),1.,places=12)
                if d['replacement']:
                    replaced+=1;self.assertNotIn(d['victim_id'],d['bank_ids_after'])
                    self.assertEqual(len(d['eviction_transferred_mass']),len(e.hazards))
                    self.assertTrue(all(0<=v<=1 for rate in d['eviction_transferred_mass'] for v in rate))
            self.assertGreater(replaced,0)

    def test_snapshot_values_immutable_while_retained(self):
        e=make(replacement='utility',max_snapshots=3);seen={}
        for x,y in observations():
            e.step_update(x,y)
            for s in e.archive:
                if s.id in seen:self.assertEqual(seen[s.id],s)
                seen[s.id]=s

if __name__=='__main__':unittest.main(verbosity=2)
