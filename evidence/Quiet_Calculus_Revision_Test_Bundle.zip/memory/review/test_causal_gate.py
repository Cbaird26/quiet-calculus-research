import copy
import math
import pickle
import unittest
from causal_gate import CausalGate,replay

class GateTests(unittest.TestCase):
    def test_predict_pure(self):
        g=CausalGate();before=pickle.dumps(g)
        self.assertEqual(g.predict(.7,.2),g.predict(.7,.2));self.assertEqual(pickle.dumps(g),before)

    def test_current_outcome_cannot_change_emitted_forecast(self):
        g=CausalGate(eta=128)
        for _ in range(5):g.step(.6,.4,1)
        self.assertEqual(copy.deepcopy(g).step(.8,.2,0),copy.deepcopy(g).step(.8,.2,1))

    def test_future_suffix_cannot_change_prefix(self):
        f=[.8,.3,.65,.1,.9,.2];a=[.3,.7,.4,.8,.2,.9];y=[1,0,1,0,1,1]
        first,_=replay(f,a,y,{'eta':32,'prior_adaptive':.25,'share':.02})
        other,_=replay(f[:3]+[.9,.9,.9],a[:3]+[.1,.1,.1],y[:3]+[1,0,0],{'eta':32,'prior_adaptive':.25,'share':.02})
        self.assertEqual(first[:3],other[:3])

    def test_invalid_input_no_mutation(self):
        g=CausalGate()
        for f,a,y in [(float('nan'),.5,1),(.1,1.5,0),(.1,.2,True),(.1,.2,2)]:
            before=pickle.dumps(g)
            with self.assertRaises(ValueError):g.step(f,a,y)
            self.assertEqual(pickle.dumps(g),before)

    def test_weights_normalized_and_predictions_in_expert_hull(self):
        for eta in (.5,2,8,32,128):
            g=CausalGate(eta=eta,share=.02)
            for t in range(1000):
                f=(t%7)/7;a=(t%11)/11;q=g.step(f,a,t%2)
                self.assertGreaterEqual(q,min(f,a)-1e-15);self.assertLessEqual(q,max(f,a)+1e-15)
                self.assertAlmostEqual(sum(g.weights()),1.,places=14)

    def test_identical_experts_reproduce_forecast(self):
        g=CausalGate(eta=128,share=.02)
        for t in range(100):
            p=(t%9)/9;self.assertAlmostEqual(g.step(p,p,t%2),p,places=14)

    def test_analytic_one_step_posterior_and_restart(self):
        g=CausalGate(eta=2,prior_adaptive=.25,share=.02);g.step(.8,.2,1)
        f=.75*math.exp(-2*.04);a=.25*math.exp(-2*.64)
        expected=.98*a/(f+a)+.02*.25
        self.assertAlmostEqual(g.weights()[1],expected,places=14)

    def test_safe_rate_cumulative_bound(self):
        f=[.8,.2,.9,.1]*40;a=[.2,.8,.1,.9]*40;y=[1,1,0,0]*40
        p,_=replay(f,a,y,{'eta':.5,'prior_adaptive':.5,'share':0})
        loss=sum((p0-y0)**2 for p0,y0 in zip(p,y))
        best=min(sum((v-y0)**2 for v,y0 in zip(e,y)) for e in (f,a))
        self.assertLessEqual(loss-best,2*math.log(2)+1e-12)

    def test_negative_control_update_before_predict_detected(self):
        def leaky(y):
            g=CausalGate(eta=32);g.step(.9,.1,y);return g.predict(.9,.1)
        self.assertNotEqual(leaky(0),leaky(1))
        g=CausalGate(eta=32)
        self.assertEqual(copy.deepcopy(g).step(.9,.1,0),copy.deepcopy(g).step(.9,.1,1))

    def test_negative_control_reversed_loss_detected(self):
        f,a=.8,.2;wf=wa=.5;bad_loss=0
        for _ in range(50):
            bad_loss+=(wf*f+wa*a-1)**2
            wf*=math.exp(.5*(f-1)**2);wa*=math.exp(.5*(a-1)**2)
            z=wf+wa;wf/=z;wa/=z
        self.assertGreater(bad_loss-50*(f-1)**2,2*math.log(2))

if __name__=='__main__':unittest.main(verbosity=2)
