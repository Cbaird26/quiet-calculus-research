from collections import defaultdict
from dataclasses import asdict
from datetime import datetime,timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import time
import benchmark_phase29 as b
from causal_gate import replay

ROOT=b.ROOT
C=json.loads((ROOT/'protocol.json').read_text())
P210=b.module('revision_phase210',ROOT/'corrected/phase2_10_adaptive_memory.py')

def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ph(v):return hashlib.sha256(json.dumps(v,separators=(',',':')).encode()).hexdigest()
def frozen():
    x=json.loads((ROOT/'freeze.json').read_text())
    for n,h in x['files'].items():assert sha(ROOT/n)==h,n
    return sha(ROOT/'freeze.json')

def data(name,seed):
    if name in C['known_scenarios']:
        _,fit,stream=b.datasets(name,seed);return fit,stream
    fit=b.p25.generate_training(seed);n=600
    rng=b.p25.make_rng(seed,'revision-'+name+'-observations')
    if name=='smooth_drift':
        phase=b.p25.make_rng(seed,'revision-drift-phase').uniform(0,2*math.pi)
        stream=[int(rng.random()<.5)]
        for t in range(n):
            p11=.5+.4*math.sin(2*math.pi*t/150+phase)
            p01=.5+.4*math.sin(2*math.pi*t/97+1+phase)
            stream.append(int(rng.random()<(p11 if stream[-1] else p01)))
        return fit,stream
    if name=='hidden_sensor_flip':
        noise=b.p25.make_rng(seed,'revision-sensor-corruption');latent=1;stream=[latent]
        for t in range(n):
            p11,p01=b.p25.A if (t//60)%2==0 else b.p25.B
            latent=int(rng.random()<(p11 if latent else p01))
            rate=.25 if any(start<=t<start+15 for start in (120,300,480)) else .02
            stream.append(latent ^ int(noise.random()<rate))
        return fit,stream
    raise ValueError(name)

def engine(fit,h=None):
    kw={'hazards':tuple(C['hazards']) if h is None else (h,),'meta_share':.01,'replacement':'none','max_snapshots':8}
    e=P210.Phase210Engine(**kw);e.initialize(fit.p11,fit.p01,fit.marginal);return e

def expert(e,stream):
    started=time.perf_counter();p=[];base=[]
    for x,y in zip(stream[:-1],stream[1:]):
        before=e.predict_proba(x);issued=e.step_update(x,y);assert before==issued
        p.append(issued);base.append(e.last_step['base_prediction'])
    return p,base,[(s.p11,s.p01,s.born) for s in e.archive],time.perf_counter()-started

def interval(values):
    n=len(values);mean=statistics.mean(values);sd=statistics.stdev(values);se=sd/math.sqrt(n)
    return {'n':n,'mean':mean,'sd':sd,'ci95':[mean-1.959963984540054*se,mean+1.959963984540054*se],
        'upper_one_sided_95':mean+statistics.NormalDist().inv_cdf(.95)*se}

def point_harm(rows,arm):
    return max(0.,max(statistics.mean(r['metrics'][arm]['brier']-r['metrics']['fixed']['brier'] for r in rows if r['scenario']==s) for s in C['known_scenarios']))

def validation():
    started=time.perf_counter();cache=[];fixed_scores=[]
    for s in C['known_scenarios']:
        for seed in range(C['validation_base'],C['validation_base']+C['validation_n']):
            fit,stream=data(s,seed);pa,base,archive,ta=expert(engine(fit),stream);fixed={}
            for h in C['hazards']:
                pf,fb,fa,tf=expert(engine(fit,h),stream);assert base==fb and archive==fa
                fixed[str(h)]=pf;fixed_scores.append({'scenario':s,'seed':seed,'hazard':h,**b.p25.score(stream[1:],pf)})
            cache.append({'scenario':s,'seed':seed,'stream':stream,'adaptive':pa,'fixed':fixed})
        print('Validation experts',s,flush=True)
    means={str(h):statistics.mean(r['brier'] for r in fixed_scores if r['hazard']==h) for h in C['hazards']}
    h=min(C['hazards'],key=lambda h:means[str(h)])
    candidates=[]
    for index,params in enumerate(C['candidates']):
        rows=[]
        for r in cache:
            pf=r['fixed'][str(h)];pa=r['adaptive'];y=r['stream'][1:];q,_=replay(pf,pa,y,params)
            rows.append({'scenario':r['scenario'],'seed':r['seed'],'metrics':{'fixed':b.p25.score(y,pf),'adaptive':b.p25.score(y,pa),'revised':b.p25.score(y,q)}})
        avg=statistics.mean(r['metrics']['revised']['brier'] for r in rows)
        delta=statistics.mean(r['metrics']['revised']['brier']-r['metrics']['adaptive']['brier'] for r in rows)
        ha=point_harm(rows,'adaptive');hr=point_harm(rows,'revised');dh=hr-ha
        violation=max(delta+C['revised_minimum_effect'],dh+C['worst_harm_reduction'])
        candidates.append({'index':index,'params':params,'mean_brier':avg,'mean_minus_adaptive':delta,'original_worst_harm':ha,
            'revised_worst_harm':hr,'harm_change':dh,'eligible':violation<=0,'max_margin_violation':violation,'raw':rows})
    eligible=[r for r in candidates if r['eligible']]
    selected=min(eligible,key=lambda r:(r['mean_brier'],r['index'])) if eligible else min(candidates,key=lambda r:(r['max_margin_violation'],r['mean_brier'],r['index']))
    selection={'fixed_hazard':h,'gate':selected['params'],'candidate_index':selected['index'],'eligible_candidates':len(eligible),
        'selection_rule':'minimum mean Brier among candidates meeting both point-estimate margins; if none, minimize maximum margin violation then mean Brier then grid index',
        'selected_validation':{k:v for k,v in selected.items() if k!='raw'},'sealed_before_test':datetime.now(timezone.utc).isoformat(),
        'freeze_sha256':frozen(),'validation_base':C['validation_base'],'validation_n':C['validation_n'],
        'elapsed_seconds':time.perf_counter()-started}
    save(ROOT/'results/validation.json',{'fixed_candidate_means':means,'fixed_raw':fixed_scores,'gate_candidates':candidates})
    selection['validation_sha256']=sha(ROOT/'results/validation.json')
    save(ROOT/'results/selection_freeze.json',selection);(ROOT/'results/selection_freeze.sha256').write_text(sha(ROOT/'results/selection_freeze.json')+'\n')
    print('SELECTION SEALED',json.dumps(selection),flush=True)
    return selection

def one_path(s,seed,selection,trace=False):
    fit,stream=data(s,seed);pa,ba,aa,ta=expert(engine(fit),stream)
    pf,bf,af,tf=expert(engine(fit,selection['fixed_hazard']),stream);assert ba==bf and aa==af
    st=time.perf_counter();pr,weights=replay(pf,pa,stream[1:],selection['gate'],trace=trace);tg=time.perf_counter()-st
    paths={'fixed':pf,'adaptive':pa,'revised':pr}
    r={'scenario':s,'seed':seed,'family_class':'known' if s in C['known_scenarios'] else 'unseen_exploratory',
        'training':asdict(fit),'metrics':{a:b.p25.score(stream[1:],p) for a,p in paths.items()},
        'forecast_sha256':{a:ph(p) for a,p in paths.items()},'stream_sha256':ph(stream),
        'compute_seconds':{'adaptive_expert':ta,'fixed_expert':tf,'gate_only':tg,'revised_total':ta+tf+tg},
        'identity':{'base_paths_identical':True,'archives_identical':True},'observations':len(stream)-1}
    if trace:r['trace']={'stream':stream,'forecasts':paths,'adaptive_gate_weight':weights}
    return r

def summarize(rows):
    out={};pairs=[('revised','adaptive'),('revised','fixed'),('adaptive','fixed')]
    for split in [*C['test_bases'],'combined']:
        rr=[r for r in rows if split=='combined' or r['split']==split];entry={'scenarios':{},'known_scenario_average':{}}
        for s in C['known_scenarios']+C['transfer_scenarios']:
            sr=[r for r in rr if r['scenario']==s]
            entry['scenarios'][s]={'class':sr[0]['family_class'],'absolute':{a:{m:interval([r['metrics'][a][m] for r in sr]) for m in ['brier','bce']} for a in ['fixed','adaptive','revised']},
                'contrasts':{a+'-minus-'+c:{m:interval([r['metrics'][a][m]-r['metrics'][c][m] for r in sr]) for m in ['brier','bce']} for a,c in pairs}}
        for a,c in pairs:
            entry['known_scenario_average'][a+'-minus-'+c]={}
            for metric in ['brier','bce']:
                grouped=defaultdict(list)
                for r in rr:
                    if r['scenario'] in C['known_scenarios']:grouped[r['seed']].append(r['metrics'][a][metric]-r['metrics'][c][metric])
                assert all(len(v)==11 for v in grouped.values())
                entry['known_scenario_average'][a+'-minus-'+c][metric]=interval([statistics.mean(v) for v in grouped.values()])
        sdata=entry['scenarios'];z=statistics.NormalDist().inv_cdf(1-.05/(2*len(C['known_scenarios'])))
        ru={};al={};old_ru={}
        for s in C['known_scenarios']:
            rev=sdata[s]['contrasts']['revised-minus-fixed']['brier'];ori=sdata[s]['contrasts']['adaptive-minus-fixed']['brier']
            ru[s]=rev['mean']+z*rev['sd']/math.sqrt(rev['n']);al[s]=ori['mean']-z*ori['sd']/math.sqrt(ori['n'])
            old_ru[s]=rev['mean']+statistics.NormalDist().inv_cdf(1-.05/11)*rev['sd']/math.sqrt(rev['n'])
        hru=max(0.,max(ru.values()));hal=max(0.,max(al.values()));ub=hru-hal
        mean_ra=entry['known_scenario_average']['revised-minus-adaptive']['brier'];mean_rf=entry['known_scenario_average']['revised-minus-fixed']['brier']
        entry['revised_target']={'minimum_mean_gain':C['revised_minimum_effect'],'mean_benefit_pass':mean_ra['upper_one_sided_95'] < -C['revised_minimum_effect'],
            'required_worst_harm_reduction':C['worst_harm_reduction'],'revised_scenario_upper_bounds':ru,'original_scenario_lower_bounds':al,
            'worst_harm_change_upper_bound':ub,'harm_reduction_pass':ub < -C['worst_harm_reduction'],
            'original_worst_harm_mean':max(0.,max(sdata[s]['contrasts']['adaptive-minus-fixed']['brier']['mean'] for s in C['known_scenarios'])),
            'revised_worst_harm_mean':max(0.,max(sdata[s]['contrasts']['revised-minus-fixed']['brier']['mean'] for s in C['known_scenarios']))}
        entry['unchanged_v3_fixed_target']={'minimum_mean_gain':.0005,'mean_superiority_pass':mean_rf['upper_one_sided_95'] < -.0005,
            'harm_margin':.001,'scenario_upper_bounds':old_ru,'harm_guardrail_pass':max(old_ru.values())<.001}
        out[split]=entry
    directions=all(out[split]['known_scenario_average']['revised-minus-adaptive']['brier']['mean']<0 for split in C['test_bases'])
    out['combined']['revised_target']['negative_direction_both_banks']=directions
    out['combined']['revised_target']['joint_pass']=directions and out['combined']['revised_target']['mean_benefit_pass'] and out['combined']['revised_target']['harm_reduction_pass']
    olddir=all(out[split]['known_scenario_average']['revised-minus-fixed']['brier']['mean']<0 for split in C['test_bases'])
    out['combined']['unchanged_v3_fixed_target']['negative_direction_both_banks']=olddir
    out['combined']['unchanged_v3_fixed_target']['joint_pass']=olddir and out['combined']['unchanged_v3_fixed_target']['mean_superiority_pass'] and out['combined']['unchanged_v3_fixed_target']['harm_guardrail_pass']
    return out

def main():
    start=time.perf_counter();frozen();selection=validation();rows=[]
    raw=ROOT/'results/raw_paths.jsonl'
    with raw.open('x') as fp:
        for split,base in C['test_bases'].items():
            for s in C['known_scenarios']+C['transfer_scenarios']:
                for seed in range(base,base+C['test_n']):
                    r={'split':split,**one_path(s,seed,selection,trace=seed==base)}
                    fp.write(json.dumps(r,separators=(',',':'),allow_nan=False)+'\n');fp.flush();rows.append(r)
                print('Test',split,s,'complete',flush=True)
    report={'status':'complete','freeze_sha256':frozen(),'selection_freeze_sha256':sha(ROOT/'results/selection_freeze.json'),
        'selection':selection,'paths':len(rows),'known_paths':sum(r['family_class']=='known' for r in rows),
        'transfer_paths':sum(r['family_class']=='unseen_exploratory' for r in rows),'raw_sha256':sha(raw),
        'summary':summarize(rows),'compute_seconds':{k:sum(r['compute_seconds'][k] for r in rows) for k in rows[0]['compute_seconds']},
        'all_identities':all(all(r['identity'].values()) for r in rows),'elapsed_seconds':time.perf_counter()-start,'limitations':C['limitations']}
    save(ROOT/'results/summary.json',report)
    print('COMPLETE',json.dumps({'paths':len(rows),'revised_target':report['summary']['combined']['revised_target'],'unchanged_v3_fixed_target':report['summary']['combined']['unchanged_v3_fixed_target']}),flush=True)

if __name__=='__main__':main()
