#!/usr/bin/env python3
"""Causal mixture over forgetting-rate policies, with common immutable memory.

Each rate policy has two conditional-row expert posteriors. All policies share
one pinned P25 no-memory adaptive base and one immutable archive. The outer
global posterior mixes complete rate-policy forecasts; its weighted mean rate
is descriptive, not an equivalent single-rate algorithm.

Chronology: forecast -> outcome likelihood for OLD experts/policies -> common
utility -> shadow update -> optional replacement/admission -> inner fixed share
and outer metashare for the next forecast. New snapshots receive no birth-outcome
likelihood or utility. born is first eligible forecast index (initial0, then t+1).

At full capacity, none rejects admission; fifo evicts oldest(born,id); utility
evicts lowest updated common utility with oldest(born,id) tie break. Utility is
.95*u+.05*(cached snapshot log likelihood - cached base log likelihood), updated
on every global outcome. Victim posterior mass transfers to base in EVERY
rate/row before new .10 mass is added and surviving mass scaled .90. No merging.
Novelty is distance>=.12 from EVERY pre-replacement snapshot, after the common
P25 six-window/valence>.20/continuity>.82 capture trigger.

Inner fixed share and outer metashare each occur once per global observation.
The inner prior is .5base/.5equal-memory, or base1 when the archive is empty.
The outer prior is uniform over configured rates. Uniform meta mode fixes that
prior at every forecast; it leaves inner policies unchanged. Predict is pure.

Only forecast loss is tested: no claim of regime identity or phenomenology.
"""
from dataclasses import dataclass
import importlib.util
import math
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
_REFERENCE=ROOT/'reference/phase25_suite.py'
_NAME='_phase210_pinned_phase25'
if _NAME in sys.modules and Path(sys.modules[_NAME].__file__).resolve()==_REFERENCE.resolve():
    _P25=sys.modules[_NAME]
else:
    _SPEC=importlib.util.spec_from_file_location(_NAME,_REFERENCE)
    _P25=importlib.util.module_from_spec(_SPEC);sys.modules[_NAME]=_P25;_SPEC.loader.exec_module(_P25)
EPS=1e-12
NEG_INF=float('-inf')


def _probability(x,name='probability'):
    if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or not 0<=x<=1:
        raise ValueError(f'{name} must be a finite probability')


def _nonnegative_int(x,name):
    if isinstance(x,bool) or not isinstance(x,int) or x<0:
        raise ValueError(f'{name} must be a nonnegative integer')


def _binary(x):
    if isinstance(x,bool) or not isinstance(x,int) or x not in (0,1):
        raise ValueError('observation must be integer0 or1')


def _logadd(a,b):
    if a==NEG_INF:return b
    if b==NEG_INF:return a
    hi,lo=max(a,b),min(a,b)
    return hi+math.log1p(math.exp(lo-hi))


def _normalize(logs):
    maximum=max(logs)
    if not math.isfinite(maximum):raise ValueError('no positive finite expert mass')
    z=maximum+math.log(math.fsum(math.exp(x-maximum) for x in logs))
    return tuple(x-z for x in logs)


def _weights(logs):
    values=tuple(math.exp(x) for x in logs);total=math.fsum(values)
    return tuple(x/total for x in values)


def _likelihood(y,p):
    return math.log(p) if y else math.log1p(-p)


def _clip(p):
    return min(max(p,EPS),1-EPS)


@dataclass(frozen=True)
class Snapshot:
    p11: float
    p01: float
    born: int
    id: int


class Phase210Engine:
    def __init__(self,hazards=(0.,.005,.02,.05,.1,.2),meta_share=.01,
                 replacement='fifo',memory_enabled=True,max_snapshots=8,meta_mode='bayes'):
        try:hazards=tuple(hazards)
        except TypeError as exc:raise ValueError('hazards must be a nonempty iterable') from exc
        if not hazards:raise ValueError('at least one hazard required')
        for h in hazards:_probability(h,'hazard')
        if len(set(hazards))!=len(hazards):raise ValueError('hazards must be distinct')
        _probability(meta_share,'meta_share');_nonnegative_int(max_snapshots,'max_snapshots')
        if replacement not in ('none','fifo','utility'):raise ValueError('unknown replacement policy')
        if meta_mode not in ('bayes','uniform'):raise ValueError('unknown meta_mode')
        if not isinstance(memory_enabled,bool):raise ValueError('memory_enabled must be boolean')
        self.hazards,self.meta_share=hazards,meta_share
        self.replacement,self.memory_enabled=replacement,memory_enabled
        self.max_snapshots,self.meta_mode=max_snapshots,meta_mode
        self.initialize(.5,.5,.5)

    def initialize(self,p11,p01,marginal):
        for value in (p11,p01,marginal):_probability(value)
        base=_P25.RefinedQualiaEngineV1_1(enable_episodic_memory=False)
        base.initialize(p11,p01,marginal)
        self.base=base
        self.archive=[Snapshot(p11,p01,0,0)] if self.max_snapshots else []
        self.utility={s.id:0. for s in self.archive}
        self.next_id=len(self.archive)
        self.step_index=0
        prior=self._prior()
        self.rate_log_weights=[[prior,prior] for _ in self.hazards]
        self.meta_log_weights=self._meta_prior()
        self.last_step=None
        self.stats=dict(steps=0,admissions=0,replacements=0,novel_candidates=0,capacity_rejections=0)

    def _prior(self):
        if not self.archive:return (0.,)
        return (math.log(.5),)+(math.log(.5/len(self.archive)),)*len(self.archive)

    def _meta_prior(self):
        return (-math.log(len(self.hazards)),)*len(self.hazards)

    def _forecast(self,row):
        _binary(row)
        base_prediction=self.base.predict_proba(row)
        expert_predictions=(_clip(base_prediction),)+tuple(_clip(s.p11 if row else s.p01) for s in self.archive)
        if self.memory_enabled:
            rate_logs=tuple(weights[row] for weights in self.rate_log_weights)
        else:
            rate_logs=((0.,)+(NEG_INF,)*len(self.archive),)*len(self.hazards)
        rate_weights=tuple(_weights(logs) for logs in rate_logs)
        rate_predictions=tuple(math.fsum(w*p for w,p in zip(weights,expert_predictions)) for weights in rate_weights)
        meta_logs=self._meta_prior() if self.meta_mode=='uniform' else self.meta_log_weights
        meta_weights=_weights(meta_logs)
        mixture=math.fsum(w*p for w,p in zip(meta_weights,rate_predictions))
        combined=tuple(math.fsum(meta_weights[j]*rate_weights[j][k] for j in range(len(self.hazards)))
                       for k in range(len(self.archive)+1))
        memory_weight=math.fsum(combined[1:])
        age_total=math.fsum(w*(self.step_index-s.born) for w,s in zip(combined[1:],self.archive))
        return dict(prediction=mixture if self.memory_enabled else base_prediction,
                    base_prediction=base_prediction,mixture_prediction=mixture,
                    memory_weight=memory_weight,effective_share=math.fsum(w*h for w,h in zip(meta_weights,self.hazards)),
                    meta_weights=meta_weights,rate_predictions=rate_predictions,rate_weights=rate_weights,
                    expert_predictions=expert_predictions,combined_expert_weights=combined,
                    mean_memory_age=age_total/memory_weight if memory_weight else 0.,
                    forecast_archive_size=len(self.archive),bank_ids_before=tuple(s.id for s in self.archive),
                    _rate_logs=rate_logs,_meta_logs=meta_logs)

    def predict_proba(self,prev_s):
        """Pure: repeated queries never update posterior, utility, age or archive."""
        return self._forecast(prev_s)['prediction']

    def _capture(self):
        """Called after shadow update and step-index increment; born is next t."""
        if not self.max_snapshots or len(self.base.window)<6 or not(self.base.valence>.20 and self.base.continuity>.82):
            return False,None,None
        p11,p01=self.base.p11_fast,self.base.p01_fast
        if any(math.hypot(s.p11-p11,s.p01-p01)<.12 for s in self.archive):
            return False,None,None
        self.stats['novel_candidates']+=1
        victim=None;transfers=None
        if len(self.archive)>=self.max_snapshots:
            if self.replacement=='none':
                self.stats['capacity_rejections']+=1
                return False,None,None
            key=(lambda k:(self.archive[k].born,self.archive[k].id)) if self.replacement=='fifo' else (
                lambda k:(self.utility[self.archive[k].id],self.archive[k].born,self.archive[k].id))
            index=min(range(len(self.archive)),key=key)
            old=self.archive[index]
            victim=dict(id=old.id,p11=old.p11,p01=old.p01,born=old.born,utility=self.utility[old.id],
                        age_at_last_forecast=self.step_index-1-old.born)
            transfers=[]
            for rate in self.rate_log_weights:
                pair=[]
                for row in (0,1):
                    logs=list(rate[row]);pair.append(math.exp(logs[index+1]))
                    logs[0]=_logadd(logs[0],logs[index+1]);del logs[index+1]
                    rate[row]=_normalize(logs)
                transfers.append(tuple(pair))
            transfers=tuple(transfers)
            del self.archive[index];del self.utility[old.id]
            self.stats['replacements']+=1
        self.archive.append(Snapshot(p11,p01,self.step_index,self.next_id))
        self.utility[self.next_id]=0.;self.next_id+=1
        for rate in self.rate_log_weights:
            for row in (0,1):
                rate[row]=_normalize(tuple(x+math.log(.9) for x in rate[row])+(math.log(.1),))
        self.stats['admissions']+=1
        return True,victim,transfers

    def _share_inner(self):
        prior=self._prior()
        for h,rate in zip(self.hazards,self.rate_log_weights):
            if h==1.:
                rate[:]=[prior,prior]
            elif h:
                keep,restart=math.log1p(-h),math.log(h)
                for row in (0,1):rate[row]=_normalize(tuple(_logadd(keep+w,restart+p) for w,p in zip(rate[row],prior)))

    def _share_meta(self):
        if self.meta_mode=='uniform' or self.meta_share==1.:
            self.meta_log_weights=self._meta_prior()
        elif self.meta_share:
            keep,restart=math.log1p(-self.meta_share),math.log(self.meta_share)
            self.meta_log_weights=_normalize(tuple(_logadd(keep+w,restart+p)
                                                   for w,p in zip(self.meta_log_weights,self._meta_prior())))

    def step_update(self,prev_s,curr_s):
        _binary(prev_s);_binary(curr_s)
        forecast=self._forecast(prev_s)
        expert_ll=tuple(_likelihood(curr_s,p) for p in forecast['expert_predictions'])
        for rate,prior in zip(self.rate_log_weights,forecast['_rate_logs']):
            rate[prev_s]=_normalize(tuple(w+l for w,l in zip(prior,expert_ll)))
        if self.meta_mode=='bayes':
            self.meta_log_weights=_normalize(tuple(w+_likelihood(curr_s,p)
                               for w,p in zip(forecast['_meta_logs'],forecast['rate_predictions'])))
        utility_before=dict(self.utility)
        for snap,ll in zip(self.archive,expert_ll[1:]):
            self.utility[snap.id]=.95*self.utility[snap.id]+.05*(ll-expert_ll[0])
        utility_scored=dict(self.utility)
        if self.base.step_update(prev_s,curr_s)!=forecast['base_prediction']:
            raise AssertionError('shadow base changed before its own outcome update')
        t=self.step_index;self.step_index+=1
        admission,victim,transfers=self._capture()
        new_mass=tuple(tuple(math.exp(row[-1]) for row in rate) for rate in self.rate_log_weights) if admission else None
        self._share_inner();self._share_meta()
        self.stats['steps']+=1
        self.last_step={k:v for k,v in forecast.items() if not k.startswith('_')}
        self.last_step.update(step_index=t,active_row=prev_s,outcome=curr_s,
                    admission=admission,new_expert=admission,replacement=victim is not None,
                    victim=victim,victim_id=victim['id'] if victim else None,
                    eviction_transferred_mass=transfers,new_mass_before_share=new_mass,
                    archive_size=len(self.archive),bank_ids_after=tuple(s.id for s in self.archive),
                    utility_before=utility_before,utility_scored=utility_scored,utility=dict(self.utility),
                    meta_weights_after_update=_weights(self.meta_log_weights))
        return forecast['prediction']
