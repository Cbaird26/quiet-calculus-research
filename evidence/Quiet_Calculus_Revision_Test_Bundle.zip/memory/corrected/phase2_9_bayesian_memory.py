#!/usr/bin/env python3
"""Prequential row-factorized expert mixture over an independent P25 shadow base.

Archive admission is NEW: the no-memory P25 shadow supplies the .20/.82
consolidation trigger; immutable snapshots are admitted at distance >=.12 from
every existing snapshot, cap8. There is no merging or eviction. All arms share
this archive and base trajectory. It is not the original P25 memory trajectory.

Bayes updates use only issued, cached expert probabilities, after the outcome.
New experts first appear in the next forecast and receive fresh mass .10 without
credit for their birth outcome. Each conditioning row has its own posterior.
The prior assigns .5 to the adaptive base and .5 equally to eligible snapshots.
Uniform means this fixed prior mixture, not equal mass across base and snapshots.

Fixed share is applied to BOTH rows after EVERY global observation for the next
prediction: (1-h)*posterior+h*prior. Gap reset is a pure effective-prior reset if
the active row was previously observed and t-last_seen>gap_reset. Predictions
never mutate state. Gap and TTL are elapsed global steps, not row observations.

born is the first eligible prediction index (initial0; after outcome t: t+1).
TTL masks age>ttl and redirects expired predictive mass to the base. Expired
experts never revive, are not evicted, and still occupy archive capacity. Inactive
row bookkeeping can retain expired mass until queried; it cannot affect issued
forecasts. Share priors never inject mass into expired experts. A gap reset uses
the current eligible prior before masking. None disables the associated control.

Only the fixed-bank, no-share/no-reset/no-TTL Bayes arm has the ordinary static
expert cumulative log-loss bound. This does not assert pointwise Brier benefit,
regime identification, or phenomenological consciousness.
"""
from dataclasses import dataclass
import importlib.util
import math
from pathlib import Path
import sys

_ROOT = Path(__file__).resolve().parents[1]
_SPEC = importlib.util.spec_from_file_location('_phase29_pinned_phase25', _ROOT/'reference/phase25_suite.py')
_P25 = importlib.util.module_from_spec(_SPEC)
sys.modules[_SPEC.name] = _P25
_SPEC.loader.exec_module(_P25)
EPS = 1e-12
NEG_INF = float('-inf')


def _probability(value, name='probability'):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1:
        raise ValueError(f'{name} must be a finite probability')


def _integer(value, name, nullable=False):
    if nullable and value is None:
        return
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f'{name} must be a nonnegative integer'+(' or None' if nullable else ''))


def _binary(value):
    if isinstance(value, bool) or not isinstance(value, int) or value not in (0, 1):
        raise ValueError('observation must be the integer 0 or 1')


def _logadd(a, b):
    if a == NEG_INF: return b
    if b == NEG_INF: return a
    hi, lo = max(a, b), min(a, b)
    return hi + math.log1p(math.exp(lo-hi))


def _normalize(logs):
    maximum = max(logs)
    if not math.isfinite(maximum):
        raise ValueError('expert weights have no finite positive mass')
    normalizer = maximum + math.log(math.fsum(math.exp(x-maximum) for x in logs))
    return tuple(x-normalizer for x in logs)


def _logs(weights):
    return tuple(math.log(x) if x else NEG_INF for x in weights)


def _weights(logs):
    weights = [math.exp(x) for x in logs]
    total = math.fsum(weights)
    return tuple(x/total for x in weights)


@dataclass(frozen=True)
class Snapshot:
    p11: float
    p01: float
    born: int


class Phase29Engine:
    def __init__(self, share_rate=0., gap_reset=None, ttl=None, weighting='bayes',
                 memory_enabled=True, max_snapshots=8):
        _probability(share_rate, 'share_rate')
        _integer(gap_reset, 'gap_reset', True)
        _integer(ttl, 'ttl', True)
        _integer(max_snapshots, 'max_snapshots')
        if weighting not in ('bayes', 'uniform'):
            raise ValueError('weighting must be bayes or uniform')
        if not isinstance(memory_enabled, bool):
            raise ValueError('memory_enabled must be boolean')
        self.share_rate, self.gap_reset, self.ttl = share_rate, gap_reset, ttl
        self.weighting, self.memory_enabled = weighting, memory_enabled
        self.max_snapshots = max_snapshots
        self.initialize(.5, .5, .5)

    def initialize(self, p11, p01, marginal):
        # Validate all arguments before mutating an existing run.
        for value in (p11, p01, marginal): _probability(value)
        base = _P25.RefinedQualiaEngineV1_1(enable_episodic_memory=False)
        base.initialize(p11, p01, marginal)
        self.base = base
        self.archive = [Snapshot(p11, p01, 0)] if self.max_snapshots else []
        self.step_index = 0
        self.last_seen = [None, None]
        prior = self._prior_logs(0)
        self.log_weights = [prior, prior]
        self.last_step = None
        self.stats = dict(steps=0, admissions=0, gap_resets=0, forecasts_with_expired_mass=0)

    def _expired(self, index, t):
        return self.ttl is not None and t-self.archive[index].born > self.ttl

    def _prior_logs(self, t):
        eligible = [i for i in range(len(self.archive)) if not self._expired(i, t)]
        if not eligible:
            return (0.,) + (NEG_INF,)*len(self.archive)
        mass = .5/len(eligible)
        return _logs([.5]+[mass if i in eligible else 0. for i in range(len(self.archive))])

    def _forecast(self, row):
        _binary(row)
        t = self.step_index
        base_prediction = self.base.predict_proba(row)
        expert_predictions = (base_prediction,)+tuple(s.p11 if row else s.p01 for s in self.archive)
        # Consistent clipping defines the likelihood experts at probability endpoints.
        expert_predictions = tuple(min(max(p, EPS), 1-EPS) for p in expert_predictions)
        gap = self.last_seen[row] is not None and self.gap_reset is not None and t-self.last_seen[row] > self.gap_reset
        if self.weighting == 'uniform' or gap:
            logs = self._prior_logs(t)
        else:
            logs = self.log_weights[row]
        logs = list(logs)
        expired_log = NEG_INF
        for i in range(len(self.archive)):
            if self._expired(i, t):
                expired_log = _logadd(expired_log, logs[i+1])
                logs[i+1] = NEG_INF
        expired_weight = math.exp(expired_log) if expired_log != NEG_INF else 0.
        logs[0] = _logadd(logs[0], expired_log)
        if not self.memory_enabled:
            logs = [0.] + [NEG_INF]*len(self.archive)
            gap = False
            expired_weight = 0.
        logs = _normalize(logs)
        weights = _weights(logs)
        mixture_prediction = math.fsum(w*p for w,p in zip(weights,expert_predictions))
        prediction = mixture_prediction if self.memory_enabled else base_prediction
        ages = [t-s.born for s,w in zip(self.archive,weights[1:]) if w>0]
        return dict(prediction=prediction, mixture_prediction=mixture_prediction,
                    base_prediction=base_prediction, weights=weights, log_weights=logs,
                    expert_predictions=expert_predictions, gap_reset=bool(gap),
                    expired_weight=expired_weight, memory_weight=math.fsum(weights[1:]),
                    oldest_weighted_age=float(max(ages)) if ages else 0.,
                    eligible_memory_count=sum(not self._expired(i,t) for i in range(len(self.archive))),
                    forecast_archive_size=len(self.archive))

    def predict_proba(self, prev_s):
        """Pure: repeated calls neither age experts nor change weights or resets."""
        return self._forecast(prev_s)['prediction']

    def _admit(self):
        if len(self.archive) >= self.max_snapshots or len(self.base.window) < 6:
            return False
        if not (self.base.valence > .20 and self.base.continuity > .82):
            return False
        p11, p01 = self.base.p11_fast, self.base.p01_fast
        if any(math.hypot(s.p11-p11,s.p01-p01) < .12 for s in self.archive):
            return False
        self.archive.append(Snapshot(p11, p01, self.step_index))
        for row in (0,1):
            self.log_weights[row] = _normalize(tuple(x+math.log(.9) for x in self.log_weights[row])+(math.log(.1),))
        self.stats['admissions'] += 1
        return True

    def _share(self):
        if self.weighting == 'uniform':
            prior = self._prior_logs(self.step_index)
            self.log_weights = [prior, prior]
        elif self.share_rate:
            prior = self._prior_logs(self.step_index)
            if self.share_rate == 1.:
                self.log_weights = [prior, prior]
            else:
                keep, restart = math.log1p(-self.share_rate), math.log(self.share_rate)
                self.log_weights = [_normalize(tuple(_logadd(keep+w,restart+p) for w,p in zip(row,prior)))
                                    for row in self.log_weights]

    def step_update(self, prev_s, curr_s):
        # Invalid inputs must not partially advance the base, archive or posterior.
        _binary(prev_s); _binary(curr_s)
        forecast = self._forecast(prev_s)
        issued = forecast['prediction']
        if self.weighting == 'bayes':
            self.log_weights[prev_s] = _normalize(tuple(w+(math.log(p) if curr_s else math.log1p(-p))
                                                      for w,p in zip(forecast['log_weights'],forecast['expert_predictions'])))
        # Shadow dynamics use their OWN issued forecast, never mixture error.
        base_issued = self.base.step_update(prev_s,curr_s)
        if base_issued != forecast['base_prediction']:
            raise AssertionError('shadow base changed before its outcome update')
        t = self.step_index
        self.last_seen[prev_s] = t
        self.step_index += 1
        new_expert = self._admit()  # first eligible at t+1, never scored against Y_t
        weights_after_admission = tuple(_weights(x) for x in self.log_weights)
        self._share()  # one elapsed GLOBAL step, including the inactive row
        self.stats['steps'] += 1
        self.stats['gap_resets'] += int(forecast['gap_reset'])
        self.stats['forecasts_with_expired_mass'] += int(forecast['expired_weight']>0)
        self.last_step = {**forecast, 'step_index':t,'active_row':prev_s,'outcome':curr_s,
                          'new_expert':new_expert,'archive_size':len(self.archive),
                          'weights_after_admission':weights_after_admission,
                          'weights_after_update':tuple(_weights(x) for x in self.log_weights),
                          'last_seen':tuple(self.last_seen)}
        return issued
