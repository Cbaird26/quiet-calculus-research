"""Independent artifact/arithmetic replay of completed revision results."""
from collections import Counter,defaultdict
from datetime import datetime,timezone
import hashlib
import json
import math
from pathlib import Path
import re
import statistics

ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ph(v):return hashlib.sha256(json.dumps(v,separators=(',',':')).encode()).hexdigest()

def main():
    cfg=json.loads((ROOT/'protocol.json').read_text());fr=json.loads((ROOT/'freeze.json').read_text())
    fixed={n:sha(ROOT/n)==h for n,h in fr['files'].items()};assert all(fixed.values())
    src=json.loads((ROOT/'source_provenance.json').read_text())
    source={n:sha(Path(v['source']))==v['sha256'] for n,v in src.items()};assert all(source.values())
    copied={n:sha(ROOT/n)==v['sha256'] for n,v in src.items()};assert all(copied.values())
    old_root=Path(next(iter(src.values()))['source']).parents[1]
    # Locate the prior package by its dedicated manifest, independent of path depth.
    old_root=next(p for p in [old_root,*old_root.parents] if (p/'SHA256SUMS').exists() and (p/'results/summary.json').exists())
    prior={}
    for line in (old_root/'SHA256SUMS').read_text().splitlines():
        h,n=line.split('  ',1);prior[n]=sha(old_root/n)==h
    assert all(prior.values())
    rec=json.loads((ROOT/'results/execution_receipt.json').read_text());assert rec['status']=='complete'
    rows=[json.loads(line) for line in (ROOT/'results/raw_paths.jsonl').open()]
    result=json.loads((ROOT/'results/summary.json').read_text());sel=json.loads((ROOT/'results/selection_freeze.json').read_text())
    val=json.loads((ROOT/'results/validation.json').read_text())
    assert sha(ROOT/'results/selection_freeze.json')==(ROOT/'results/selection_freeze.sha256').read_text().strip()==result['selection_freeze_sha256']
    assert sha(ROOT/'results/validation.json')==sel['validation_sha256']
    assert sha(ROOT/'results/raw_paths.jsonl')==result['raw_sha256']
    assert len(rows)==1300 and len({(r['split'],r['scenario'],r['seed']) for r in rows})==1300
    assert Counter((r['split'],r['scenario']) for r in rows)=={(s,n):50 for s in cfg['test_bases'] for n in cfg['known_scenarios']+cfg['transfer_scenarios']}
    new_sets=[set(range(cfg['validation_base'],cfg['validation_base']+20))]+[set(range(b,b+50)) for b in cfg['test_bases'].values()]
    previous=set(range(181000000,181000100))|set(range(191000000,191000100))|set(range(201000000,201000030))|set(range(731010000,731010020))|set(range(731020000,731020050))|set(range(731030000,731030050))
    assert not(set.union(*new_sets)&previous)
    assert all(not(a&b) for i,a in enumerate(new_sets) for b in new_sets[i+1:])
    all_seeds=previous|set.union(*new_sets);assert not(all_seeds&{x+1000000000 for x in all_seeds})
    h=min(cfg['hazards'],key=lambda h:statistics.mean(r['brier'] for r in val['fixed_raw'] if r['hazard']==h));assert h==sel['fixed_hazard']
    for c in val['gate_candidates']:
        rr=c['raw'];mu=statistics.mean(r['metrics']['revised']['brier'] for r in rr)
        delta=statistics.mean(r['metrics']['revised']['brier']-r['metrics']['adaptive']['brier'] for r in rr)
        harms={arm:max(0.,max(statistics.mean(r['metrics'][arm]['brier']-r['metrics']['fixed']['brier'] for r in rr if r['scenario']==s) for s in cfg['known_scenarios'])) for arm in ['adaptive','revised']}
        violation=max(delta+.0001,harms['revised']-harms['adaptive']+.0003)
        assert abs(mu-c['mean_brier'])<1e-14 and abs(delta-c['mean_minus_adaptive'])<1e-14
        assert abs(violation-c['max_margin_violation'])<1e-14 and c['eligible']==(violation<=0)
    eligible=[c for c in val['gate_candidates'] if c['eligible']]
    chosen=min(eligible,key=lambda c:(c['mean_brier'],c['index'])) if eligible else min(val['gate_candidates'],key=lambda c:(c['max_margin_violation'],c['mean_brier'],c['index']))
    assert chosen['index']==sel['candidate_index'] and chosen['params']==sel['gate']
    assert all(r['scenario'] in cfg['known_scenarios'] for c in val['gate_candidates'] for r in c['raw'])
    traces=0;score_checks=0;gate_steps=0
    for r in rows:
        assert all(r['identity'].values())
        if 'trace' not in r:continue
        traces+=1;t=r['trace'];y=t['stream'][1:];assert ph(t['stream'])==r['stream_sha256']
        for arm,path in t['forecasts'].items():
            assert ph(path)==r['forecast_sha256'][arm]
            bs=statistics.mean((p-a)**2 for p,a in zip(path,y));ll=statistics.mean(-math.log(max(1e-12,min(1-1e-12,p)) if a else 1-max(1e-12,min(1-1e-12,p))) for p,a in zip(path,y))
            assert abs(bs-r['metrics'][arm]['brier'])<1e-12 and abs(ll-r['metrics'][arm]['bce'])<1e-12;score_checks+=1
        params=sel['gate'];w=params['prior_adaptive'];log_odds=math.log(w/(1-w))
        for i,(pf,pa,target) in enumerate(zip(t['forecasts']['fixed'],t['forecasts']['adaptive'],y)):
            w=1/(1+math.exp(-log_odds)) if log_odds>=0 else math.exp(log_odds)/(1+math.exp(log_odds))
            assert abs(w-t['adaptive_gate_weight'][i])<1e-11
            assert abs((1-w)*pf+w*pa-t['forecasts']['revised'][i])<1e-11
            log_odds+=params['eta']*((pf-target)**2-(pa-target)**2)
            if params['share']:
                w=1/(1+math.exp(-log_odds)) if log_odds>=0 else math.exp(log_odds)/(1+math.exp(log_odds))
                w=(1-params['share'])*w+params['share']*params['prior_adaptive'];log_odds=math.log(w/(1-w))
            gate_steps+=1
    arithmetic=0
    for split,data in result['summary'].items():
        rr=[r for r in rows if split=='combined' or r['split']==split]
        for contrast,ms in data['known_scenario_average'].items():
            arm,comp=contrast.split('-minus-')
            for metric,target in ms.items():
                grouped=defaultdict(list)
                for r in rr:
                    if r['scenario'] in cfg['known_scenarios']:grouped[r['seed']].append(r['metrics'][arm][metric]-r['metrics'][comp][metric])
                values=[statistics.mean(v) for v in grouped.values()]
                assert all(len(v)==11 for v in grouped.values())
                assert abs(statistics.mean(values)-target['mean'])<1e-14 and abs(statistics.stdev(values)-target['sd'])<1e-14;arithmetic+=1
        z=statistics.NormalDist().inv_cdf(1-.05/22);ru={};al={}
        for s in cfg['known_scenarios']:
            ss=[r for r in rr if r['scenario']==s]
            rd=[r['metrics']['revised']['brier']-r['metrics']['fixed']['brier'] for r in ss]
            ad=[r['metrics']['adaptive']['brier']-r['metrics']['fixed']['brier'] for r in ss]
            ru[s]=statistics.mean(rd)+z*statistics.stdev(rd)/math.sqrt(len(rd))
            al[s]=statistics.mean(ad)-z*statistics.stdev(ad)/math.sqrt(len(ad))
            assert abs(ru[s]-data['revised_target']['revised_scenario_upper_bounds'][s])<1e-14
            assert abs(al[s]-data['revised_target']['original_scenario_lower_bounds'][s])<1e-14
        upper=max(0.,max(ru.values()))-max(0.,max(al.values()))
        assert abs(upper-data['revised_target']['worst_harm_change_upper_bound'])<1e-14
    tests={}
    for name in ['test_phase29_engine','test_benchmark','test_phase210','test_causal_gate']:
        text=(ROOT/'logs'/f'{name}.log').read_text();m=re.search(r'Ran (\d+) tests?',text);assert m and '\nOK\n' in text;tests[name]=int(m.group(1))
    report={'status':'pass','audited_at':datetime.now(timezone.utc).isoformat(),'frozen_files':fixed,'source_unchanged':source,'copies_exact':copied,
        'prior_v3_manifest_entries_unchanged':len(prior),'all_prior_v3_manifest_entries_match':all(prior.values()),'paths':len(rows),
        'full_traces':traces,'score_hash_checks':score_checks,'causal_gate_steps_replayed':gate_steps,'average_arithmetic_checks':arithmetic,
        'test_counts':tests,'total_tests':sum(tests.values()),'selection_reproduced':sel['gate'],'fresh_seed_ranges_disjoint':True,
        'transfer_families_excluded_from_selection':True,'revised_target_pass':result['summary']['combined']['revised_target']['joint_pass'],
        'unchanged_v3_target_pass':result['summary']['combined']['unchanged_v3_fixed_target']['joint_pass'],
        'precision_note':'The simultaneous harm bounds cover the11 known families only. The2 newly authored families are exploratory transfer, excluded from both primary gates.'}
    (ROOT/'results/audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if not isinstance(v,dict)},indent=2))

if __name__=='__main__':main()
